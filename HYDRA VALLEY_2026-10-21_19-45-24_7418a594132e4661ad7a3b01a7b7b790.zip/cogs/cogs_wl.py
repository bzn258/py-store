import discord
from discord.ext import commands
from discord import app_commands
from discord.interactions import Interaction
from discord.ui import Select, View, Modal, TextInput
import sqlite3
import os
from datetime import datetime
import pytz
import imagens

# ============================================================
#  CONFIGURAÇÕES (Lidas do .env pelo main.py)
# ============================================================
CANAL_REGISTRO_ID   = int(os.getenv("CANAL_REGISTRO_ID", 0))
CANAL_APROVACAO_ID  = int(os.getenv("CANAL_APROVACAO_ID", 0))
CARGO_RECRUTADOR_ID = int(os.getenv("CARGO_RECRUTADOR_ID", 0))
CANAL_RANKING_ID    = int(os.getenv("CANAL_RANKING_ID", 0))
CARGO_MEMBRO_ID     = int(os.getenv("CARGO_MEMBRO_ID", 0))

# --- Diagnóstico Imagem ---
print(f"[DIAGNÓSTICO WL] Imagem do painel configurada via imagens.py: '{imagens.obter_caminho_imagem('painel_registro')}'")

# ── Banco de Dados ──
db_path = os.path.join(os.path.dirname(__file__), '..', 'registro.db') # Aponta para a pasta raiz
db = sqlite3.connect(db_path)
db.execute("""
    CREATE TABLE IF NOT EXISTS registros (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id       INTEGER NOT NULL,
        nome_ig       TEXT NOT NULL,
        id_ig         TEXT NOT NULL,
        recrutador_id INTEGER NOT NULL,
        aprovado_por  INTEGER,
        status        TEXT NOT NULL DEFAULT 'pendente', -- pendente, aprovado, recusado
        data_registro TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
        data_aprovacao TEXT,
        motivo_recusa TEXT
    )
""")
db.commit()

# ============================================================
#  CLASSES DA UI (VIEWS, MODALS, SELECTS)
#  Não precisam estar dentro do Cog, mas podem se preferir.
#  Deixá-las fora simplifica as referências.
# ============================================================

class RegistroModal(Modal, title="📋 Registro"):
    nome_ig  = TextInput(label="Qual seu nome? (In Game)", placeholder="Ex: João Silva", max_length=50)
    id_ig    = TextInput(label="Qual seu ID?", placeholder="Ex: 1234", max_length=10)

    def __init__(self, recrutador_id: int, bot: commands.Bot):
        super().__init__()
        self.recrutador_id = recrutador_id
        self.bot = bot

    async def on_submit(self, interaction: discord.Interaction):
        canal_aprovacao = self.bot.get_channel(CANAL_APROVACAO_ID)
        if not canal_aprovacao:
            await interaction.response.send_message("❌ Canal de aprovação não encontrado. Avise um administrador.", ephemeral=True)
            return

        cursor = db.cursor()
        cursor.execute("INSERT INTO registros (user_id, nome_ig, id_ig, recrutador_id) VALUES (?, ?, ?, ?)",
                       (interaction.user.id, self.nome_ig.value, self.id_ig.value, self.recrutador_id))
        db.commit()
        registro_id = cursor.lastrowid

        embed = discord.Embed(title="📋 Novo Pedido de Registro", color=discord.Color.gold())
        embed.set_footer(text=f"ID do Registro: {registro_id}")
        embed.add_field(name="**👤 SOLICITANTE**", value=f"{interaction.user.mention} (ID: {interaction.user.id})", inline=False)
        embed.add_field(name="**📝 DADOS**", value=f"Nome: {self.nome_ig.value}\nID: {self.id_ig.value}", inline=False)
        embed.add_field(name="**🤝 RECRUTADOR**", value=f"<@{self.recrutador_id}>", inline=False)
        embed.add_field(name="**STATUS**", value="🟡 Aguardando análise.", inline=False)

        view = View()
        view.add_item(discord.ui.Button(style=discord.ButtonStyle.success, label="Aprovar", emoji="✅", custom_id=f"aprovar_{registro_id}"))
        view.add_item(discord.ui.Button(style=discord.ButtonStyle.danger, label="Recusar", emoji="❌", custom_id=f"recusar_{registro_id}"))

        await canal_aprovacao.send(embed=embed, view=view)
        await interaction.response.send_message("✅ Solicitação enviada! Aguarde a aprovação de um recrutador.", ephemeral=True)

class RecusaModal(Modal, title="❌ Recusar Registro"):
    motivo = TextInput(label="Motivo da recusa", style=discord.TextStyle.paragraph, placeholder="Ex: Nome ou ID inválido.", required=True, max_length=200)

    def __init__(self, registro_id: int):
        super().__init__()
        self.registro_id = registro_id

    async def on_submit(self, interaction: discord.Interaction):
        db.execute("UPDATE registros SET status = 'recusado', motivo_recusa = ? WHERE id = ?", (self.motivo.value, self.registro_id))
        db.commit()

        view = View.from_message(interaction.message)
        for item in view.children:
            item.disabled = True

        cursor = db.cursor()
        cursor.execute("SELECT user_id FROM registros WHERE id = ?", (self.registro_id,))
        registro = cursor.fetchone()
        solicitante_id = registro[0]

        embed_recusado = discord.Embed(title="❌ Pedido de Registro — Recusado", color=discord.Color.red())
        embed_recusado.set_footer(text=f"ID do Registro: {self.registro_id}")
        embed_recusado.add_field(name="**👤 SOLICITANTE**", value=f"<@{solicitante_id}> (ID: {solicitante_id})", inline=False)
        embed_recusado.add_field(name="**🚫 RECUSADO POR**", value=f"{interaction.user.mention}", inline=False)
        embed_recusado.add_field(name="**📄 MOTIVO**", value=self.motivo.value, inline=False)
        embed_recusado.add_field(name="**STATUS**", value="🔴 Recusado pela staff.", inline=False)

        await interaction.response.edit_message(embed=embed_recusado, view=view)

        try:
            membro = await interaction.guild.fetch_member(solicitante_id)
            if membro:
                await membro.send(f"❌ Seu registro foi **recusado**.\n**Motivo:** {self.motivo.value}")
        except discord.NotFound:
            print(f"Não foi possível encontrar o membro {solicitante_id} para notificar sobre a recusa.")
        except discord.Forbidden:
            print(f"Não foi possível enviar DM para o membro {solicitante_id} sobre a recusa do registro {self.registro_id}.")

class RecrutadorSelect(discord.ui.Select):
    def __init__(self, membros: list, bot: commands.Bot):
        options = [discord.SelectOption(label=m.display_name, value=str(m.id)) for m in membros[:25]]
        super().__init__(placeholder="Selecione o recrutador...", options=options, max_values=1)
        self.bot = bot

    async def callback(self, interaction: discord.Interaction):
        recrutador_id = int(self.values[0])
        await interaction.response.send_modal(RegistroModal(recrutador_id=recrutador_id, bot=self.bot))


class RecrutadorFiltroModal(Modal, title="🔍 Buscar Recrutador"):
    filtro = TextInput(label="Nome ou ID do recrutador", placeholder="Ex: João ou 123456789", max_length=50)

    def __init__(self, bot: commands.Bot):
        super().__init__()
        self.bot = bot

    async def on_submit(self, interaction: discord.Interaction):
        cargo = interaction.guild.get_role(CARGO_RECRUTADOR_ID)
        if not cargo:
            await interaction.response.send_message("❌ Cargo de recrutador não encontrado.", ephemeral=True)
            return

        termo = self.filtro.value.strip().lower()
        membros_filtrados = [
            m for m in cargo.members
            if termo in m.display_name.lower() or termo in str(m.id)
        ]

        if not membros_filtrados:
            await interaction.response.send_message("❌ Nenhum recrutador encontrado com esse nome ou ID.", ephemeral=True)
            return

        if len(membros_filtrados) == 1:
            view = View()
            btn = discord.ui.Button(label=f"Registrar como {membros_filtrados[0].display_name}", custom_id=f"registrar_recrutador_{membros_filtrados[0].id}", style=discord.ButtonStyle.primary)
            view.add_item(btn)
            await interaction.response.send_message(
                f"✅ Recrutador encontrado: **{membros_filtrados[0].display_name}**",
                view=view, ephemeral=True
            )
            return

        view = View()
        view.add_item(RecrutadorSelect(membros=membros_filtrados, bot=self.bot))
        await interaction.response.send_message(
            f"📋 Encontrados **{len(membros_filtrados)}** recrutador(es). Selecione um:",
            view=view, ephemeral=True
        )


class PainelView(View):
    def __init__(self, bot: commands.Bot):
        super().__init__(timeout=None)
        self.bot = bot

    @discord.ui.button(label="Registrar", style=discord.ButtonStyle.secondary, custom_id="btn_registro", emoji="📋")
    async def registrar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(RecrutadorFiltroModal(bot=self.bot))

class RankingView(View):
    def __init__(self, bot: commands.Bot):
        super().__init__(timeout=None)
        self.bot = bot

    async def get_ranking_embed(self, limit: int = 10):
        cursor = db.cursor()
        cursor.execute("""
            SELECT recrutador_id, COUNT(*) as total
            FROM registros
            WHERE status = 'aprovado'
            GROUP BY recrutador_id
            ORDER BY total DESC
        """)
        ranking_data = cursor.fetchall()

        title = "🏆 Ranking de Recrutadores (Top 10)" if limit == 10 and len(ranking_data) > 10 else "🏆 Ranking de Recrutadores (Completo)"
        embed = discord.Embed(title=title, color=discord.Color.gold())

        if not ranking_data:
            embed.description = "Ainda não há recrutamentos aprovados."
            return embed

        description = ""
        for i, (recrutador_id, total) in enumerate(ranking_data[:limit]):
            rank_emoji = {0: "🥇", 1: "🥈", 2: "🥉"}.get(i, f"**{i+1}.**")
            try:
                user = await self.bot.fetch_user(recrutador_id)
                description += f"{rank_emoji} {user.mention} - **{total}** recrutamento(s)\n"
            except discord.NotFound:
                description += f"{rank_emoji} `ID: {recrutador_id}` (usuário não encontrado) - **{total}** recrutamento(s)\n"

        embed.description = description
        fuso_horario_py = pytz.timezone('America/Asuncion')
        hora_atual_py = discord.utils.utcnow().astimezone(fuso_horario_py)
        embed.set_footer(text=f"Última atualização: {hora_atual_py.strftime('%d/%m/%Y %H:%M:%S')}")
        return embed

    @discord.ui.button(label="Exibir Lista Completa", style=discord.ButtonStyle.primary, custom_id="ranking_show_all", emoji="📜")
    async def show_all(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        full_ranking_embed = await self.get_ranking_embed(limit=None)
        await interaction.followup.send(embed=full_ranking_embed, ephemeral=True)

    @discord.ui.button(label="Resetar Ranking", style=discord.ButtonStyle.danger, custom_id="ranking_reset", emoji="🔄")
    async def reset_ranking(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("❌ Você não tem permissão para usar este botão.", ephemeral=True)

        # Defer a resposta para dar tempo para a operação
        await interaction.response.defer()

        # Executa o reset diretamente
        db.execute("DELETE FROM registros")
        db.commit()
        
        reset_embed = await self.get_ranking_embed()
        reset_embed.title = "✅ Ranking Resetado com Sucesso!"
        await interaction.edit_original_response(embed=reset_embed, view=self)

# ============================================================
#  O COG PRINCIPAL
# ============================================================
class RegistroCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        # Adiciona as views persistentes quando o cog é carregado
        self.bot.add_view(PainelView(bot=self.bot))
        self.bot.add_view(RankingView(bot=self.bot))

    async def atualizar_painel_ranking(self):
        """Encontra e atualiza a mensagem do painel de ranking."""
        if not CANAL_RANKING_ID:
            print("⚠️ CANAL_RANKING_ID não configurado. A atualização automática do ranking está desativada.")
            return

        try:
            channel = await self.bot.fetch_channel(CANAL_RANKING_ID)
        except (discord.NotFound, discord.Forbidden):
            print(f"❌ Erro: Não foi possível encontrar ou acessar o canal de ranking com ID {CANAL_RANKING_ID}.")
            return

        # Procura por uma mensagem de ranking existente para editar
        async for message in channel.history(limit=50):
            if message.author == self.bot.user and message.embeds and "Ranking de Recrutadores" in message.embeds[0].title:
                view = RankingView(bot=self.bot)
                embed = await view.get_ranking_embed(limit=10)
                await message.edit(embed=embed, view=view)
                print(f"✅ Painel de ranking de recrutadores editado no canal {channel.name}.")
                return
        
        # Se não encontrou, envia um novo
        view = RankingView(bot=self.bot)
        embed = await view.get_ranking_embed(limit=10)
        await channel.send(embed=embed, view=view)
        print(f"✅ Novo painel de ranking de recrutadores enviado para o canal {channel.name}.")


    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):
        if interaction.type != discord.InteractionType.component:
            return

        custom_id = interaction.data.get("custom_id", "")

        # ── Aprovar ──
        if custom_id.startswith("aprovar_"):
            await interaction.response.defer()
            registro_id = int(custom_id.split("_")[1])

            view = View.from_message(interaction.message)
            for item in view.children:
                item.disabled = True

            cursor = db.cursor()
            cursor.execute("SELECT user_id, nome_ig, id_ig FROM registros WHERE id = ?", (registro_id,))
            registro = cursor.fetchone()

            if not registro:
                await interaction.followup.send("❌ Registro não encontrado no banco de dados.", ephemeral=True)
                return

            solicitante_id, nome_ig, id_ig = registro
            try:
                membro = await interaction.guild.fetch_member(solicitante_id)
            except discord.NotFound:
                membro = None

            if not membro:
                await interaction.followup.send("❌ Membro não encontrado no servidor. Ele pode ter saído.", ephemeral=True)
                return

            novo_nick = f"{nome_ig} | {id_ig}"
            try:
                await membro.edit(nick=novo_nick)
            except discord.Forbidden:
                await interaction.channel.send(f"⚠️ Sem permissão para renomear {membro.mention}.", silent=True)

            cargo_membro = interaction.guild.get_role(CARGO_MEMBRO_ID)
            if cargo_membro:
                try:
                    await membro.add_roles(cargo_membro)
                except discord.Forbidden:
                    await interaction.followup.send("⚠️ Sem permissão para adicionar cargo.", ephemeral=True)
                    return

            db.execute("""
                UPDATE registros
                SET status = 'aprovado', aprovado_por = ?, data_aprovacao = datetime('now', 'localtime')
                WHERE id = ?
            """, (interaction.user.id, registro_id))
            db.commit()

            recrutador_field = interaction.message.embeds[0].fields[2].value
            embed_aprovado = discord.Embed(title="✅ Pedido de Registro — Aprovado", color=discord.Color.green())
            embed_aprovado.set_footer(text=f"ID do Registro: {registro_id}")
            embed_aprovado.add_field(name="**👤 SOLICITANTE**", value=f"{membro.mention} (ID: `{membro.id}`)", inline=False)
            embed_aprovado.add_field(name="**📝 DADOS**", value=f"Nome: `{nome_ig}`\nID: `{id_ig}`", inline=False)
            embed_aprovado.add_field(name="**🤝 RECRUTADOR**", value=recrutador_field, inline=False)
            embed_aprovado.add_field(name="**✅ APROVADO POR**", value=f"{interaction.user.mention}", inline=False)
            embed_aprovado.add_field(name="**STATUS**", value="🟢 Aprovado por um recrutador.", inline=False)

            await interaction.edit_original_response(embed=embed_aprovado, view=view)

            try:
                await membro.send(f"🎉 Parabéns! Seu registro foi **aprovado**.\nSeu nick foi definido como: `{novo_nick}`")
            except discord.Forbidden:
                print(f"Não foi possível enviar DM para {membro.name}.")
            
            # Atualiza o painel de ranking
            await self.atualizar_painel_ranking()
            return

        # ── Recusar ──
        if custom_id.startswith("recusar_"):
            registro_id = int(custom_id.split("_")[1])
            await interaction.response.send_modal(RecusaModal(registro_id=registro_id))
            return

        # ── Registrar recrutador (filtro de 1 resultado) ──
        if custom_id.startswith("registrar_recrutador_"):
            recrutador_id = int(custom_id.split("_")[2])
            await interaction.response.send_modal(RegistroModal(recrutador_id=recrutador_id, bot=self.bot))
            return
            
    @app_commands.command(name="ranking", description="Exibe o painel com o ranking de recrutadores.")
    @app_commands.default_permissions(administrator=True)
    async def ranking(self, interaction: discord.Interaction, canal: discord.TextChannel = None):
        """Configura o painel com o ranking de recrutadores em um canal."""
        target_channel = canal or self.bot.get_channel(CANAL_RANKING_ID)
        if not target_channel:
            await interaction.response.send_message(
                "❌ Por favor, especifique um canal ou defina `CANAL_RANKING_ID` no seu arquivo de configuração.",
                ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True, thinking=True)
        view = RankingView(bot=self.bot)
        embed = await view.get_ranking_embed(limit=10)
        await target_channel.send(embed=embed, view=view)
        await interaction.followup.send(f"✅ Painel de ranking configurado com sucesso em {target_channel.mention}!")

    @app_commands.command(name="setup_painel", description="Configura o painel de registro no canal definido.")
    @app_commands.default_permissions(administrator=True)
    async def setup_painel(self, interaction: discord.Interaction):
        """Configura o painel de registro no canal."""
        canal = self.bot.get_channel(CANAL_REGISTRO_ID)
        if not canal:
            await interaction.response.send_message("❌ Canal de registro não encontrado. Verifique `CANAL_REGISTRO_ID`.", ephemeral=True)
            return

        await interaction.response.defer(ephemeral=True, thinking=True)
        
        await canal.purge(limit=100)

        embed = discord.Embed(
            title="📋 Sistema de Registro **HYDRA**",
            description="*Clique no botão abaixo para realizar seu **registro**.\n*Após o registro, aguarde a aprovação de um recrutador para receber seu cargo e ter acesso completo ao servidor.",
            color=0x2F4F4F
        )
        # Aplica a imagem do painel a partir do arquivo local em imagens.py
        arquivo_imagem = imagens.aplicar_imagem_painel(embed, "painel_registro")

        if arquivo_imagem:
            await canal.send(embed=embed, view=PainelView(bot=self.bot), file=arquivo_imagem)
        else:
            await canal.send(embed=embed, view=PainelView(bot=self.bot))
        await interaction.followup.send(f"✅ Painel de registro configurado com sucesso no canal {canal.mention}!", ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(RegistroCog(bot))