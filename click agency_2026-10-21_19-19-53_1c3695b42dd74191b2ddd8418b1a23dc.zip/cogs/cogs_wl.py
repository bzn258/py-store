import discord
from discord.ext import commands
from discord import app_commands
from discord.ui import Modal, TextInput, View
import sqlite3
import os
from datetime import datetime

# ============================================================
#  CONFIGURAÇÕES (Lidas do .env)
# ============================================================
CANAL_REGISTRO_ID   = int(os.getenv("CANAL_REGISTRO_ID", 0))
# Canal de logs da Whitelist (usa CANAL_LOG_WL_ID ou o antigo CANAL_APROVACAO_ID como fallback)
CANAL_LOG_WL_ID     = int(os.getenv("CANAL_LOG_WL_ID", os.getenv("CANAL_APROVACAO_ID", 0)))
CARGO_MEMBRO_ID     = int(os.getenv("CARGO_MEMBRO_ID", 0))

# ── Banco de Dados ──
db_path = os.path.join(os.path.dirname(__file__), '..', 'registro.db')
db = sqlite3.connect(db_path)
db.execute("""
    CREATE TABLE IF NOT EXISTS registros (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id       INTEGER NOT NULL,
        nome_ig       TEXT NOT NULL,
        id_ig         TEXT NOT NULL,
        recrutador_id INTEGER DEFAULT 0,
        aprovado_por  INTEGER,
        status        TEXT NOT NULL DEFAULT 'aprovado',
        data_registro TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
        data_aprovacao TEXT,
        motivo_recusa TEXT
    )
""")
db.commit()

# ============================================================
#  MODAL DE WHITELIST
# ============================================================
class RegistroModal(Modal, title="📋 Iniciar Whitelist"):
    nome_ig = TextInput(
        label="Qual seu nome? (In Game)",
        placeholder="Ex: João Silva",
        min_length=2,
        max_length=15,
        required=True
    )
    id_ig = TextInput(
        label="Qual seu ID?",
        placeholder="Ex: 1234",
        min_length=1,
        max_length=7,
        required=True
    )

    def __init__(self, bot: commands.Bot):
        super().__init__()
        self.bot = bot

    async def on_submit(self, interaction: discord.Interaction):
        # Evita timeout de 3 segundos do Discord enquanto processa permissões e logs
        await interaction.response.defer(ephemeral=True, thinking=True)

        member = interaction.user
        if not isinstance(member, discord.Member) and interaction.guild:
            try:
                member = await interaction.guild.fetch_member(interaction.user.id)
            except Exception:
                member = interaction.user

        nome = self.nome_ig.value.strip()
        id_game = self.id_ig.value.strip()

        # O Discord possui limite estrito de 32 caracteres para apelidos
        novo_nick = f"{nome} | {id_game}"
        if len(novo_nick) > 32:
            novo_nick = novo_nick[:32]

        # 1. Alterar o apelido do membro
        nick_alterado = False
        msg_aviso_nick = ""
        try:
            await member.edit(nick=novo_nick)
            nick_alterado = True
        except discord.Forbidden:
            msg_aviso_nick = "⚠️ O bot não possui permissão de hierarquia para alterar seu apelido (comum para administradores/dono do servidor)."
            print(f"⚠️ Sem permissão hierárquica para alterar apelido de {member} ({member.id}).")
        except Exception as e:
            msg_aviso_nick = f"⚠️ Erro ao atualizar apelido: {e}"
            print(f"⚠️ Erro ao alterar apelido de {member}: {e}")

        # 2. Adicionar o cargo de membro configurado
        cargo_adicionado = False
        cargo_membro = interaction.guild.get_role(CARGO_MEMBRO_ID) if interaction.guild else None
        if cargo_membro:
            try:
                await member.add_roles(cargo_membro, reason="Whitelist aprovada automaticamente")
                cargo_adicionado = True
            except discord.Forbidden:
                print(f"⚠️ Sem permissão para adicionar o cargo '{cargo_membro.name}' ({cargo_membro.id}) para {member}.")
            except Exception as e:
                print(f"⚠️ Erro ao adicionar cargo para {member}: {e}")
        else:
            print(f"⚠️ Cargo com ID {CARGO_MEMBRO_ID} não encontrado na guilda.")

        # 3. Salvar no banco de dados SQLite
        registro_id = None
        try:
            cursor = db.cursor()
            cursor.execute("""
                INSERT INTO registros (user_id, nome_ig, id_ig, recrutador_id, aprovado_por, status, data_registro, data_aprovacao)
                VALUES (?, ?, ?, 0, ?, 'aprovado', datetime('now', 'localtime'), datetime('now', 'localtime'))
            """, (member.id, nome, id_game, self.bot.user.id if self.bot.user else 0))
            db.commit()
            registro_id = cursor.lastrowid
        except Exception as e:
            print(f"⚠️ Erro ao salvar registro no banco de dados: {e}")

        # 4. Gerar e enviar log de Whitelist
        canal_log = self.bot.get_channel(CANAL_LOG_WL_ID)
        if not canal_log and CANAL_LOG_WL_ID:
            try:
                canal_log = await self.bot.fetch_channel(CANAL_LOG_WL_ID)
            except Exception:
                canal_log = None

        if canal_log:
            embed_log = discord.Embed(
                title="📋 Nova Whitelist Concluída",
                color=discord.Color.green(),
                timestamp=discord.utils.utcnow()
            )
            embed_log.set_thumbnail(url=member.display_avatar.url)
            embed_log.add_field(name="**👤 Membro**", value=f"{member.mention} (`{member.name}`)", inline=True)
            embed_log.add_field(name="**🆔 Discord ID**", value=f"`{member.id}`", inline=True)
            embed_log.add_field(name="**📝 Nome In-Game**", value=f"`{nome}`", inline=True)
            embed_log.add_field(name="**🎮 ID In-Game**", value=f"`{id_game}`", inline=True)

            status_nick = f"`{novo_nick}`" if nick_alterado else f"`{novo_nick}` *(Não alterado - hierarquia)*"
            embed_log.add_field(name="**🏷️ Apelido Definido**", value=status_nick, inline=True)

            if cargo_adicionado and cargo_membro:
                status_cargo = cargo_membro.mention
            elif cargo_membro:
                status_cargo = f"⚠️ Falha de permissão ({cargo_membro.mention})"
            else:
                status_cargo = f"⚠️ Cargo não encontrado (`{CARGO_MEMBRO_ID}`)"
            embed_log.add_field(name="**🎖️ Cargo Entregue**", value=status_cargo, inline=True)

            embed_log.add_field(name="**⚡ Liberação**", value="🟢 Automática (Sem aprovação)", inline=False)
            embed_log.set_footer(text=f"ID do Registro: #{registro_id if registro_id else 'N/A'} • Whitelist Automática")

            try:
                await canal_log.send(embed=embed_log)
            except Exception as e:
                print(f"⚠️ Erro ao enviar log no canal {CANAL_LOG_WL_ID}: {e}")

        # 5. Envia mensagem de aprovação exclusivamente no privado (DM) do usuário
        dm_enviada = False
        try:
            embed_dm = discord.Embed(
                title="🎉 Whitelist Aprovada com Sucesso!",
                description=(
                    f"Olá **{member.name}**, sua Whitelist no servidor **{interaction.guild.name}** foi confirmada!\n\n"
                    f"• **Apelido:** `{novo_nick}`\n"
                ),
                color=discord.Color.green(),
                timestamp=discord.utils.utcnow()
            )
            if cargo_adicionado and cargo_membro:
                embed_dm.description += f"• **Cargo:** **@{cargo_membro.name}** liberado com sucesso!\n"
            elif not cargo_membro:
                embed_dm.description += f"• ⚠️ *Cargo de membro (`{CARGO_MEMBRO_ID}`) não encontrado no servidor.*\n"
            elif not cargo_adicionado:
                embed_dm.description += f"• ⚠️ *Não foi possível adicionar o cargo automaticamente por permissões do bot.*\n"

            if msg_aviso_nick:
                embed_dm.description += f"\n{msg_aviso_nick}\n"

            embed_dm.description += "\nSeja bem-vindo(a) e divirta-se!"
            if interaction.guild.icon:
                embed_dm.set_thumbnail(url=interaction.guild.icon.url)
            embed_dm.set_footer(text=f"Servidor: {interaction.guild.name} • Whitelist Automática")

            await member.send(embed=embed_dm)
            dm_enviada = True
        except discord.Forbidden:
            print(f"⚠️ Não foi possível enviar DM para {member} ({member.id}) - mensagens privadas desativadas.")
        except Exception as e:
            print(f"⚠️ Erro ao enviar DM para {member}: {e}")

        # 6. Remove a resposta temporária do chat para não deixar mensagem de aprovação no canal
        try:
            if dm_enviada:
                await interaction.delete_original_response()
            else:
                # Se o privado estiver bloqueado, apenas avisa discretamente que a DM estava fechada
                await interaction.followup.send(
                    "⚠️ Sua Whitelist foi concluída, mas não foi possível enviar a confirmação no seu privado (DM fechada).",
                    ephemeral=True
                )
        except Exception:
            pass


# ============================================================
#  VIEW PERSISTENTE DO PAINEL
# ============================================================
class PainelView(View):
    def __init__(self, bot: commands.Bot):
        super().__init__(timeout=None)
        self.bot = bot

    @discord.ui.button(
        label="Iniciar Whitelist",
        style=discord.ButtonStyle.success,
        custom_id="btn_registro",
        emoji="📋"
    )
    async def registrar(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Abre diretamente o modal para o usuário preencher Nome e ID
        await interaction.response.send_modal(RegistroModal(bot=self.bot))

# ============================================================
#  COG PRINCIPAL DE WHITELIST
# ============================================================
class RegistroCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        # Registra a view persistente para que o botão funcione após reinicializações
        self.bot.add_view(PainelView(bot=self.bot))

    @app_commands.command(name="setup_painel", description="Configura o painel de Whitelist no canal definido.")
    @app_commands.default_permissions(administrator=True)
    async def setup_painel(self, interaction: discord.Interaction, canal: discord.TextChannel = None):
        """Configura o painel de Whitelist interativo no canal."""
        target_channel = canal or self.bot.get_channel(CANAL_REGISTRO_ID)
        if not target_channel:
            await interaction.response.send_message(
                f"❌ Canal de registro não encontrado. Verifique `CANAL_REGISTRO_ID` no seu `.env`.",
                ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True, thinking=True)

        try:
            await target_channel.purge(limit=100)
        except Exception:
            pass

        embed = discord.Embed(
            title="📋 Sistema de Whitelist",
            description=(
                "Seja bem-vindo(a) ao servidor de **fotografias** da valley!\n\n"
                "Para liberar seu acesso ao servidor, realize sua **Whitelist**:\n\n"
                "1️⃣ Clique no botão **Iniciar Whitelist** abaixo.\n"
                "2️⃣ Preencha seu **Nome In-Game** e seu **ID**.\n"
                "3️⃣ Envie o formulário para obter aprovação e ter os dados configurados!\n"
            ),
            color=0x2F4F4F
        )

        # Procura imagem na pasta 'imagens'
        imagens_dir = os.path.join(os.path.dirname(__file__), '..', 'imagens')
        arquivo_banner = None
        for nome_arq in ['painel_wl.png', 'painel_wl.jpg', 'painel_wl.jpeg', 'painel_wl.gif', 'wl.png', 'wl.jpg']:
            caminho = os.path.join(imagens_dir, nome_arq)
            if os.path.isfile(caminho):
                arquivo_banner = discord.File(caminho, filename=nome_arq)
                embed.set_image(url=f"attachment://{nome_arq}")
                break

        if arquivo_banner:
            await target_channel.send(embed=embed, file=arquivo_banner, view=PainelView(bot=self.bot))
        else:
            await target_channel.send(embed=embed, view=PainelView(bot=self.bot))
        await interaction.followup.send(f"✅ Painel de Whitelist configurado com sucesso em {target_channel.mention}!", ephemeral=True)

    @app_commands.command(name="verificar_config", description="[ADMIN] Verifica as configurações atuais de Whitelist.")
    @app_commands.default_permissions(administrator=True)
    async def verificar_config(self, interaction: discord.Interaction):
        """Exibe os canais e cargos configurados para a Whitelist."""
        await interaction.response.defer(ephemeral=True)

        canal_registro = self.bot.get_channel(CANAL_REGISTRO_ID)
        canal_log = self.bot.get_channel(CANAL_LOG_WL_ID)
        cargo_membro = interaction.guild.get_role(CARGO_MEMBRO_ID) if interaction.guild else None

        embed = discord.Embed(title="⚙️ Configurações da Whitelist", color=discord.Color.blue())
        embed.add_field(
            name="Canal de Início/Registro (`CANAL_REGISTRO_ID`)",
            value=f"{canal_registro.mention} (`{CANAL_REGISTRO_ID}`)" if canal_registro else f"❌ Não encontrado (`{CANAL_REGISTRO_ID}`)",
            inline=False
        )
        embed.add_field(
            name="Canal de Logs de Whitelist (`CANAL_LOG_WL_ID` / `CANAL_APROVACAO_ID`)",
            value=f"{canal_log.mention} (`{CANAL_LOG_WL_ID}`)" if canal_log else f"❌ Não encontrado (`{CANAL_LOG_WL_ID}`)",
            inline=False
        )
        embed.add_field(
            name="Cargo de Membro (`CARGO_MEMBRO_ID`)",
            value=f"{cargo_membro.mention} (`{CARGO_MEMBRO_ID}`)" if cargo_membro else f"❌ Não encontrado (`{CARGO_MEMBRO_ID}`)",
            inline=False
        )

        await interaction.followup.send(embed=embed, ephemeral=True)

    @app_commands.command(name="consultar_wl", description="[ADMIN] Consulta os dados de Whitelist de um usuário.")
    @app_commands.default_permissions(administrator=True)
    async def consultar_wl(self, interaction: discord.Interaction, membro: discord.Member):
        """Consulta o registro de um usuário pelo ID ou menção."""
        cursor = db.cursor()
        cursor.execute("""
            SELECT id, nome_ig, id_ig, status, data_registro
            FROM registros
            WHERE user_id = ?
            ORDER BY id DESC LIMIT 1
        """, (membro.id,))
        registro = cursor.fetchone()

        if not registro:
            return await interaction.response.send_message(f"❌ Nenhum registro de Whitelist encontrado para {membro.mention}.", ephemeral=True)

        reg_id, nome_ig, id_ig, status, data_reg = registro
        embed = discord.Embed(title="📋 Consulta de Whitelist", color=discord.Color.green())
        embed.set_thumbnail(url=membro.display_avatar.url)
        embed.add_field(name="Membro", value=membro.mention, inline=True)
        embed.add_field(name="Discord ID", value=f"`{membro.id}`", inline=True)
        embed.add_field(name="Nome In-Game", value=f"`{nome_ig}`", inline=True)
        embed.add_field(name="ID In-Game", value=f"`{id_ig}`", inline=True)
        embed.add_field(name="Status", value=f"`{status}`", inline=True)
        embed.add_field(name="Data do Registro", value=f"`{data_reg}`", inline=True)
        embed.set_footer(text=f"ID do Registro: #{reg_id}")

        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(RegistroCog(bot))