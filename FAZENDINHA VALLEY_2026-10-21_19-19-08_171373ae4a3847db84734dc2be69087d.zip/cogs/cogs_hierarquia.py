import discord
from discord.ext import commands, tasks
from discord import app_commands
import asyncio
from datetime import datetime, timezone
import json
import os
import pytz

# --- Configurações ---
ID_DO_CANAL_HIERARQUIA = int(os.getenv("ID_DO_CANAL_HIERARQUIA", 0))
CONFIG_FILE = "config_hierarquia.json"

# --- Funções de Gerenciamento da Configuração ---
def carregar_config():
    if not os.path.exists(CONFIG_FILE):
        return []
    try:
        with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, FileNotFoundError):
        return []

def salvar_config(config):
    with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=4)

# --- Classes da Interface ---
class AdicionarCargoModal(discord.ui.Modal, title="Adicionar Cargo à Hierarquia"):
    posicao = discord.ui.TextInput(
        label="Posição na Hierarquia",
        placeholder="Ex: 1 (para o topo), 2, 3...",
        style=discord.TextStyle.short,
        required=True
    )
    
    def __init__(self, role: discord.Role, parent_view: discord.ui.View):
        super().__init__()
        self.role = role
        self.parent_view = parent_view
        
    async def on_submit(self, interaction: discord.Interaction):
        try:
            pos = int(self.posicao.value)
            if pos < 1:
                await interaction.response.send_message("A posição deve ser um número maior que 0.", ephemeral=True)
                return
        except ValueError:
            await interaction.response.send_message("A posição deve ser um número válido.", ephemeral=True)
            return

        config = carregar_config()

        if any(c['id'] == self.role.id for c in config):
            await interaction.response.send_message(f"O cargo {self.role.mention} já está na hierarquia.", ephemeral=True)
            return

        novo_cargo = {"id": self.role.id, "titulo": self.role.name, "cor": self.role.color.value}
        config.insert(pos - 1, novo_cargo)

        salvar_config(config)
        await interaction.response.send_message(f"✅ Cargo {self.role.mention} adicionado na posição {pos}.", ephemeral=True)
        await self.parent_view.atualizar_embed()

class PainelConfigHierarquiaView(discord.ui.View):
    def __init__(self, bot: commands.Bot, *, timeout=300):
        super().__init__(timeout=timeout)
        self.bot = bot
        self.message: discord.Message = None

    async def atualizar_embed(self):
        embed = self.criar_embed_config(self.message.guild)
        await self.message.edit(embed=embed, view=self)

    def criar_embed_config(self, guild: discord.Guild):
        config = carregar_config()
        embed = discord.Embed(
            title="⚙️ Painel de Configuração da Hierarquia",
            description="Use os botões abaixo para gerenciar os cargos que aparecem no painel de hierarquia.",
            color=discord.Color.blue()
        )
        if not config:
            embed.add_field(name="Hierarquia Atual", value="*Nenhum cargo configurado ainda.*", inline=False)
        else:
            lista_cargos = ""
            for i, cargo_info in enumerate(config):
                role = guild.get_role(cargo_info['id'])
                lista_cargos += f"**{i+1}.** {role.mention if role else f'Cargo não encontrado (ID: {cargo_info["id"]})'}\n"
            embed.add_field(name="Ordem da Hierarquia", value=lista_cargos, inline=False)
        
        embed.set_footer(text="As mudanças são salvas automaticamente.")
        return embed

    @discord.ui.button(label="Adicionar Cargo", style=discord.ButtonStyle.success, emoji="➕", row=0)
    async def adicionar(self, interaction: discord.Interaction, button: discord.ui.Button):
        select_view = discord.ui.View(timeout=180)
        role_select = discord.ui.RoleSelect(placeholder="Selecione o cargo para adicionar...")

        async def select_callback(select_interaction: discord.Interaction):
            selected_role_id = int(select_interaction.data['values'][0])
            role_obj = select_interaction.guild.get_role(selected_role_id)
            if not role_obj:
                await select_interaction.response.send_message("Erro: O cargo selecionado não foi encontrado.", ephemeral=True)
                return
            modal = AdicionarCargoModal(role=role_obj, parent_view=self)
            await select_interaction.response.send_modal(modal)

        role_select.callback = select_callback
        select_view.add_item(role_select)
        await interaction.response.send_message("Qual cargo você deseja adicionar à hierarquia?", view=select_view, ephemeral=True)

    @discord.ui.button(label="Remover Cargo", style=discord.ButtonStyle.danger, emoji="🗑️", row=0)
    async def remover(self, interaction: discord.Interaction, button: discord.ui.Button):
        config = carregar_config()
        if not config:
            await interaction.response.send_message("A hierarquia está vazia. Não há cargos para remover.", ephemeral=True)
            return
        
        options = [
            discord.SelectOption(label=f"{(i+1):02d}. {role.name if (role := interaction.guild.get_role(c['id'])) else f'ID: {c["id"]}'}", 
                                 value=str(c['id']))
            for i, c in enumerate(config)
        ]
        select = discord.ui.Select(placeholder="Selecione o cargo para remover...", options=options, max_values=len(options))

        async def remover_callback(select_interaction: discord.Interaction):
            ids_para_remover = {int(v) for v in select_interaction.data['values']}
            nova_config = [c for c in carregar_config() if c['id'] not in ids_para_remover]
            salvar_config(nova_config)
            await select_interaction.response.send_message(f"✅ {len(ids_para_remover)} cargo(s) removido(s) com sucesso.", ephemeral=True)
            await self.atualizar_embed()

        select.callback = remover_callback
        view_remover = discord.ui.View(timeout=180)
        view_remover.add_item(select)
        await interaction.response.send_message("Selecione os cargos que deseja remover da hierarquia:", view=view_remover, ephemeral=True)

    @discord.ui.button(label="Finalizar e Atualizar Painel", style=discord.ButtonStyle.primary, emoji="🚀", row=1)
    async def finalizar_e_atualizar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True, thinking=True)
        await self.cog.atualizar_painel_hierarquia()
        await interaction.followup.send("✅ O painel de hierarquia principal foi atualizado com sucesso!", ephemeral=True)


class HierarquiaCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.loop_hierarquia.start()

    def cog_unload(self):
        self.loop_hierarquia.cancel()

    async def atualizar_painel_hierarquia(self):
        try:
            channel = await self.bot.fetch_channel(ID_DO_CANAL_HIERARQUIA)
        except Exception as e:
            print(f" ERRO CRÍTICO: Não foi possível acessar o canal ID {ID_DO_CANAL_HIERARQUIA}. Detalhe: {e}")
            return

        try:
            await channel.purge(limit=30)
        except discord.Forbidden:
            print(f"ERRO: O bot não tem permissão para 'Gerenciar Mensagens' no canal {channel.name}.")
        
        cargos_config = carregar_config()
        fuso_horario_py = pytz.timezone('America/Asuncion')
        data_hoje = datetime.now(fuso_horario_py).strftime("%d/%m/%Y às %H:%M")
        membros_ja_exibidos = set()
        guild = channel.guild

        for config in cargos_config:
            role = guild.get_role(config["id"])
            if not role:
                continue

            membros_para_exibir = [m for m in role.members if not m.bot and m.id not in membros_ja_exibidos]
            membros_ja_exibidos.update(m.id for m in membros_para_exibir)

            lista_membros = "\n".join(f"• {m.mention}" for m in membros_para_exibir) or "• *Nenhum membro neste cargo.*"
            
            cor = role.color if role.color.value != 0 else 0x99aab5
            embed = discord.Embed(description=f"## {role.name}\n\n{lista_membros}", color=cor)
            
            LINK_DO_GIF = "https://files.catbox.moe/71gbst.gif"
            embed.set_footer(text=f"Total: {len(membros_para_exibir)} membros   |   Atualizado automaticamente dia: {data_hoje}", icon_url=LINK_DO_GIF)
            
            if role.icon:
                embed.set_thumbnail(url=role.icon.url)

            await channel.send(embed=embed)
            await asyncio.sleep(1)

        print(f"Hierarquia atualizada com sucesso em {data_hoje}")

    @tasks.loop(minutes=60)
    async def loop_hierarquia(self):
        await self.atualizar_painel_hierarquia()

    @loop_hierarquia.before_loop
    async def before_loop_hierarquia(self):
        await self.bot.wait_until_ready()

    @app_commands.command(name="atualizar", description="Força a atualização do painel de hierarquia.")
    @app_commands.default_permissions(administrator=True)
    async def atualizar(self, interaction: discord.Interaction):
        """Comando manual para atualizar a hierarquia agora."""
        await interaction.response.send_message("**Iniciando atualização da Hierarquia...**", ephemeral=True)
        await self.atualizar_painel_hierarquia()
        await interaction.followup.send("**Hierarquia Atualizada com sucesso!**", ephemeral=True)

    @app_commands.command(name="painel_config", description="Exibe o painel para configurar a hierarquia de cargos.")
    @app_commands.default_permissions(administrator=True)
    async def painel_config(self, interaction: discord.Interaction):
        """Exibe o painel interativo para configurar a hierarquia."""
        view = PainelConfigHierarquiaView(bot=self.bot)
        view.cog = self # Passa a referência do cog para a view
        embed = view.criar_embed_config(interaction.guild)
        # Envia a mensagem no canal, visível para todos os administradores
        await interaction.response.send_message(embed=embed, view=view)
        message = await interaction.original_response()
        view.message = message

async def setup(bot: commands.Bot):
    await bot.add_cog(HierarquiaCog(bot))