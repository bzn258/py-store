import discord
from discord.ext import commands, tasks
from discord import app_commands
from discord.interactions import Interaction
from discord.ui import Select, View, Modal, TextInput
import sqlite3
import os
from datetime import datetime
import pytz

# ============================================================
#  CONFIGURAÇÕES (Lidas do .env pelo main.py)
# ============================================================
CANAL_REGISTRO_ID   = int(os.getenv("CANAL_REGISTRO_ID", 0))
CANAL_APROVACAO_ID  = int(os.getenv("CANAL_APROVACAO_ID", 0))

# Carrega a lista de cargos de recrutador, separados por vírgula no .env
CARGOS_RECRUTADOR_IDS_STR = os.getenv("CARGOS_RECRUTADOR_IDS", os.getenv("CARGO_RECRUTADOR_ID", "")) # Compatibilidade com a variável antiga
CARGOS_RECRUTADOR_IDS = [int(role_id.strip()) for role_id in CARGOS_RECRUTADOR_IDS_STR.split(',') if role_id.strip().isdigit()]

CANAL_RANKING_ID    = int(os.getenv("CANAL_RANKING_ID", 0))
CARGO_MEMBRO_ID     = int(os.getenv("CARGO_MEMBRO_ID", 0))

# Novas configs para pagamento de recrutamento
CANAL_RECRUTAMENTO_PAGAMENTOS_ID = int(os.getenv("CANAL_RECRUTAMENTO_PAGAMENTOS_ID", 0))
VALOR_POR_RECRUTAMENTO = float(os.getenv("VALOR_POR_RECRUTAMENTO", 0))

CARGOS_PAGADOR_IDS_STR = os.getenv("CARGOS_PAGADOR_IDS", os.getenv("CARGO_PAGADOR_ID", ""))
CARGOS_PAGADOR_IDS = [int(role_id.strip()) for role_id in CARGOS_PAGADOR_IDS_STR.split(',') if role_id.strip().isdigit()]

# ── Banco de Dados ──
db_path = os.path.join(os.path.dirname(__file__), '..', 'registro.db') # Aponta para a pasta raiz
db = sqlite3.connect(db_path)
db.execute("""
    CREATE TABLE IF NOT EXISTS registros (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id       INTEGER NOT NULL,
        nome_ig       TEXT NOT NULL,
        id_ig         TEXT NOT NULL,
        recrutador_id INTEGER NOT NULL,
        aprovado_por  INTEGER,
        status        TEXT NOT NULL DEFAULT 'pendente', -- pendente, aprovado, recusado
        data_registro TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
        data_aprovacao TEXT,
        motivo_recusa TEXT
    )
""")
db.commit()
db.execute("""
    CREATE TABLE IF NOT EXISTS recrutamento_pagamentos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        registro_id INTEGER NOT NULL,
        recrutador_id INTEGER NOT NULL,
        recrutado_id INTEGER NOT NULL,
        valor_pago REAL,
        status TEXT NOT NULL DEFAULT 'pendente', -- pendente, pago, recusado
        data_submissao TEXT NOT NULL,
        pago_por_id INTEGER,
        data_pagamento TEXT,
        motivo_recusa TEXT,
        FOREIGN KEY(registro_id) REFERENCES registros(id)
    )
""")
db.commit()

# ============================================================
#  CLASSES DA UI (VIEWS, MODALS, SELECTS)
#  Não precisam estar dentro do Cog, mas podem se preferir.
#  Deixá-las fora simplifica as referências.
# ============================================================

class RegistroModal(Modal, title="📋 Registro"):
    nome_ig  = TextInput(label="Qual seu nome? (In Game)", placeholder="Ex: João Silva", max_length=50)
    id_ig    = TextInput(label="Qual seu ID?", placeholder="Ex: 1234", max_length=10)

    def __init__(self, recrutador_id: int, bot: commands.Bot):
        super().__init__()
        self.recrutador_id = recrutador_id
        self.bot = bot

    async def on_submit(self, interaction: discord.Interaction):
        canal_aprovacao = self.bot.get_channel(CANAL_APROVACAO_ID)
        if not canal_aprovacao:
            await interaction.response.send_message("❌ Canal de aprovação não encontrado. Avise um administrador.", ephemeral=True)
            return

        cursor = db.cursor()
        cursor.execute("INSERT INTO registros (user_id, nome_ig, id_ig, recrutador_id) VALUES (?, ?, ?, ?)",
                       (interaction.user.id, self.nome_ig.value, self.id_ig.value, self.recrutador_id))
        db.commit()
        registro_id = cursor.lastrowid

        embed = discord.Embed(title="📋 Novo Pedido de Registro", color=discord.Color.gold())
        embed.set_footer(text=f"ID do Registro: {registro_id}")
        embed.add_field(name="**👤 SOLICITANTE**", value=f"{interaction.user.mention} (ID: {interaction.user.id})", inline=False)
        embed.add_field(name="**📝 DADOS**", value=f"Nome: {self.nome_ig.value}\nID: {self.id_ig.value}", inline=False)
        embed.add_field(name="**🤝 RECRUTADOR**", value=f"<@{self.recrutador_id}>", inline=False)
        embed.add_field(name="**STATUS**", value="🟡 Aguardando análise.", inline=False)

        view = View()
        view.add_item(discord.ui.Button(style=discord.ButtonStyle.success, label="Aprovar", emoji="✅", custom_id=f"aprovar_{registro_id}"))
        view.add_item(discord.ui.Button(style=discord.ButtonStyle.danger, label="Recusar", emoji="❌", custom_id=f"recusar_{registro_id}"))

        await canal_aprovacao.send(embed=embed, view=view)
        await interaction.response.send_message("✅ Solicitação enviada! Aguarde a aprovação de um recrutador.", ephemeral=True)

class RecusaModal(Modal, title="❌ Recusar Registro"):
    motivo = TextInput(label="Motivo da recusa", style=discord.TextStyle.paragraph, placeholder="Ex: Nome ou ID inválido.", required=True, max_length=200)

    def __init__(self, registro_id: int):
        super().__init__()
        self.registro_id = registro_id

    async def on_submit(self, interaction: discord.Interaction):
        db.execute("UPDATE registros SET status = 'recusado', motivo_recusa = ? WHERE id = ?", (self.motivo.value, self.registro_id))
        db.commit()

        view = View.from_message(interaction.message)
        for item in view.children:
            item.disabled = True

        cursor = db.cursor()
        cursor.execute("SELECT user_id FROM registros WHERE id = ?", (self.registro_id,))
        registro = cursor.fetchone()
        solicitante_id = registro[0]

        embed_recusado = discord.Embed(title="❌ Pedido de Registro — Recusado", color=discord.Color.red())
        embed_recusado.set_footer(text=f"ID do Registro: {self.registro_id}")
        embed_recusado.add_field(name="**👤 SOLICITANTE**", value=f"<@{solicitante_id}> (ID: {solicitante_id})", inline=False)
        embed_recusado.add_field(name="**🚫 RECUSADO POR**", value=f"{interaction.user.mention}", inline=False)
        embed_recusado.add_field(name="**📄 MOTIVO**", value=self.motivo.value, inline=False)
        embed_recusado.add_field(name="**STATUS**", value="🔴 Recusado pela staff.", inline=False)

        await interaction.response.edit_message(embed=embed_recusado, view=view)

        try:
            membro = await interaction.guild.fetch_member(solicitante_id)
            if membro:
                await membro.send(f"❌ Seu registro foi **recusado**.\n**Motivo:** {self.motivo.value}")
        except discord.NotFound:
            print(f"Não foi possível encontrar o membro {solicitante_id} para notificar sobre a recusa.")
        except discord.Forbidden:
            print(f"Não foi possível enviar DM para o membro {solicitante_id} sobre a recusa do registro {self.registro_id}.")

class RecrutadorSelect(Select):
    def __init__(self, opcoes, bot: commands.Bot):
        super().__init__(placeholder="Selecione quem te recrutou...", min_values=1, max_values=1, options=opcoes)
        self.bot = bot

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.send_modal(RegistroModal(recrutador_id=int(self.values[0]), bot=self.bot))

class RecrutadorView(View):
    def __init__(self, opcoes, bot: commands.Bot):
        super().__init__(timeout=120)
        self.add_item(RecrutadorSelect(opcoes, bot))

class PainelView(View):
    def __init__(self, bot: commands.Bot):
        super().__init__(timeout=None)
        self.bot = bot

    @discord.ui.button(label="Registrar", style=discord.ButtonStyle.secondary, custom_id="btn_registro", emoji="📋")
    async def registrar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not CARGOS_RECRUTADOR_IDS:
            await interaction.response.send_message("❌ Nenhum cargo de recrutador foi configurado. Avise um administrador.", ephemeral=True)
            return

        guild = interaction.guild
        membros_recrutadores = set() # Usamos um set para evitar duplicatas

        for cargo_id in CARGOS_RECRUTADOR_IDS:
            cargo = guild.get_role(cargo_id)
            if cargo:
                for membro in cargo.members:
                    if not membro.bot: # Garante que bots não apareçam na lista
                        membros_recrutadores.add(membro)

        if not membros_recrutadores:
            await interaction.response.send_message("❌ Nenhum recrutador encontrado. Avise um administrador.", ephemeral=True)
            return

        # Ordena os membros por nome para uma lista mais organizada
        membros_ordenados = sorted(list(membros_recrutadores), key=lambda m: m.display_name)
        opcoes = [discord.SelectOption(label=m.display_name, value=str(m.id)) for m in membros_ordenados[:25]]
        await interaction.response.send_message("👇 Selecione o recrutador que te trouxe:", view=RecrutadorView(opcoes, self.bot), ephemeral=True)

class RecusarRecrutamentoModal(Modal, title="Recusar Pagamento de Recrutamento"):
    motivo = TextInput(label="Motivo da Recusa", style=discord.TextStyle.paragraph, placeholder="Ex: Recrutamento fraudulento, etc.", required=True)

    async def on_submit(self, interaction: discord.Interaction):
        pagamento_id = int(interaction.message.embeds[0].footer.text.split(': ')[1])
        
        db.execute("UPDATE recrutamento_pagamentos SET status = 'recusado', motivo_recusa = ? WHERE id = ?", (self.motivo.value, pagamento_id))
        db.commit()

        cursor = db.cursor()
        cursor.execute("SELECT recrutador_id FROM recrutamento_pagamentos WHERE id = ?", (pagamento_id,))
        recrutador_id = cursor.fetchone()[0]

        embed = interaction.message.embeds[0]
        embed.title = "❌ Pagamento de Recrutamento Recusado"
        embed.color = discord.Color.red()
        embed.add_field(name="Recusado por", value=interaction.user.mention, inline=False)
        embed.add_field(name="Motivo", value=self.motivo.value, inline=False)

        view = View.from_message(interaction.message)
        for item in view.children: item.disabled = True
        await interaction.response.edit_message(embed=embed, view=view)

        try:
            recrutador = await interaction.guild.fetch_member(recrutador_id)
            await recrutador.send(f"Seu pagamento por um recrutamento foi **recusado**.\n**Motivo:** {self.motivo.value}")
        except (discord.NotFound, discord.Forbidden):
            pass

class PagamentoRecrutamentoView(View):
    def __init__(self):
        super().__init__(timeout=None)

    def tem_permissao(self, interaction: discord.Interaction) -> bool:
        if not CARGOS_PAGADOR_IDS: return False
        user_role_ids = {role.id for role in interaction.user.roles}
        return not user_role_ids.isdisjoint(CARGOS_PAGADOR_IDS)

    @discord.ui.button(label="Realizar Pagamento", style=discord.ButtonStyle.success, emoji="✅", custom_id="pagamento_recrutamento_pagar")
    async def pagar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.tem_permissao(interaction):
            return await interaction.response.send_message("❌ Você não tem permissão para realizar pagamentos.", ephemeral=True)

        await interaction.response.defer()

        embed = interaction.message.embeds[0]
        pagamento_id = int(embed.footer.text.split(': ')[1])

        # Ignora o valor no embed e usa a variável de ambiente atual para garantir o valor correto.
        valor_pago = VALOR_POR_RECRUTAMENTO

        db.execute("UPDATE recrutamento_pagamentos SET status = 'pago', valor_pago = ?, pago_por_id = ?, data_pagamento = ? WHERE id = ?",
                   (valor_pago, interaction.user.id, datetime.now().isoformat(), pagamento_id))
        db.commit()

        cursor = db.cursor()
        cursor.execute("SELECT recrutador_id, recrutado_id FROM recrutamento_pagamentos WHERE id = ?", (pagamento_id,))
        recrutador_id, recrutado_id = cursor.fetchone()

        embed.title = "✅ Pagamento de Recrutamento Realizado"
        embed.color = discord.Color.green()
        embed.add_field(name="Pago por", value=interaction.user.mention, inline=False)

        self.clear_items()
        await interaction.edit_original_response(embed=embed, view=self)

        try:
            recrutador = await interaction.guild.fetch_member(recrutador_id)
            recrutado = await interaction.guild.fetch_member(recrutado_id)
            valor_formatado_dm = f"R$ {int(valor_pago):,}".replace(',', '.')
            await recrutador.send(f"Seu pagamento pelo recrutamento de **{recrutado.display_name}** foi realizado!\n**Valor:** {valor_formatado_dm}")
        except (discord.NotFound, discord.Forbidden):
            pass

    @discord.ui.button(label="Recusar", style=discord.ButtonStyle.danger, emoji="❌", custom_id="pagamento_recrutamento_recusar")
    async def recusar(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.tem_permissao(interaction):
            return await interaction.response.send_message("❌ Você não tem permissão para recusar pagamentos.", ephemeral=True)
        await interaction.response.send_modal(RecusarRecrutamentoModal())


async def gerar_log_pagamento_rec(bot: commands.Bot, registro_id: int, recrutador_id: int, recrutado_id: int):
    canal_pagamentos = bot.get_channel(CANAL_RECRUTAMENTO_PAGAMENTOS_ID)
    if not canal_pagamentos: return

    cursor = db.cursor()
    cursor.execute("INSERT INTO recrutamento_pagamentos (registro_id, recrutador_id, recrutado_id, data_submissao) VALUES (?, ?, ?, ?)",
                   (registro_id, recrutador_id, recrutado_id, datetime.now().isoformat()))
    db.commit()
    pagamento_id = cursor.lastrowid

    recrutador = await bot.fetch_user(recrutador_id)
    recrutado = await bot.fetch_user(recrutado_id)
    valor_formatado = f"R$ {int(VALOR_POR_RECRUTAMENTO):,}".replace(',', '.')

    embed = discord.Embed(title="💰 Novo Pagamento de Recrutamento", color=discord.Color.blue())
    embed.add_field(name="Recrutador", value=recrutador.mention, inline=True)
    embed.add_field(name="Recrutado", value=recrutado.mention, inline=True)
    embed.add_field(name="💸 Valor a Pagar", value=f"**{valor_formatado}**", inline=False)
    embed.set_footer(text=f"ID do Pagamento: {pagamento_id}")

    await canal_pagamentos.send(embed=embed, view=PagamentoRecrutamentoView())

# ============================================================
#  O COG PRINCIPAL
# ============================================================
class RegistroCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        # Adiciona as views persistentes quando o cog é carregado
        self.bot.add_view(PainelView(bot=self.bot))
        self.bot.add_view(PagamentoRecrutamentoView())

    async def get_ranking_embed(self, limit: int = 10):
        cursor = db.cursor()
        cursor.execute("""
            SELECT recrutador_id, COUNT(*) as total
            FROM registros
            WHERE status = 'aprovado'
            GROUP BY recrutador_id
            ORDER BY total DESC
        """)
        ranking_data = cursor.fetchall()

        title = "🏆 Ranking de Recrutadores (Top 10)" if limit == 10 and len(ranking_data) > 10 else "🏆 Ranking de Recrutadores (Completo)"
        embed = discord.Embed(title=title, color=discord.Color.gold())

        if not ranking_data:
            embed.description = "Ainda não há recrutamentos aprovados."
            return embed

        description = ""
        for i, (recrutador_id, total) in enumerate(ranking_data[:limit]):
            rank_emoji = {0: "🥇", 1: "🥈", 2: "🥉"}.get(i, f"**{i+1}.**")
            try:
                user = await self.bot.fetch_user(recrutador_id)
                description += f"{rank_emoji} {user.mention} - **{total}** recrutamento(s)\n"
            except discord.NotFound:
                description += f"{rank_emoji} `ID: {recrutador_id}` (usuário não encontrado) - **{total}** recrutamento(s)\n"

        embed.description = description
        fuso_horario_py = pytz.timezone('America/Asuncion')
        hora_atual_py = discord.utils.utcnow().astimezone(fuso_horario_py)
        embed.set_footer(text=f"Última atualização: {hora_atual_py.strftime('%d/%m/%Y %H:%M:%S')}")
        return embed
    
    async def atualizar_painel_ranking(self):
        """Encontra e atualiza a mensagem do painel de ranking."""
        if not CANAL_RANKING_ID:
            print("⚠️ CANAL_RANKING_ID não configurado. A atualização automática do ranking está desativada.")
            return

        try:
            channel = await self.bot.fetch_channel(CANAL_RANKING_ID)
        except (discord.NotFound, discord.Forbidden):
            print(f"❌ Erro: Não foi possível encontrar ou acessar o canal de ranking com ID {CANAL_RANKING_ID}.")
            return

        # Procura por uma mensagem de ranking existente para editar
        async for message in channel.history(limit=50):
            if message.author == self.bot.user and message.embeds and "Ranking de Recrutadores" in message.embeds[0].title:
                embed = await self.get_ranking_embed(limit=10)
                await message.edit(embed=embed, view=None) # Remove a view antiga
                print(f"✅ Painel de ranking de recrutadores editado no canal {channel.name}.")
                return
        
        # Se não encontrou, envia um novo
        embed = await self.get_ranking_embed(limit=10)
        await channel.send(embed=embed, view=None)
        print(f"✅ Novo painel de ranking de recrutadores enviado para o canal {channel.name}.")


    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):
        if interaction.type != discord.InteractionType.component:
            return

        custom_id = interaction.data.get("custom_id", "")

        # ── Aprovar ──
        if custom_id.startswith("aprovar_"):
            await interaction.response.defer()

            # Verificação de permissão para aprovar
            user_role_ids = {role.id for role in interaction.user.roles}
            if not user_role_ids.isdisjoint(CARGOS_RECRUTADOR_IDS):
                pass # O usuário tem um dos cargos, pode continuar
            else:
                return await interaction.followup.send("❌ Você não tem permissão para aprovar registros.", ephemeral=True)

            registro_id = int(custom_id.split("_")[1])

            view = View.from_message(interaction.message)
            for item in view.children:
                item.disabled = True

            cursor = db.cursor()
            cursor.execute("SELECT user_id, nome_ig, id_ig, recrutador_id FROM registros WHERE id = ?", (registro_id,))
            registro = cursor.fetchone()

            if not registro:
                await interaction.followup.send("❌ Registro não encontrado no banco de dados.", ephemeral=True)
                return

            solicitante_id, nome_ig, id_ig, recrutador_id = registro
            try:
                membro = await interaction.guild.fetch_member(solicitante_id)
            except discord.NotFound:
                membro = None

            if not membro:
                await interaction.followup.send("❌ Membro não encontrado no servidor. Ele pode ter saído.", ephemeral=True)
                return

            novo_nick = f"{nome_ig} | {id_ig}"
            try:
                await membro.edit(nick=novo_nick)
            except discord.Forbidden:
                await interaction.channel.send(f"⚠️ Sem permissão para renomear {membro.mention}.", silent=True)

            cargo_membro = interaction.guild.get_role(CARGO_MEMBRO_ID)
            if cargo_membro:
                try:
                    await membro.add_roles(cargo_membro)
                except discord.Forbidden:
                    await interaction.followup.send("⚠️ Sem permissão para adicionar cargo.", ephemeral=True)
                    return

            db.execute("""
                UPDATE registros
                SET status = 'aprovado', aprovado_por = ?, data_aprovacao = datetime('now', 'localtime')
                WHERE id = ?
            """, (interaction.user.id, registro_id))
            db.commit()

            recrutador_field = interaction.message.embeds[0].fields[2].value
            embed_aprovado = discord.Embed(title="✅ Pedido de Registro — Aprovado", color=discord.Color.green())
            embed_aprovado.set_footer(text=f"ID do Registro: {registro_id}")
            embed_aprovado.add_field(name="**👤 SOLICITANTE**", value=f"{membro.mention} (ID: `{membro.id}`)", inline=False)
            embed_aprovado.add_field(name="**📝 DADOS**", value=f"Nome: `{nome_ig}`\nID: `{id_ig}`", inline=False)
            embed_aprovado.add_field(name="**🤝 RECRUTADOR**", value=recrutador_field, inline=False)
            embed_aprovado.add_field(name="**✅ APROVADO POR**", value=f"{interaction.user.mention}", inline=False)
            embed_aprovado.add_field(name="**STATUS**", value="🟢 Aprovado por um recrutador.", inline=False)

            await interaction.edit_original_response(embed=embed_aprovado, view=view)

            try:
                await membro.send(f"🎉 Parabéns! Seu registro foi **aprovado**.\nSeu nick foi definido como: `{novo_nick}`")
            except discord.Forbidden:
                print(f"Não foi possível enviar DM para {membro.name}.")
            
            # Gera o log de pagamento para o recrutador
            await gerar_log_pagamento_rec(self.bot, registro_id, recrutador_id, solicitante_id)

            # Atualiza o painel de ranking
            await self.atualizar_painel_ranking()
            return

        # ── Recusar ──
        if custom_id.startswith("recusar_"):
            # Verificação de permissão para recusar
            user_role_ids = {role.id for role in interaction.user.roles}
            if not user_role_ids.isdisjoint(CARGOS_RECRUTADOR_IDS):
                pass # O usuário tem um dos cargos, pode continuar
            else:
                return await interaction.response.send_message("❌ Você não tem permissão para recusar registros.", ephemeral=True)

            registro_id = int(custom_id.split("_")[1])
            await interaction.response.send_modal(RecusaModal(registro_id=registro_id))
            
    @app_commands.command(name="ranking", description="Exibe o painel com o ranking de recrutadores.")
    @app_commands.default_permissions(administrator=True)
    async def ranking(self, interaction: discord.Interaction, canal: discord.TextChannel = None):
        """Configura o painel com o ranking de recrutadores em um canal."""
        target_channel = canal or self.bot.get_channel(CANAL_RANKING_ID)
        if not target_channel:
            await interaction.response.send_message(
                "❌ Por favor, especifique um canal ou defina `CANAL_RANKING_ID` no seu arquivo de configuração.",
                ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True, thinking=True)
        embed = await self.get_ranking_embed(limit=10)
        await target_channel.send(embed=embed, view=None)
        await interaction.followup.send(f"✅ Painel de ranking configurado com sucesso em {target_channel.mention}!")

    @app_commands.command(name="rec_ranking_completo", description="[ADMIN] Mostra o ranking de recrutamento completo.")
    @app_commands.default_permissions(administrator=True)
    async def rec_ranking_completo(self, interaction: discord.Interaction):
        if interaction.channel_id != CANAL_RANKING_ID:
            return await interaction.response.send_message(f"❌ Este comando só pode ser usado no canal de ranking de recrutamento.", ephemeral=True)
        
        await interaction.response.defer(ephemeral=True)
        full_ranking_embed = await self.get_ranking_embed(limit=None)
        await interaction.followup.send(embed=full_ranking_embed, ephemeral=True)

    @app_commands.command(name="rec_resetar_ranking", description="[ADMIN] Reseta todos os dados do ranking de recrutamento.")
    @app_commands.default_permissions(administrator=True)
    async def rec_resetar_ranking(self, interaction: discord.Interaction):
        if interaction.channel_id != CANAL_RANKING_ID:
            return await interaction.response.send_message(f"❌ Este comando só pode ser usado no canal de ranking de recrutamento.", ephemeral=True)

        # Adiciona um modal de confirmação para segurança
        class ConfirmResetView(View):
            def __init__(self, cog_instance):
                super().__init__(timeout=60)
                self.cog = cog_instance

            @discord.ui.button(label="CONFIRMAR RESET", style=discord.ButtonStyle.danger)
            async def confirm(self, confirm_interaction: discord.Interaction, button: discord.ui.Button):
                db.execute("DELETE FROM registros")
                db.commit()
                await self.cog.atualizar_painel_ranking()
                await confirm_interaction.response.send_message("✅ Ranking de recrutamento resetado com sucesso!", ephemeral=True)
                self.stop()

        await interaction.response.send_message(
            "**⚠️ ATENÇÃO!** Você está prestes a apagar **TODOS** os registros de recrutamento. Esta ação é irreversível.",
            view=ConfirmResetView(self), ephemeral=True)

    @app_commands.command(name="setup_painel", description="Configura o painel de registro no canal definido.")
    @app_commands.default_permissions(administrator=True)
    async def setup_painel(self, interaction: discord.Interaction):
        """Configura o painel de registro no canal."""
        canal = self.bot.get_channel(CANAL_REGISTRO_ID)
        if not canal:
            await interaction.response.send_message("❌ Canal de registro não encontrado. Verifique `CANAL_REGISTRO_ID`.", ephemeral=True)
            return

        await interaction.response.defer(ephemeral=True, thinking=True)
        
        await canal.purge(limit=100)

        embed = discord.Embed(
            title="📋 Sistema de Registro da **Fazendinha**",
            description="*Clique no botão abaixo para realizar seu **registro**.\n*Após o registro, aguarde a aprovação de um recrutador para receber seu cargo e ter acesso completo ao servidor.",
            color=0x2F4F4F
        )
        embed.set_image(url="https://cdn.discordapp.com/attachments/1534329462189981716/1536690515473469460/Captura_de_tela_2026-08-03_234740.png?ex=6a7c5211&is=6a7b0091&hm=0d26024002fa0aba34693ba40787817a8f864db43e722b675fa6f4944414fe13&")

        await canal.send(embed=embed, view=PainelView(bot=self.bot))
        await interaction.followup.send(f"✅ Painel de registro configurado com sucesso no canal {canal.mention}!", ephemeral=True)

    @app_commands.command(name="verificar_config", description="[ADMIN] Verifica os valores de configuração atuais do bot.")
    @app_commands.default_permissions(administrator=True)
    async def verificar_config(self, interaction: discord.Interaction):
        """Exibe os valores das variáveis de ambiente importantes que o bot está usando."""
        await interaction.response.defer(ephemeral=True)

        valor_recrutamento_atual = f"R$ {int(VALOR_POR_RECRUTAMENTO):,}".replace(',', '.')

        embed = discord.Embed(title="⚙️ Verificação de Configuração em Tempo Real", color=discord.Color.orange())
        embed.add_field(name="Valor por Recrutamento", value=f"`{valor_recrutamento_atual}`", inline=False)
        embed.set_footer(text="Estes são os valores que o bot está usando neste exato momento.")

        await interaction.followup.send(embed=embed, ephemeral=True)

async def setup(bot: commands.Bot):
    await bot.add_cog(RegistroCog(bot))