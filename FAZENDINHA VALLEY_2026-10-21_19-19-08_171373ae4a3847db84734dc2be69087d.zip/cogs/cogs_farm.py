import discord
from discord.ext import commands
from discord import app_commands, ui
import os
import sqlite3
from datetime import datetime
import asyncio
import math

import json
# --- Configurações (Lidas do .env) ---
CANAL_FARM_PAINEL_ID = int(os.getenv("CANAL_FARM_PAINEL_ID", 0))
CANAL_FARM_PAGAMENTOS_ID = int(os.getenv("CANAL_FARM_PAGAMENTOS_ID", 0))
CANAL_PROVAS_ID = int(os.getenv("CANAL_PROVAS_ID", 0)) # NOVO: Canal para armazenar as provas
CANAL_FARM_RANKING_ID = int(os.getenv("CANAL_FARM_RANKING_ID", 0))

# Carrega a lista de cargos que podem pagar, separados por vírgula no .env
CARGOS_PAGADOR_IDS_STR = os.getenv("CARGOS_PAGADOR_IDS", os.getenv("CARGO_PAGADOR_ID", "")) # Compatibilidade com a variável antiga
CARGOS_PAGADOR_IDS = [int(role_id.strip()) for role_id in CARGOS_PAGADOR_IDS_STR.split(',') if role_id.strip().isdigit()]

VALOR_POR_ROTA_FARM = float(os.getenv("VALOR_POR_ROTA_FARM", 250000)) # Valor padrão de 250k se não definido


# Carrega a tabela de preços do .env
FARM_PRICES_STR = os.getenv("FARM_PRICES", "{}")
try:
    FARM_PRICES = json.loads(FARM_PRICES_STR.lower())
except json.JSONDecodeError:
    print("ERRO CRÍTICO: A variável 'FARM_PRICES' no arquivo .env não é um JSON válido.")
    FARM_PRICES = {}

# --- Banco de Dados ---
db_path = os.path.join(os.path.dirname(__file__), '..', 'registro.db')
db = sqlite3.connect(db_path)
db.execute("""
    CREATE TABLE IF NOT EXISTS farm_entregas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        item TEXT NOT NULL,
        quantidade INTEGER NOT NULL,
        valor_pago REAL,
        status TEXT NOT NULL DEFAULT 'pendente', -- pendente, pago, recusado
        data_submissao TEXT NOT NULL,
        pago_por_id INTEGER,
        data_pagamento TEXT,
        motivo_recusa TEXT,
        prova_url TEXT
    )
""")
db.commit()

# --- Modals (Formulários) ---

class FarmQuantidadeModal(ui.Modal):
    """Pede a quantidade e inicia o processo de espera pela prova."""
    quantidade_input = ui.TextInput(label="Quantidade Entregue", placeholder="Ex: 850", required=True)

    def __init__(self, item_selecionado: str, bot: commands.Bot):
        super().__init__(title=f"Entregar: {item_selecionado.capitalize()}")
        self.item_selecionado = item_selecionado
        self.bot = bot

    async def on_submit(self, interaction: discord.Interaction):
        try:
            quantidade = int(self.quantidade_input.value)
            if quantidade <= 0:
                raise ValueError("Quantidade deve ser positiva.")
        except ValueError:
            return await interaction.response.send_message("❌ A quantidade deve ser um número inteiro positivo.", ephemeral=True)

        if quantidade < 450:
            return await interaction.response.send_message(f"❌ A quantidade mínima para pagamento é de **1 rota** (500 unidades). Você enviou apenas {quantidade}.", ephemeral=True)

        await interaction.response.send_message(
            "✅ Dados recebidos! Agora, por favor, **anexe a imagem de prova** nesta conversa.\n"
            "Você tem 30 segundos. Se não quiser enviar, apenas ignore esta mensagem.",
            ephemeral=True
        )

        prova_message_url = None
        try:
            def check(m):
                return m.author == interaction.user and m.channel == interaction.channel and m.attachments

            msg_com_anexo = await self.bot.wait_for('message', check=check, timeout=30.0)

            anexo = msg_com_anexo.attachments[0]
            if anexo.content_type and anexo.content_type.startswith("image/"):
                provas_channel = self.bot.get_channel(CANAL_PROVAS_ID)
                if provas_channel:
                    # Envia apenas o arquivo de imagem para o canal de provas
                    prova_message = await provas_channel.send(file=await anexo.to_file())
                    # Pega a URL permanente da nova imagem enviada
                    prova_message_url = prova_message.attachments[0].url
                    await msg_com_anexo.reply("✅ Prova recebida e registrada!", delete_after=5)
                else:
                    await msg_com_anexo.reply("⚠️ Erro de configuração: Canal de provas não encontrado. A entrega seguirá sem prova.", delete_after=10)
            else:
                await msg_com_anexo.reply("❌ O arquivo enviado não é uma imagem válida. A entrega seguirá sem prova.", delete_after=10)

            try:
                await asyncio.sleep(5)
                await msg_com_anexo.delete()
            except discord.NotFound:
                pass

        except asyncio.TimeoutError:
            pass

        cog = self.bot.get_cog("FarmCog")
        await cog.criar_pedido_pagamento(
            channel=interaction.channel,
            user=interaction.user,
            item=self.item_selecionado,
            quantidade=quantidade,
            prova_message_url=prova_message_url
        )


class RecusarFarmModal(ui.Modal, title="Recusar Entrega de Farm"):
    motivo = ui.TextInput(label="Motivo da Recusa", style=discord.TextStyle.paragraph, placeholder="Ex: Print inválida, quantidade incorreta...", required=True)

    async def on_submit(self, interaction: discord.Interaction):
        entrega_id = int(interaction.message.embeds[0].footer.text.split(': ')[1])
        
        db.execute("UPDATE farm_entregas SET status = 'recusado', motivo_recusa = ? WHERE id = ?", (self.motivo.value, entrega_id))
        db.commit()

        cursor = db.cursor()
        cursor.execute("SELECT user_id FROM farm_entregas WHERE id = ?", (entrega_id,))
        user_id = cursor.fetchone()[0]

        embed = interaction.message.embeds[0]
        embed.title = "❌ Entrega de Farm Recusada"
        embed.color = discord.Color.red()
        embed.add_field(name="Recusado por", value=interaction.user.mention, inline=False)
        embed.add_field(name="Motivo", value=self.motivo.value, inline=False)

        view = ui.View.from_message(interaction.message)
        for item in view.children: item.disabled = True
        await interaction.response.edit_message(embed=embed, view=view)

        try:
            membro = await interaction.guild.fetch_member(user_id)
            await membro.send(f"Sua entrega de farm foi **recusada**.\n**Motivo:** {self.motivo.value}")
        except (discord.NotFound, discord.Forbidden):
            pass

# --- Views (Botões) ---

class PagamentoView(ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    def tem_permissao(self, interaction: discord.Interaction) -> bool:
        """Verifica se o usuário tem QUALQUER um dos cargos de pagador."""
        if not CARGOS_PAGADOR_IDS: return False # Se nenhum cargo estiver configurado, ninguém tem permissão.
        user_role_ids = {role.id for role in interaction.user.roles}
        return not user_role_ids.isdisjoint(CARGOS_PAGADOR_IDS)

    @ui.button(label="Realizar Pagamento", style=discord.ButtonStyle.success, emoji="✅", custom_id="farm_pagar_btn")
    async def pagar(self, interaction: discord.Interaction, button: ui.Button):
        if not self.tem_permissao(interaction):
            return await interaction.response.send_message("❌ Você não tem permissão para realizar pagamentos.", ephemeral=True)

        await interaction.response.defer()

        embed = interaction.message.embeds[0]
        entrega_id = int(embed.footer.text.split(': ')[1])
        
        valor_pago_str = next((field.value for field in embed.fields if field.name == "💰 Valor a Pagar"), None)
        if not valor_pago_str:
            await interaction.followup.send("❌ Erro: Não foi possível encontrar o valor do pagamento no registro.", ephemeral=True)
            return
        
        # Limpa a string de formatação (negrito, R$, etc.) e converte para float
        valor_limpo = valor_pago_str.strip('*').replace('R$ ', '').replace('.', '').replace(',', '.')
        valor_pago = float(valor_limpo)

        db.execute("UPDATE farm_entregas SET status = 'pago', valor_pago = ?, pago_por_id = ?, data_pagamento = ? WHERE id = ?",
                   (valor_pago, interaction.user.id, datetime.now().isoformat(), entrega_id))
        db.commit()

        cursor = db.cursor()
        cursor.execute("SELECT user_id, item, quantidade FROM farm_entregas WHERE id = ?", (entrega_id,))
        user_id, item, quantidade = cursor.fetchone()

        embed.title = "✅ Entrega de Farm Paga"
        embed.color = discord.Color.green()
        embed.add_field(name="Pago por", value=interaction.user.mention, inline=False)

        # Dispara um evento personalizado para o cog lidar com a atualização do ranking
        interaction.client.dispatch("farm_pago")

        self.clear_items()
        await interaction.edit_original_response(embed=embed, view=self)

        try:
            membro = await interaction.guild.fetch_member(user_id)
            valor_formatado_dm = f"R$ {int(valor_pago):,}".replace(',', '.')
            await membro.send(f"Seu pagamento pela entrega de **{quantidade}x {item}** foi realizado!\n**Valor:** {valor_formatado_dm}")
        except (discord.NotFound, discord.Forbidden):
            pass

    @ui.button(label="Recusar", style=discord.ButtonStyle.danger, emoji="❌", custom_id="farm_recusar_btn")
    async def recusar(self, interaction: discord.Interaction, button: ui.Button):
        if not self.tem_permissao(interaction):
            return await interaction.response.send_message("❌ Você não tem permissão para recusar entregas.", ephemeral=True)
        await interaction.response.send_modal(RecusarFarmModal())

class FarmItemSelect(ui.Select):
    def __init__(self, bot: commands.Bot):
        options = [discord.SelectOption(label=item.capitalize(), value=item) for item in FARM_PRICES.keys()]
        super().__init__(placeholder="Selecione o item que você farmou...", options=options)
        self.bot = bot

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.send_modal(FarmQuantidadeModal(item_selecionado=self.values[0], bot=self.bot))

class PainelFarmView(ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @ui.button(label="Enviar Farm", style=discord.ButtonStyle.primary, emoji="📦", custom_id="farm_iniciar_envio")
    async def iniciar_envio(self, interaction: discord.Interaction, button: ui.Button):
        view = ui.View(timeout=180)
        view.add_item(FarmItemSelect(bot=interaction.client))
        await interaction.response.send_message("Selecione o item que deseja registrar:", view=view, ephemeral=True)

# --- Cog Principal ---

class FarmCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.bot.add_view(PainelFarmView())
        self.bot.add_view(PagamentoView())
        self.verificar_e_atualizar_schema_db()

    def verificar_e_atualizar_schema_db(self):
        """Verifica se a coluna 'prova_url' existe e a adiciona se necessário."""
        cursor = db.cursor()
        cursor.execute("PRAGMA table_info(farm_entregas)")
        columns = [column[1] for column in cursor.fetchall()]
        if 'prova_url' not in columns:
            print("Atualizando schema: Adicionando coluna 'prova_url' à tabela 'farm_entregas'...")
            db.execute("ALTER TABLE farm_entregas ADD COLUMN prova_url TEXT")
            db.commit()
            print("Schema atualizado com sucesso.")

    @commands.Cog.listener()
    async def on_ready(self):
        # Verifica se a tabela existe ao iniciar
        cursor = db.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='farm_entregas'")
        if cursor.fetchone() is None:
            print("Tabela 'farm_entregas' não encontrada, criando...")
            db.execute("""
                CREATE TABLE IF NOT EXISTS farm_entregas (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    item TEXT NOT NULL,
                    quantidade INTEGER NOT NULL,
                    valor_pago REAL,
                    status TEXT NOT NULL DEFAULT 'pendente',
                    data_submissao TEXT NOT NULL,
                    pago_por_id INTEGER,
                    data_pagamento TEXT,
                    motivo_recusa TEXT,
                    prova_url TEXT
                )
            """)
            db.commit()
            print("Tabela 'farm_entregas' criada.")
        else:
            print("Cog de Farm pronto. Tabela 'farm_entregas' já existe.")

    async def criar_pedido_pagamento(self, channel: discord.TextChannel, user: discord.User, item: str, quantidade: int, prova_message_url: str = None):
        # Calcula o número de rotas e o valor total
        rotas_completas = math.floor((quantidade + 50) / 500)
        valor_total = rotas_completas * VALOR_POR_ROTA_FARM

        cursor = db.cursor()
        cursor.execute("INSERT INTO farm_entregas (user_id, item, quantidade, data_submissao, prova_url) VALUES (?, ?, ?, ?, ?)",
                       (user.id, item.capitalize(), quantidade, datetime.now().isoformat(), prova_message_url))
        db.commit()
        entrega_id = cursor.lastrowid

        canal_pagamentos = self.bot.get_channel(CANAL_FARM_PAGAMENTOS_ID)
        if not canal_pagamentos:
            # A mensagem de erro será enviada no followup final
            pass

        embed = discord.Embed(
            title="📦 Nova Entrega de Farm",
            description=f"**Enviado por:** {user.mention}",
            color=discord.Color.orange()
        )
        embed.add_field(name="Item", value=item.capitalize(), inline=True)
        embed.add_field(name="Rotas Completas", value=f"**{rotas_completas}** ({quantidade} unidades)", inline=True)

        valor_formatado = f"R$ {int(valor_total):,}".replace(',', '.')
        embed.add_field(name="💰 Valor a Pagar", value=f"**{valor_formatado}**", inline=False)
        
        # Define a imagem da prova diretamente no embed, se ela existir
        if prova_message_url:
            embed.set_image(url=prova_message_url)
        else:
            embed.set_image(url="https://cdn.discordapp.com/attachments/1532840644060643489/1532845250672988262/pagar_farm.jpg?ex=6a724962&is=6a70f7e2&hm=71b627e6fb7f7d2718b7890ea5e76bd805e34c6b6ef375d68b241554197029df&")

        embed.set_footer(text=f"ID da Entrega: {entrega_id}")

        if canal_pagamentos:
            await canal_pagamentos.send(embed=embed, view=PagamentoView())
            # Envia uma mensagem de confirmação que se apaga após 10 segundos.
            await channel.send(f"✅ {user.mention}, sua entrega de farm foi registrada para pagamento!", delete_after=10)
        else:
            print(f"ERRO: Canal de pagamentos de farm (ID: {CANAL_FARM_PAGAMENTOS_ID}) não encontrado.")
            if channel: # Garante que o canal existe antes de tentar enviar a mensagem
                await channel.send(f"❌ {user.mention}, ocorreu um erro crítico ao registrar sua entrega. Avise um administrador.", delete_after=15)


    async def get_ranking_embed(self, limit: int = 10):
        cursor = db.cursor()
        cursor.execute("""
            SELECT user_id, SUM(quantidade) as total_quantidade
            FROM farm_entregas
            WHERE status = 'pago'
            GROUP BY user_id
            ORDER BY total_quantidade DESC
        """)
        ranking_data = cursor.fetchall()

        title = "🏆 Ranking de Farm (Top 10)" if limit == 10 and len(ranking_data) > 10 else "🏆 Ranking de Farm (Completo)"
        embed = discord.Embed(title=title, color=discord.Color.gold(), description="Jogadores com mais rotas de farm completadas.")

        if not ranking_data:
            embed.description = "Ainda não há entregas pagas registradas."
            return embed

        description = ""
        for i, (user_id, total_quantidade) in enumerate(ranking_data[:limit]):
            rank_emoji = {0: "🥇", 1: "🥈", 2: "🥉"}.get(i, f"**{i+1}.**")
            
            # Usa a mesma lógica do pagamento para o ranking (margem de 10%)
            rotas_completas = math.floor((total_quantidade + 50) / 500)

            try:
                user = await self.bot.fetch_user(user_id)
                description += f"{rank_emoji} {user.mention} - **{rotas_completas}** rota(s)\n"
            except discord.NotFound:
                description += f"{rank_emoji} `ID: {user_id}` (usuário não encontrado) - **{rotas_completas}** rota(s)\n"

        embed.description = description
        embed.set_footer(text=f"Última atualização: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
        return embed

    async def atualizar_painel_ranking_farm(self):
        """Encontra e atualiza a mensagem do painel de ranking de farm."""
        if not CANAL_FARM_RANKING_ID:
            return

        try:
            channel = await self.bot.fetch_channel(CANAL_FARM_RANKING_ID)
            
            # Procura por uma mensagem de ranking existente para editar
            async for message in channel.history(limit=50):
                if message.author == self.bot.user and message.embeds and "Ranking de Farm" in message.embeds[0].title:
                    embed = await self.get_ranking_embed(limit=10)
                    await message.edit(embed=embed, view=None) # Remove a view antiga
                    print(f"✅ Painel de ranking de farm editado no canal {channel.name}.")
                    return
            
            # Se não encontrou, envia um novo
            embed = await self.get_ranking_embed(limit=10)
            await channel.send(embed=embed, view=None)
            print(f"✅ Novo painel de ranking de farm enviado para o canal {channel.name}.")
        except (discord.NotFound, discord.Forbidden, discord.HTTPException) as e:
            print(f"❌ Erro ao atualizar o painel de ranking de farm: {e}")

    @app_commands.command(name="setup_painel_farm", description="Cria o painel para envio de farm.")
    @app_commands.default_permissions(administrator=True)
    async def setup_painel_farm(self, interaction: discord.Interaction):
        canal = self.bot.get_channel(CANAL_FARM_PAINEL_ID)
        if not canal:
            return await interaction.response.send_message("❌ `CANAL_FARM_PAINEL_ID` não foi configurado.", ephemeral=True)

        await interaction.response.defer(ephemeral=True)
        
        embed = discord.Embed(
            title="Central de Entregas de Farm",
            description="Clique no botão abaixo para registrar uma entrega e solicitar seu pagamento.",
            color=0x2ecc71 # Verde
        )
        embed.set_image(url="https://cdn.discordapp.com/attachments/1534329462189981716/1536690552798576701/Captura_de_tela_2026-08-04_003342.png?ex=6a7c521a&is=6a7b009a&hm=81c7990fa6bb99fa56fff52b5109adb37625ca5704695cbf4ca8a6854db224a2&")

        await canal.send(embed=embed, view=PainelFarmView())
        await interaction.followup.send(f"✅ Painel de farm com botão interativo configurado com sucesso em {canal.mention}!", ephemeral=True)

    @app_commands.command(name="ranking_farm", description="Exibe o painel com o ranking de farm.")
    @app_commands.default_permissions(administrator=True)
    async def ranking_farm(self, interaction: discord.Interaction):
        """Configura o painel com o ranking de farm em um canal."""
        target_channel = self.bot.get_channel(CANAL_FARM_RANKING_ID)
        if not target_channel:
            return await interaction.response.send_message("❌ `CANAL_FARM_RANKING_ID` não foi configurado.", ephemeral=True)

        await interaction.response.defer(ephemeral=True, thinking=True)
        
        embed = await self.get_ranking_embed(limit=10)
        await target_channel.send(embed=embed, view=None)
        await self.atualizar_painel_ranking_farm()
        await interaction.followup.send(f"✅ Painel de ranking de farm configurado com sucesso em {target_channel.mention}!")

    @app_commands.command(name="farm_ranking_completo", description="[ADMIN] Mostra o ranking de farm completo.")
    @app_commands.default_permissions(administrator=True)
    async def farm_ranking_completo(self, interaction: discord.Interaction):
        if interaction.channel_id != CANAL_FARM_RANKING_ID:
            return await interaction.response.send_message(f"❌ Este comando só pode ser usado no canal de ranking de farm.", ephemeral=True)
        
        await interaction.response.defer(ephemeral=True)
        full_ranking_embed = await self.get_ranking_embed(limit=None)
        await interaction.followup.send(embed=full_ranking_embed, ephemeral=True)

    @app_commands.command(name="farm_resetar_ranking", description="[ADMIN] Reseta todas as entregas do ranking de farm.")
    @app_commands.default_permissions(administrator=True)
    async def farm_resetar_ranking(self, interaction: discord.Interaction):
        if interaction.channel_id != CANAL_FARM_RANKING_ID:
            return await interaction.response.send_message(f"❌ Este comando só pode ser usado no canal de ranking de farm.", ephemeral=True)

        # Adiciona um modal de confirmação para segurança
        class ConfirmResetView(ui.View):
            def __init__(self, cog_instance):
                super().__init__(timeout=60)
                self.cog = cog_instance

            @ui.button(label="CONFIRMAR RESET", style=discord.ButtonStyle.danger)
            async def confirm(self, confirm_interaction: discord.Interaction, button: ui.Button):
                db.execute("DELETE FROM farm_entregas")
                db.commit()
                await self.cog.atualizar_painel_ranking_farm()
                await confirm_interaction.response.send_message("✅ Ranking de farm resetado com sucesso!", ephemeral=True)
                self.stop()

        await interaction.response.send_message(
            "**⚠️ ATENÇÃO!** Você está prestes a apagar **TODAS** as entregas de farm. Esta ação é irreversível.",
            view=ConfirmResetView(self), ephemeral=True)

    @commands.Cog.listener()
    async def on_farm_pago(self):
        """
        Listener para o evento personalizado 'farm_pago'.
        Atualiza o painel de ranking sempre que um pagamento é confirmado.
        """
        print("Evento 'farm_pago' recebido. Atualizando ranking de farm...")
        await self.atualizar_painel_ranking_farm()

async def setup(bot: commands.Bot):
    # Garante que a conexão com o banco de dados seja estabelecida no mesmo processo
    global db
    # A conexão já é feita no topo do arquivo
    await bot.add_cog(FarmCog(bot))