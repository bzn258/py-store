import discord
from discord.ext import commands
from discord import app_commands, ui
import os
import sqlite3
from datetime import datetime

import json

# --- Funções Auxiliares ---
def get_first_id(env_var: str, default: int = 0) -> int:
    """Lê uma variável de ambiente, pega o primeiro ID se houver múltiplos, e converte para int."""
    value = os.getenv(env_var)
    if not value:
        return default
    # Pega apenas o primeiro valor antes da vírgula, se houver, e remove espaços.
    first_value = value.split(',')[0].strip()
    return int(first_value) if first_value.isdigit() else default

# --- Configurações (Lidas do .env) ---
CANAL_FARM_PAINEL_ID = get_first_id("CANAL_FARM_PAINEL_ID")
CANAL_FARM_PAGAMENTOS_ID = get_first_id("CANAL_FARM_PAGAMENTOS_ID")
CARGO_PAGADOR_ID = get_first_id("CARGO_PAGADOR_ID")
CANAL_FARM_RANKING_ID = get_first_id("CANAL_FARM_RANKING_ID")
FARM_PAGAMENTO_IMAGE_URL = os.getenv("FARM_PAGAMENTO_IMAGE_URL")
FARM_PAINEL_IMAGE_URL = os.getenv("FARM_PAINEL_IMAGE_URL")

# Carrega a tabela de preços do .env
FARM_PRICES_STR = os.getenv("FARM_PRICES", "{}")
try:
    FARM_PRICES = json.loads(FARM_PRICES_STR.lower())
except json.JSONDecodeError:
    print("ERRO CRÍTICO: A variável 'FARM_PRICES' no arquivo .env não é um JSON válido.")
    FARM_PRICES = {}

# --- Banco de Dados ---
db_path = os.path.join(os.path.dirname(__file__), '..', 'registro.db')
db = sqlite3.connect(db_path)
db.execute("""
    CREATE TABLE IF NOT EXISTS farm_entregas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        item TEXT NOT NULL,
        quantidade INTEGER NOT NULL,
        valor_pago REAL,
        status TEXT NOT NULL DEFAULT 'pendente', -- pendente, pago, recusado
        data_submissao TEXT NOT NULL,
        pago_por_id INTEGER,
        data_pagamento TEXT,
        motivo_recusa TEXT
    )
""")
db.commit()

# --- Modals (Formulários) ---

class RecusarFarmModal(ui.Modal, title="Recusar Entrega de Farm"):
    motivo = ui.TextInput(label="Motivo da Recusa", style=discord.TextStyle.paragraph, placeholder="Ex: Print inválida, quantidade incorreta...", required=True)

    async def on_submit(self, interaction: discord.Interaction):
        entrega_id = int(interaction.message.embeds[0].footer.text.split(': ')[1])
        
        db.execute("UPDATE farm_entregas SET status = 'recusado', motivo_recusa = ? WHERE id = ?", (self.motivo.value, entrega_id))
        db.commit()

        cursor = db.cursor()
        cursor.execute("SELECT user_id FROM farm_entregas WHERE id = ?", (entrega_id,))
        user_id = cursor.fetchone()[0]

        embed = interaction.message.embeds[0]
        embed.title = "❌ Entrega de Farm Recusada"
        embed.color = discord.Color.red()
        embed.add_field(name="Recusado por", value=interaction.user.mention, inline=False)
        embed.add_field(name="Motivo", value=self.motivo.value, inline=False)

        view = ui.View.from_message(interaction.message)
        for item in view.children: item.disabled = True
        await interaction.response.edit_message(embed=embed, view=view)

        try:
            membro = await interaction.guild.fetch_member(user_id)
            await membro.send(f"Sua entrega de farm foi **recusada**.\n**Motivo:** {self.motivo.value}")
        except (discord.NotFound, discord.Forbidden):
            pass

class FarmQuantidadeModal(ui.Modal):
    """Pede apenas a quantidade após o item ser selecionado."""
    quantidade = ui.TextInput(label="Quantidade Entregue", placeholder="Ex: 150", required=True)

    def __init__(self, item_selecionado: str):
        super().__init__(title=f"Entregar: {item_selecionado.capitalize()}")
        self.item_selecionado = item_selecionado

    async def on_submit(self, interaction: discord.Interaction):
        try:
            qtd_val = int(self.quantidade.value)
            if qtd_val <= 0:
                raise ValueError("Quantidade deve ser positiva.")
        except ValueError:
            return await interaction.response.send_message("❌ A quantidade deve ser um número.", ephemeral=True)

        await interaction.response.defer(ephemeral=True, thinking=True)

        # Calcula o valor a ser pago
        item_nome_lower = self.item_selecionado.lower()
        preco_unitario = FARM_PRICES.get(item_nome_lower)

        if preco_unitario is None:
            # Esta verificação é uma segurança, mas não deve acontecer com o menu de seleção
            return await interaction.followup.send(f"❌ O item '{self.item_selecionado}' não possui um preço definido. Avise um administrador.", ephemeral=True)

        cursor = db.cursor()
        cursor.execute("INSERT INTO farm_entregas (user_id, item, quantidade, data_submissao) VALUES (?, ?, ?, ?)",
                       (interaction.user.id, self.item_selecionado.capitalize(), qtd_val, datetime.now().isoformat()))
        db.commit()
        entrega_id = cursor.lastrowid

        canal_pagamentos = interaction.guild.get_channel(CANAL_FARM_PAGAMENTOS_ID)
        if not canal_pagamentos:
            return await interaction.followup.send("❌ Canal de pagamentos não configurado. Avise um administrador.", ephemeral=True)

        embed = discord.Embed(
            title="📦 Nova Entrega de Farm",
            description=f"**Enviado por:** {interaction.user.mention}",
            color=discord.Color.orange()
        )
        embed.add_field(name="Item", value=self.item_selecionado.capitalize(), inline=True)
        embed.add_field(name="Quantidade", value=f"{qtd_val}", inline=True)
        
        valor_total = preco_unitario * qtd_val
        valor_formatado = f"R$ {int(valor_total):,}".replace(',', '.')
        embed.add_field(name="💰 Valor a Pagar", value=f"**{valor_formatado}**", inline=False)
        embed.set_footer(text=f"ID da Entrega: {entrega_id}")

        # --- Lógica de Imagem Aprimorada ---
        arquivo_imagem = None
        caminho_imagem_local = os.path.join(os.path.dirname(__file__), '..', 'assets', 'pagamento_farm.png')

        if os.path.exists(caminho_imagem_local):
            print("[DIAGNÓSTICO FARM] Usando imagem local 'assets/pagamento_farm.png'.")
            arquivo_imagem = discord.File(caminho_imagem_local, filename="pagamento_farm.png")
            embed.set_image(url="attachment://pagamento_farm.png")
        elif FARM_PAGAMENTO_IMAGE_URL:
            print(f"[DIAGNÓSTICO FARM] Usando imagem da URL: {FARM_PAGAMENTO_IMAGE_URL}")
            embed.set_image(url=FARM_PAGAMENTO_IMAGE_URL)

        await canal_pagamentos.send(embed=embed, view=PagamentoView(), file=arquivo_imagem)
        await interaction.followup.send("✅ Sua entrega de farm foi registrada para pagamento!", ephemeral=True)

class FarmItemSelect(ui.Select):
    """Menu de seleção com os itens de farm disponíveis."""
    def __init__(self):
        options = [
            discord.SelectOption(label=item.capitalize(), value=item)
            for item in FARM_PRICES.keys()
        ]
        if not options:
            options.append(discord.SelectOption(label="Nenhum item configurado", value="disabled"))

        super().__init__(placeholder="Selecione o item que você farmou...", options=options)

    async def callback(self, interaction: discord.Interaction):
        item_selecionado = self.values[0]
        if item_selecionado == "disabled":
            await interaction.response.send_message("❌ Nenhum item de farm foi configurado. Avise um administrador.", ephemeral=True)
            return
        
        # Abre o modal para pedir a quantidade
        await interaction.response.send_modal(FarmQuantidadeModal(item_selecionado=item_selecionado))

# --- Views (Botões) ---

class PagamentoView(ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    def tem_permissao(self, interaction: discord.Interaction) -> bool:
        """Permissão liberada para todos que tenham acesso ao canal."""
        return True

    @ui.button(label="Realizar Pagamento", style=discord.ButtonStyle.success, emoji="✅", custom_id="farm_pagar")
    async def pagar(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.defer()

        embed = interaction.message.embeds[0]
        entrega_id = int(embed.footer.text.split(': ')[1])
        
        valor_pago_str = next((field.value for field in embed.fields if field.name == "💰 Valor a Pagar"), None)
        if not valor_pago_str:
            await interaction.followup.send("❌ Erro: Não foi possível encontrar o valor do pagamento no registro.", ephemeral=True)
            return
        
        # Limpa a string de formatação (negrito, R$, etc.) e converte para float
        valor_limpo = valor_pago_str.strip('*').replace('R$ ', '').replace('.', '').replace(',', '.')
        valor_pago = float(valor_limpo)

        db.execute("UPDATE farm_entregas SET status = 'pago', valor_pago = ?, pago_por_id = ?, data_pagamento = ? WHERE id = ?",
                   (valor_pago, interaction.user.id, datetime.now().isoformat(), entrega_id))
        db.commit()

        cursor = db.cursor()
        cursor.execute("SELECT user_id, item, quantidade FROM farm_entregas WHERE id = ?", (entrega_id,))
        user_id, item, quantidade = cursor.fetchone()

        embed.title = "✅ Entrega de Farm Paga"
        embed.color = discord.Color.green()
        embed.add_field(name="Pago por", value=interaction.user.mention, inline=False)

        # Dispara um evento personalizado para o cog lidar com a atualização do ranking
        interaction.client.dispatch("farm_pago")

        self.clear_items()
        await interaction.edit_original_response(embed=embed, view=self)

        try:
            membro = await interaction.guild.fetch_member(user_id)
            valor_formatado_dm = f"R$ {int(valor_pago):,}".replace(',', '.')
            await membro.send(f"Seu pagamento pela entrega de **{quantidade}x {item}** foi realizado!\n**Valor:** {valor_formatado_dm}")
        except (discord.NotFound, discord.Forbidden):
            pass

    @ui.button(label="Recusar", style=discord.ButtonStyle.danger, emoji="❌", custom_id="farm_recusar")
    async def recusar(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.send_modal(RecusarFarmModal())

class PainelFarmView(ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @ui.button(label="Enviar Farm", style=discord.ButtonStyle.primary, emoji="📦", custom_id="farm_enviar")
    async def enviar_farm(self, interaction: discord.Interaction, button: ui.Button):
        # Cria uma view temporária com o menu de seleção
        view = ui.View(timeout=180)
        view.add_item(FarmItemSelect())
        await interaction.response.send_message("Selecione o item que deseja registrar:", view=view, ephemeral=True)

class RankingFarmView(ui.View):
    def __init__(self, bot: commands.Bot):
        super().__init__(timeout=None)
        self.bot = bot

# --- Cog Principal ---

class FarmCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.bot.add_view(PainelFarmView())
        self.bot.add_view(PagamentoView())
        self.bot.add_view(RankingFarmView(bot=self.bot))

    @commands.Cog.listener()
    async def on_ready(self):
        # Verifica se a tabela existe ao iniciar
        cursor = db.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='farm_entregas'")
        if cursor.fetchone() is None:
            print("Tabela 'farm_entregas' não encontrada, criando...")
            db.execute("""
                CREATE TABLE IF NOT EXISTS farm_entregas (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    item TEXT NOT NULL,
                    quantidade INTEGER NOT NULL,
                    valor_pago REAL,
                    status TEXT NOT NULL DEFAULT 'pendente',
                    data_submissao TEXT NOT NULL,
                    pago_por_id INTEGER,
                    data_pagamento TEXT,
                    motivo_recusa TEXT
                )
            """)
            db.commit()
            print("Tabela 'farm_entregas' criada.")
        else:
            print("Cog de Farm pronto. Tabela 'farm_entregas' já existe.")

    async def get_ranking_farm_embed(self, limit: int = 10):
        cursor = db.cursor()
        cursor.execute("""
            SELECT user_id, SUM(valor_pago) as total_pago
            FROM farm_entregas
            WHERE status = 'pago'
            GROUP BY user_id
            ORDER BY total_pago DESC
        """)
        ranking_data = cursor.fetchall()

        title = "🏆 Ranking de Farm (Top 10)" if limit == 10 else "🏆 Ranking de Farm (Completo)"
        embed = discord.Embed(title=title, color=discord.Color.gold(), description="Jogadores que mais receberam por suas entregas.")

        if not ranking_data:
            embed.description = "Ainda não há pagamentos registrados."
            return embed

        description = ""
        for i, (user_id, total_pago) in enumerate(ranking_data[:limit]):
            rank_emoji = {0: "🥇", 1: "🥈", 2: "🥉"}.get(i, f"**{i+1}.**")
            try:
                user = await self.bot.fetch_user(user_id)
                valor_formatado_rank = f"R$ {int(total_pago):,}".replace(',', '.')
                description += f"{rank_emoji} {user.mention} - **{valor_formatado_rank}**\n"
            except discord.NotFound:
                valor_formatado_rank = f"R$ {int(total_pago):,}".replace(',', '.')
                description += f"{rank_emoji} `ID: {user_id}` (usuário não encontrado) - **{valor_formatado_rank}**\n"

        embed.description = description
        embed.set_footer(text=f"Última atualização: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
        return embed

    async def atualizar_painel_ranking_farm(self):
        """Encontra e atualiza a mensagem do painel de ranking de farm."""
        if not CANAL_FARM_RANKING_ID:
            return

        try:
            channel = await self.bot.fetch_channel(CANAL_FARM_RANKING_ID)
            
            # Procura por uma mensagem de ranking existente para editar
            async for message in channel.history(limit=50):
                if message.author == self.bot.user and message.embeds and "Ranking de Farm" in message.embeds[0].title:
                    view = RankingFarmView(bot=self.bot)
                    embed = await self.get_ranking_farm_embed(limit=10)
                    await message.edit(embed=embed, view=view)
                    print(f"✅ Painel de ranking de farm editado no canal {channel.name}.")
                    return
            
            # Se não encontrou, envia um novo
            view = RankingFarmView(bot=self.bot)
            embed = await self.get_ranking_farm_embed(limit=10)
            await channel.send(embed=embed, view=view)
            print(f"✅ Novo painel de ranking de farm enviado para o canal {channel.name}.")
        except (discord.NotFound, discord.Forbidden, discord.HTTPException) as e:
            print(f"❌ Erro ao atualizar o painel de ranking de farm: {e}")

    @app_commands.command(name="setup_painel_farm", description="Cria o painel para envio de farm.")
    @app_commands.default_permissions(administrator=True)
    async def setup_painel_farm(self, interaction: discord.Interaction):
        canal = self.bot.get_channel(CANAL_FARM_PAINEL_ID)
        if not canal:
            return await interaction.response.send_message("❌ `CANAL_FARM_PAINEL_ID` não foi configurado.", ephemeral=True)

        await interaction.response.defer(ephemeral=True)
        
        embed = discord.Embed(
            title="Central de Entregas de Farm",
            description="Clique no botão abaixo para registrar uma entrega e solicitar seu pagamento.",
            color=0x2ecc71 # Verde
        )
        
        # --- Lógica de Imagem Aprimorada ---
        arquivo_imagem = None
        caminho_imagem_local = os.path.join(os.path.dirname(__file__), '..', 'assets', 'painel_farm.png')

        if os.path.exists(caminho_imagem_local):
            print("[DIAGNÓSTICO FARM] Usando imagem local 'assets/painel_farm.png'.")
            arquivo_imagem = discord.File(caminho_imagem_local, filename="painel_farm.png")
            embed.set_image(url="attachment://painel_farm.png")
        elif FARM_PAINEL_IMAGE_URL:
            print(f"[DIAGNÓSTICO FARM] Usando imagem da URL: {FARM_PAINEL_IMAGE_URL}")
            embed.set_image(url=FARM_PAINEL_IMAGE_URL)

        await canal.send(embed=embed, view=PainelFarmView(), file=arquivo_imagem)
        await interaction.followup.send(f"✅ Painel de farm configurado com sucesso em {canal.mention}!", ephemeral=True)

    @app_commands.command(name="ranking_farm", description="Exibe o painel com o ranking de farm.")
    @app_commands.default_permissions(administrator=True)
    async def ranking_farm(self, interaction: discord.Interaction):
        """Configura o painel com o ranking de farm em um canal."""
        target_channel = self.bot.get_channel(CANAL_FARM_RANKING_ID)
        if not target_channel:
            return await interaction.response.send_message("❌ `CANAL_FARM_RANKING_ID` não foi configurado.", ephemeral=True)

        await interaction.response.defer(ephemeral=True, thinking=True)
        
        view = RankingFarmView(bot=self.bot)
        embed = await self.get_ranking_farm_embed(limit=10)
        await target_channel.send(embed=embed, view=view)
        await self.atualizar_painel_ranking_farm()
        await interaction.followup.send(f"✅ Painel de ranking de farm configurado com sucesso em {target_channel.mention}!")

    @app_commands.command(name="ranking_farm_completo", description="Exibe a lista completa do ranking de farm.")
    @app_commands.default_permissions(administrator=True)
    async def ranking_farm_completo(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        embed = await self.get_ranking_farm_embed(limit=None)
        await interaction.followup.send(embed=embed, ephemeral=True)

    @app_commands.command(name="resetar_ranking_farm", description="Reseta o ranking de farm.")
    @app_commands.default_permissions(administrator=True)
    async def resetar_ranking_farm(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)

        # Executa o reset
        db.execute("DELETE FROM farm_entregas")
        db.commit()

        # Atualiza o painel principal
        await self.atualizar_painel_ranking_farm()
        await interaction.followup.send("✅ O ranking de farm foi resetado e o painel atualizado.", ephemeral=True)

    @commands.Cog.listener()
    async def on_farm_pago(self):
        """
        Listener para o evento personalizado 'farm_pago'.
        Atualiza o painel de ranking sempre que um pagamento é confirmado.
        """
        print("Evento 'farm_pago' recebido. Atualizando ranking de farm...")
        await self.atualizar_painel_ranking_farm()

async def setup(bot: commands.Bot):
    # Garante que a conexão com o banco de dados seja estabelecida no mesmo processo
    global db
    db_path = os.path.join(os.path.dirname(__file__), '..', 'registro.db')
    db = sqlite3.connect(db_path)
    await bot.add_cog(FarmCog(bot))