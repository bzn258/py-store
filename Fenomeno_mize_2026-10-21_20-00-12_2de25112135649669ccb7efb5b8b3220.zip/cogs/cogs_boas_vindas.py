import os
import discord
from discord.ext import commands
from discord import app_commands

class BoasVindas(commands.Cog):
    """Cog responsável por enviar mensagens de boas-vindas quando novos membros entram no servidor."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        # ID do canal onde a mensagem de boas-vindas será enviada.
        # Defina CANAL_BOAS_VINDAS_ID no arquivo .env ou altere o valor padrão abaixo.
        self.canal_id = int(os.getenv('CANAL_BOAS_VINDAS_ID', '0'))

    def criar_embed_boas_vindas(self, member: discord.Member) -> discord.Embed:
        """Gera o Embed personalizado de boas-vindas."""
        guild = member.guild
        embed = discord.Embed(
            title=f"🎉 Bem-vindo(a) ao {guild.name}!",
            description=(
                f"Olá {member.mention}, seja muito bem-vindo(a) ao nosso servidor!\n\n"
                f"📜 Leia as regras e divirta-se!\n"
                f"Esperamos que você esteja aqui para somar."
            ),
            color=discord.Color.from_rgb(88, 101, 242), # Estilo Blurple do Discord
            timestamp=discord.utils.utcnow()
        )

        # Foto de perfil do membro como thumbnail
        embed.set_thumbnail(url=member.display_avatar.url)

        # Campos com informações úteis
        embed.add_field(name="👤 Usuário", value=f"`{member.name}`", inline=True)
        embed.add_field(name="👥 Membro Nº", value=f"`#{guild.member_count}`", inline=True)

        if guild.icon:
            embed.set_footer(text=guild.name, icon_url=guild.icon.url)
        else:
            embed.set_footer(text=guild.name)

        return embed

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        """Evento acionado automaticamente quando um membro entra no servidor."""
        if self.canal_id == 0:
            print(f"[Boas-Vindas] Canal não configurado. Defina CANAL_BOAS_VINDAS_ID no .env para enviar mensagem para {member.name}.")
            return

        canal = self.bot.get_channel(self.canal_id)
        if canal is None:
            try:
                canal = await self.bot.fetch_channel(self.canal_id)
            except Exception as e:
                print(f"[Boas-Vindas] Erro ao buscar o canal com ID {self.canal_id}: {e}")
                return

        try:
            embed = self.criar_embed_boas_vindas(member)
            await canal.send(content=f"👋 Olá {member.mention}, seja bem-vindo(a)!", embed=embed)
            print(f"[Boas-Vindas] Mensagem enviada para {member.name} com sucesso.")
        except discord.Forbidden:
            print(f"[Boas-Vindas] Erro de permissão: O bot não tem permissão para enviar mensagens no canal de boas-vindas.")
        except Exception as e:
            print(f"[Boas-Vindas] Erro ao enviar mensagem de boas-vindas: {e}")

    @app_commands.command(name="testar_boas_vindas", description="Testa o envio da mensagem de boas-vindas.")
    @app_commands.checks.has_permissions(administrator=True)
    async def testar_boas_vindas(self, interaction: discord.Interaction):
        """Comando slash para administradores testarem a mensagem de boas-vindas."""
        if not isinstance(interaction.user, discord.Member):
            await interaction.response.send_message("Este comando só pode ser usado dentro de um servidor.", ephemeral=True)
            return

        embed = self.criar_embed_boas_vindas(interaction.user)
        
        await interaction.response.send_message("✅ Testando envio de boas-vindas...", ephemeral=True)

        destino = self.bot.get_channel(self.canal_id) if self.canal_id != 0 else interaction.channel
        if destino and isinstance(destino, discord.TextChannel):
            await destino.send(content=f"👋 [TESTE] Olá {interaction.user.mention}, seja bem-vindo(a)!", embed=embed)
        else:
            await interaction.followup.send(content=f"👋 Olá {interaction.user.mention}, seja bem-vindo(a)!", embed=embed)

    @testar_boas_vindas.error
    async def testar_boas_vindas_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message("❌ Apenas administradores podem executar este comando.", ephemeral=True)


async def setup(bot: commands.Bot):
    """Função obrigatória para carregar a extensão no bot."""
    await bot.add_cog(BoasVindas(bot))

