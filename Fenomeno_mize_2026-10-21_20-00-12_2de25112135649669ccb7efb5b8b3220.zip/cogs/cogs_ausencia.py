import discord
from discord.ext import commands
from discord import app_commands
import os

# --- Configurações (Lidas do .env) ---
def get_first_id(env_var: str, default: int = 0) -> int:
    """Lê uma variável de ambiente, pega o primeiro ID se houver múltiplos, e converte para int."""
    value = os.getenv(env_var)
    if not value:
        return default
    first_value = value.split(',')[0].strip()
    return int(first_value) if first_value.isdigit() else default

def get_role_ids(env_var: str) -> set:
    """Lê uma variável de ambiente com IDs separados por vírgula e retorna um set de inteiros."""
    val = os.getenv(env_var, "")
    return {int(r.strip()) for r in val.split(',') if r.strip().isdigit()}

CANAL_AUSENCIA_PAINEL_ID = get_first_id("CANAL_AUSENCIA_PAINEL_ID")
CANAL_AUSENCIA_LOGS_ID = get_first_id("CANAL_AUSENCIA_LOGS_ID")
CARGO_STAFF_IDS = get_role_ids("CARGO_STAFF_ID") | get_role_ids("CARGO_GERENTE_ID")
CARGO_AUSENTE_ID = get_first_id("CARGO_AUSENTE_ID")
AUSENCIA_PAINEL_IMAGE_URL = os.getenv("AUSENCIA_PAINEL_IMAGE_URL")

def tem_permissao_ausencia(user: discord.Member) -> bool:
    """Permissão liberada para todos que tenham acesso ao canal."""
    return True

# --- Modals (Formulários) ---

class RecusaAusenciaModal(discord.ui.Modal, title="Recusar Solicitação de Ausência"):
    """Formulário para o staff explicar o motivo da recusa."""
    motivo = discord.ui.TextInput(
        label="Motivo da recusa",
        style=discord.TextStyle.paragraph,
        placeholder="Ex: Período muito longo, motivo não justificado, etc.",
        required=True,
        max_length=500
    )

    async def on_submit(self, interaction: discord.Interaction):
        # Pega o embed original e o ID do solicitante
        original_embed = interaction.message.embeds[0]
        solicitante_id = int(original_embed.footer.text.split(': ')[1])
        
        # Cria o novo embed de recusa
        embed_recusado = discord.Embed(
            title="❌ Ausência Recusada",
            description=original_embed.description,
            color=discord.Color.red()
        )
        for field in original_embed.fields:
            embed_recusado.add_field(name=field.name, value=field.value, inline=field.inline)
        
        embed_recusado.add_field(name="Recusado por", value=interaction.user.mention, inline=False)
        embed_recusado.add_field(name="Motivo da Recusa", value=self.motivo.value, inline=False)
        embed_recusado.set_footer(text=f"ID do Solicitante: {solicitante_id}")

        # Desativa os botões da mensagem original
        view = discord.ui.View.from_message(interaction.message)
        for item in view.children:
            item.disabled = True

        await interaction.response.edit_message(embed=embed_recusado, view=view)

        # Notifica o usuário no privado
        try:
            membro = await interaction.guild.fetch_member(solicitante_id)
            await membro.send(f"Sua solicitação de ausência foi **recusada**.\n**Motivo:** {self.motivo.value}")
        except (discord.NotFound, discord.Forbidden):
            await interaction.channel.send(f"⚠️ Não foi possível notificar o solicitante (ID: {solicitante_id}) no privado.", delete_after=10)


class AusenciaModal(discord.ui.Modal, title="Solicitar Ausência"):
    """Formulário para o usuário preencher os dados da ausência."""
    inicio = discord.ui.TextInput(
        label="Data de Início da Ausência",
        placeholder="Ex: 20/07/2024",
        required=True
    )
    fim = discord.ui.TextInput(
        label="Data de Fim da Ausência",
        placeholder="Ex: 25/07/2024",
        required=True
    )
    motivo = discord.ui.TextInput(
        label="Motivo da Ausência",
        style=discord.TextStyle.paragraph,
        placeholder="Ex: Viagem, problemas pessoais, etc.",
        required=True,
        max_length=1024
    )

    async def on_submit(self, interaction: discord.Interaction):
        canal_logs = interaction.guild.get_channel(CANAL_AUSENCIA_LOGS_ID)
        if not canal_logs:
            return await interaction.response.send_message("❌ Canal de logs de ausência não configurado. Avise um administrador.", ephemeral=True)

        embed = discord.Embed(
            title="📝 Nova Solicitação de Ausência",
            description=f"**Solicitante:** {interaction.user.mention}",
            color=discord.Color.orange()
        )
        embed.add_field(name="Período", value=f"De **{self.inicio.value}** até **{self.fim.value}**", inline=False)
        embed.add_field(name="Motivo", value=self.motivo.value, inline=False)
        embed.set_footer(text=f"ID do Solicitante: {interaction.user.id}")

        view = AusenciaAprovacaoView()
        await canal_logs.send(embed=embed, view=view)
        await interaction.response.send_message("✅ Sua solicitação de ausência foi enviada para análise!", ephemeral=True)


# --- Views (Botões) ---

class AusenciaAprovacaoView(discord.ui.View):
    """View com os botões de Aprovar e Recusar para a staff."""
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Aprovar", style=discord.ButtonStyle.success, custom_id="ausencia_aprovar")
    async def aprovar(self, interaction: discord.Interaction, button: discord.ui.Button):
        original_embed = interaction.message.embeds[0]
        solicitante_id = int(original_embed.footer.text.split(': ')[1])

        embed_aprovado = discord.Embed(
            title="✅ Ausência Aprovada",
            description=original_embed.description,
            color=discord.Color.green()
        )
        for field in original_embed.fields:
            embed_aprovado.add_field(name=field.name, value=field.value, inline=field.inline)
        
        embed_aprovado.add_field(name="Aprovado por", value=interaction.user.mention, inline=False)
        embed_aprovado.set_footer(text=f"ID do Solicitante: {solicitante_id}")

        self.clear_items() # Remove os botões
        await interaction.response.edit_message(embed=embed_aprovado, view=self)

        membro = None
        try:
            membro = await interaction.guild.fetch_member(solicitante_id)
            await membro.send("Sua solicitação de ausência foi **aprovada**!")
        except (discord.NotFound, discord.Forbidden):
            await interaction.channel.send(f"⚠️ Não foi possível notificar o solicitante (ID: {solicitante_id}) no privado.", delete_after=10)

        # Adiciona o cargo de ausente
        if membro:
            cargo_ausente = interaction.guild.get_role(CARGO_AUSENTE_ID)
            if cargo_ausente:
                try:
                    await membro.add_roles(cargo_ausente, reason="Ausência aprovada via bot.")
                except discord.Forbidden:
                    await interaction.channel.send(f"⚠️ Não tenho permissão para adicionar o cargo de ausente a {membro.mention}.", delete_after=15)
            else:
                await interaction.channel.send(f"⚠️ O cargo de ausente (`CARGO_AUSENTE_ID`) não foi configurado ou não foi encontrado.", delete_after=15)

    @discord.ui.button(label="Recusar", style=discord.ButtonStyle.danger, custom_id="ausencia_recusar")
    async def recusar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(RecusaAusenciaModal())


class PainelAusenciaView(discord.ui.View):
    """View persistente com o botão para iniciar a solicitação."""
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Solicitar Ausência", style=discord.ButtonStyle.primary, custom_id="solicitar_ausencia", emoji="🗓️")
    async def solicitar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(AusenciaModal())


# --- Cog Principal ---

class AusenciaCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.bot.add_view(PainelAusenciaView())
        self.bot.add_view(AusenciaAprovacaoView())

    @app_commands.command(name="setup_ausencia", description="Cria o painel de solicitação de ausência.")
    @app_commands.default_permissions(administrator=True)
    async def setup_ausencia(self, interaction: discord.Interaction):
        canal = self.bot.get_channel(CANAL_AUSENCIA_PAINEL_ID)
        if not canal:
            return await interaction.response.send_message("❌ `CANAL_AUSENCIA_PAINEL_ID` não foi configurado corretamente.", ephemeral=True)

        await interaction.response.defer(ephemeral=True)
        
        embed = discord.Embed(
            title="**SOLICITAR AUSENCIA**",
            description="Precisa se ausentar por um período maior que **5 DIAS**?\nClique no botão abaixo para preencher o formulário para notificar os lideres.",
            color=discord.Color.dark_blue()
        )

        # --- Lógica de Imagem Aprimorada ---
        arquivo_imagem = None
        caminho_imagem_local = os.path.join(os.path.dirname(__file__), '..', 'assets', 'painel_ausencia.png')

        if os.path.exists(caminho_imagem_local):
            print("[DIAGNÓSTICO AUSENCIA] Usando imagem local 'assets/painel_ausencia.png'.")
            arquivo_imagem = discord.File(caminho_imagem_local, filename="painel_ausencia.png")
            embed.set_image(url="attachment://painel_ausencia.png")
        elif AUSENCIA_PAINEL_IMAGE_URL:
            print(f"[DIAGNÓSTICO AUSENCIA] Usando imagem da URL: {AUSENCIA_PAINEL_IMAGE_URL}")
            embed.set_image(url=AUSENCIA_PAINEL_IMAGE_URL)

        await canal.send(embed=embed, view=PainelAusenciaView(), file=arquivo_imagem)
        await interaction.followup.send(f"✅ Painel de ausências configurado com sucesso em {canal.mention}!", ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(AusenciaCog(bot))