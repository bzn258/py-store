import discord
from discord.ext import commands
from discord import app_commands
from discord.interactions import Interaction
from discord.ui import Select, View, Modal, TextInput
import sqlite3
import os
from datetime import datetime
import pytz

# ============================================================
#  CONFIGURAÇÕES (Lidas do .env pelo main.py)
# ============================================================
def get_first_id(env_var: str, default: int = 0) -> int:
    """Lê uma variável de ambiente, pega o primeiro ID se houver múltiplos, e converte para int."""
    value = os.getenv(env_var)
    if not value:
        return default
    # Pega apenas o primeiro valor antes da vírgula, se houver, e remove espaços.
    first_value = value.split(',')[0].strip()
    return int(first_value) if first_value.isdigit() else default

CANAL_REGISTRO_ID   = get_first_id("CANAL_REGISTRO_ID")
CANAL_APROVACAO_ID  = get_first_id("CANAL_APROVACAO_ID")
CARGO_RECRUTADOR_IDS_STR = os.getenv("CARGO_RECRUTADOR_ID", "")
CARGO_RECRUTADOR_IDS = {int(role_id.strip()) for role_id in CARGO_RECRUTADOR_IDS_STR.split(',') if role_id.strip()}
CANAL_RANKING_ID    = get_first_id("CANAL_RANKING_ID")
CARGO_MEMBRO_ID     = get_first_id("CARGO_MEMBRO_ID")
REGISTRO_PAINEL_IMAGE_URL = os.getenv("REGISTRO_PAINEL_IMAGE_URL") # URL para a imagem do painel de registro

# --- Diagnóstico ---
print(f"[DIAGNÓSTICO WL] URL da imagem do painel de registro: '{REGISTRO_PAINEL_IMAGE_URL}'")

# ── Banco de Dados ──
db_path = os.path.join(os.path.dirname(__file__), '..', 'registro.db') # Aponta para a pasta raiz
db = sqlite3.connect(db_path)
cursor = db.cursor()
cursor.execute("""
    CREATE TABLE IF NOT EXISTS registros (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id       INTEGER NOT NULL,
        nome_ig       TEXT NOT NULL,
        id_ig         TEXT NOT NULL,
        tipo_registro TEXT NOT NULL DEFAULT 'membro', -- membro, parceiro
        recrutador_id INTEGER NOT NULL,
        aprovado_por  INTEGER,
        status        TEXT NOT NULL DEFAULT 'pendente', -- pendente, aprovado, recusado
        data_registro TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
        data_aprovacao TEXT,
        motivo_recusa TEXT
    )
""")

# --- Migração de Banco de Dados ---
# Verifica se a coluna 'tipo_registro' existe e a adiciona se não existir.
cursor.execute("PRAGMA table_info(registros)")
columns = [column[1] for column in cursor.fetchall()]
if 'tipo_registro' not in columns:
    print("⚠️  [MIGRAÇÃO WL] A coluna 'tipo_registro' não existe. Adicionando...")
    cursor.execute("ALTER TABLE registros ADD COLUMN tipo_registro TEXT NOT NULL DEFAULT 'membro'")
    print("✅ [MIGRAÇÃO WL] Coluna 'tipo_registro' adicionada com sucesso.")

db.commit()

# ============================================================
#  CLASSES DA UI (VIEWS, MODALS, SELECTS)
#  Não precisam estar dentro do Cog, mas podem se preferir.
#  Deixá-las fora simplifica as referências.
# ============================================================

class RegistroModal(Modal, title="📋 Registro"):
    nome_ig  = TextInput(label="Qual seu nome? (In Game)", placeholder="Ex: João Silva", max_length=50)
    id_ig    = TextInput(label="Qual seu ID?", placeholder="Ex: 1234", max_length=10)

    def __init__(self, bot: commands.Bot, recrutador_id: int = 0, tipo_registro: str = "membro"):
        super().__init__()
        self.tipo_registro = tipo_registro
        self.recrutador_id = recrutador_id
        self.bot = bot
        self.title = "📋 Registro de Membro"

    async def on_submit(self, interaction: discord.Interaction):
        canal_aprovacao = self.bot.get_channel(CANAL_APROVACAO_ID)
        if not canal_aprovacao:
            await interaction.response.send_message("❌ Canal de aprovação não encontrado. Avise um administrador.", ephemeral=True)
            return
        
        cursor.execute("INSERT INTO registros (user_id, nome_ig, id_ig, tipo_registro, recrutador_id) VALUES (?, ?, ?, ?, ?)",
                       (interaction.user.id, self.nome_ig.value, self.id_ig.value, self.tipo_registro, self.recrutador_id))
        db.commit()
        registro_id = cursor.lastrowid

        recrutador_field = f"<@{self.recrutador_id}>" if self.recrutador_id != 0 else "Não informado"

        embed = discord.Embed(title="📋 Novo Pedido de Registro", color=discord.Color.gold())
        embed.set_footer(text=f"ID do Registro: {registro_id}")
        embed.add_field(name="**👤 SOLICITANTE**", value=f"{interaction.user.mention} (ID: {interaction.user.id})", inline=False)
        embed.add_field(name="**📝 DADOS**", value=f"Nome: {self.nome_ig.value}\nID: {self.id_ig.value}", inline=False)

        embed.add_field(name="**🤝 RECRUTADOR**", value=recrutador_field, inline=False)
        embed.add_field(name="**STATUS**", value="🟡 Aguardando análise.", inline=False)

        view = View()
        view.add_item(discord.ui.Button(style=discord.ButtonStyle.success, label="Aprovar", emoji="✅", custom_id=f"aprovar_{registro_id}"))
        view.add_item(discord.ui.Button(style=discord.ButtonStyle.danger, label="Recusar", emoji="❌", custom_id=f"recusar_{registro_id}"))

        await canal_aprovacao.send(embed=embed, view=view)
        await interaction.response.send_message("✅ Solicitação enviada! Aguarde a aprovação de um recrutador.", ephemeral=True)

class RecusaModal(Modal, title="❌ Recusar Registro"):
    motivo = TextInput(label="Motivo da recusa", style=discord.TextStyle.paragraph, placeholder="Ex: Nome ou ID inválido.", required=True, max_length=200)

    def __init__(self, registro_id: int):
        super().__init__()
        self.registro_id = registro_id

    async def on_submit(self, interaction: discord.Interaction):
        db.execute("UPDATE registros SET status = 'recusado', motivo_recusa = ? WHERE id = ?", (self.motivo.value, self.registro_id))
        db.commit()

        view = View.from_message(interaction.message)
        for item in view.children:
            item.disabled = True

        cursor = db.cursor()
        cursor.execute("SELECT user_id, nome_ig, id_ig, tipo_registro, recrutador_id FROM registros WHERE id = ?", (self.registro_id,))
        registro = cursor.fetchone()
        solicitante_id, nome_ig, id_ig, tipo_registro, recrutador_id = registro

        embed_recusado = discord.Embed(title="❌ Pedido de Registro — Recusado", color=discord.Color.red())
        embed_recusado.set_footer(text=f"ID do Registro: {self.registro_id}")
        embed_recusado.add_field(name="**🚫 RECUSADO POR**", value=f"{interaction.user.mention}", inline=False)
        embed_recusado.add_field(name="**📄 MOTIVO**", value=self.motivo.value, inline=False)
        embed_recusado.add_field(name="**STATUS**", value="🔴 Recusado pela staff.", inline=False)

        await interaction.response.edit_message(embed=embed_recusado, view=view)

        try:
            membro = await interaction.guild.fetch_member(solicitante_id)
            if membro:
                await membro.send(f"❌ Seu registro foi **recusado**.\n**Motivo:** {self.motivo.value}")
        except discord.NotFound:
            print(f"Não foi possível encontrar o membro {solicitante_id} para notificar sobre a recusa.")
        except discord.Forbidden:
            print(f"Não foi possível enviar DM para o membro {solicitante_id} sobre a recusa do registro {self.registro_id}.")

class RecrutadorSelect(Select):
    def __init__(self, opcoes, bot: commands.Bot):
        super().__init__(placeholder="Selecione quem te recrutou...", min_values=1, max_values=1, options=opcoes)
        self.bot = bot

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.send_modal(RegistroModal(bot=self.bot, recrutador_id=int(self.values[0]), tipo_registro="membro"))

class RecrutadorView(View):
    def __init__(self, opcoes, bot: commands.Bot):
        super().__init__(timeout=120)
        self.add_item(RecrutadorSelect(opcoes, bot))

class PainelView(View):
    def __init__(self, bot: commands.Bot):
        super().__init__(timeout=None)
        self.bot = bot

    @discord.ui.button(label="Registrar-se", style=discord.ButtonStyle.primary, custom_id="btn_registro_membro", emoji="👤")
    async def registrar_membro(self, interaction: discord.Interaction, button: discord.ui.Button):
        guild = interaction.guild
        
        todos_os_recrutadores = set()
        if not CARGO_RECRUTADOR_IDS:
            await interaction.response.send_message("❌ Nenhum recrutador encontrado. Avise um administrador.", ephemeral=True)
            return

        for cargo_id in CARGO_RECRUTADOR_IDS:
            cargo = guild.get_role(cargo_id)
            if cargo:
                for membro in cargo.members:
                    todos_os_recrutadores.add(membro)

        if not todos_os_recrutadores:
            await interaction.response.send_message("❌ Nenhum recrutador online ou configurado. Avise um administrador.", ephemeral=True)
            return

        opcoes = [discord.SelectOption(label=m.display_name, value=str(m.id)) for m in sorted(list(todos_os_recrutadores), key=lambda m: m.display_name)[:25]]
        await interaction.response.send_message("👇 Selecione o recrutador que te trouxe:", view=RecrutadorView(opcoes, self.bot), ephemeral=True)

class RankingView(View):
    def __init__(self, bot: commands.Bot):
        super().__init__(timeout=None)
        self.bot = bot

# ============================================================
#  O COG PRINCIPAL
# ============================================================
class RegistroCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        # Adiciona as views persistentes quando o cog é carregado
        self.bot.add_view(PainelView(bot=self.bot))
        self.bot.add_view(RankingView(bot=self.bot))

    async def get_ranking_recrutadores_embed(self, limit: int = 10):
        cursor = db.cursor()
        cursor.execute("""
            SELECT recrutador_id, COUNT(*) as total
            FROM registros
            WHERE status = 'aprovado' AND recrutador_id != 0
            GROUP BY recrutador_id
            ORDER BY total DESC
        """)
        ranking_data = cursor.fetchall()

        title = "🏆 Ranking de Recrutadores (Top 10)" if limit == 10 else "🏆 Ranking de Recrutadores (Completo)"
        embed = discord.Embed(title=title, color=discord.Color.gold())

        if not ranking_data:
            embed.description = "Ainda não há recrutamentos aprovados."
            return embed

        description = ""
        for i, (recrutador_id, total) in enumerate(ranking_data[:limit]):
            rank_emoji = {0: "🥇", 1: "🥈", 2: "🥉"}.get(i, f"**{i+1}.**")
            try:
                user = await self.bot.fetch_user(recrutador_id)
                description += f"{rank_emoji} {user.mention} - **{total}** recrutamento(s)\n"
            except discord.NotFound:
                description += f"{rank_emoji} `ID: {recrutador_id}` (usuário não encontrado) - **{total}** recrutamento(s)\n"

        embed.description = description
        fuso_horario_py = pytz.timezone('America/Asuncion')
        hora_atual_py = discord.utils.utcnow().astimezone(fuso_horario_py)
        embed.set_footer(text=f"Última atualização: {hora_atual_py.strftime('%d/%m/%Y %H:%M:%S')}")
        return embed

    async def atualizar_painel_ranking(self):
        """Encontra e atualiza a mensagem do painel de ranking."""
        if not CANAL_RANKING_ID:
            print("⚠️ CANAL_RANKING_ID não configurado. A atualização automática do ranking está desativada.")
            return

        try:
            channel = await self.bot.fetch_channel(CANAL_RANKING_ID)
        except (discord.NotFound, discord.Forbidden):
            print(f"❌ Erro: Não foi possível encontrar ou acessar o canal de ranking com ID {CANAL_RANKING_ID}.")
            return

        # Procura por uma mensagem de ranking existente para editar
        async for message in channel.history(limit=50):
            if message.author == self.bot.user and message.embeds and "Ranking de Recrutadores" in message.embeds[0].title:
                view = RankingView(bot=self.bot)
                embed = await self.get_ranking_recrutadores_embed(limit=10)
                await message.edit(embed=embed, view=view)
                print(f"✅ Painel de ranking de recrutadores editado no canal {channel.name}.")
                return
        
        # Se não encontrou, envia um novo
        view = RankingView(bot=self.bot)
        embed = await self.get_ranking_recrutadores_embed(limit=10)
        await channel.send(embed=embed, view=view)
        print(f"✅ Novo painel de ranking de recrutadores enviado para o canal {channel.name}.")


    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):
        if interaction.type != discord.InteractionType.component:
            return

        custom_id = interaction.data.get("custom_id", "")

        # ── Aprovar ──
        if custom_id.startswith("aprovar_"):
            await interaction.response.defer()
            registro_id = int(custom_id.split("_")[1])

            view = View.from_message(interaction.message)
            for item in view.children:
                item.disabled = True

            cursor = db.cursor()
            cursor.execute("SELECT user_id, nome_ig, id_ig, tipo_registro, recrutador_id FROM registros WHERE id = ?", (registro_id,))
            registro = cursor.fetchone()

            if not registro:
                await interaction.followup.send("❌ Registro não encontrado no banco de dados.", ephemeral=True)
                return
            
            solicitante_id, nome_ig, id_ig, tipo_registro, recrutador_id = registro
            try:
                membro = await interaction.guild.fetch_member(solicitante_id)
            except discord.NotFound:
                membro = None

            if not membro:
                await interaction.followup.send("❌ Membro não encontrado no servidor. Ele pode ter saído.", ephemeral=True)
                return

            novo_nick = f"{nome_ig} | {id_ig}"
            try:
                await membro.edit(nick=novo_nick)
            except discord.Forbidden:
                await interaction.channel.send(f"⚠️ Sem permissão para renomear {membro.mention}.", silent=True)

            cargo_para_dar = interaction.guild.get_role(CARGO_MEMBRO_ID)

            if cargo_para_dar:
                try:
                    await membro.add_roles(cargo_para_dar)
                except discord.Forbidden:
                    # Este followup pode não funcionar se a interação original já foi respondida.
                    await interaction.followup.send("⚠️ Sem permissão para adicionar cargo.", ephemeral=True)
                    return

            db.execute("""
                UPDATE registros
                SET status = 'aprovado', aprovado_por = ?, data_aprovacao = datetime('now', 'localtime')
                WHERE id = ?
            """, (interaction.user.id, registro_id))
            db.commit()

            recrutador_field = f"<@{recrutador_id}>" if recrutador_id and recrutador_id != 0 else "Não informado"
            embed_aprovado = discord.Embed(title="✅ Pedido de Registro — Aprovado", color=discord.Color.green())
            embed_aprovado.set_footer(text=f"ID do Registro: {registro_id}")
            embed_aprovado.add_field(name="**👤 SOLICITANTE**", value=f"{membro.mention} (ID: `{membro.id}`)", inline=False)
            embed_aprovado.add_field(name="**📝 DADOS**", value=f"Nome: `{nome_ig}`\nID: `{id_ig}`", inline=False)
            embed_aprovado.add_field(name="**🤝 RECRUTADOR**", value=recrutador_field, inline=False)
            embed_aprovado.add_field(name="**✅ APROVADO POR**", value=f"{interaction.user.mention}", inline=False)
            embed_aprovado.add_field(name="**STATUS**", value="🟢 Aprovado por um recrutador.", inline=False)

            await interaction.edit_original_response(embed=embed_aprovado, view=view)

            try:
                await membro.send(f"🎉 Parabéns! Seu registro foi **aprovado**.\nSeu nick foi definido como: `{novo_nick}`")
            except discord.Forbidden:
                print(f"Não foi possível enviar DM para {membro.name}.")
            
            # Atualiza o painel de ranking
            await self.atualizar_painel_ranking()
            return

        # ── Recusar ──
        if custom_id.startswith("recusar_"):
            registro_id = int(custom_id.split("_")[1])
            await interaction.response.send_modal(RecusaModal(registro_id=registro_id))
            
    @app_commands.command(name="ranking", description="Exibe o painel com o ranking de recrutadores.")
    @app_commands.default_permissions(administrator=True)
    async def ranking(self, interaction: discord.Interaction, canal: discord.TextChannel = None):
        """Configura o painel com o ranking de recrutadores em um canal."""
        target_channel = canal or self.bot.get_channel(CANAL_RANKING_ID)
        if not target_channel:
            await interaction.response.send_message(
                "❌ Por favor, especifique um canal ou defina `CANAL_RANKING_ID` no seu arquivo de configuração.",
                ephemeral=True
            )
            return

        await interaction.response.defer(ephemeral=True, thinking=True)
        view = RankingView(bot=self.bot)
        embed = await self.get_ranking_recrutadores_embed(limit=10)
        await target_channel.send(embed=embed, view=view)
        await interaction.followup.send(f"✅ Painel de ranking configurado com sucesso em {target_channel.mention}!")

    @app_commands.command(name="ranking_recrutadores_completo", description="Exibe a lista completa do ranking de recrutadores.")
    @app_commands.default_permissions(administrator=True)
    async def ranking_completo(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        embed = await self.get_ranking_recrutadores_embed(limit=None)
        await interaction.followup.send(embed=embed, ephemeral=True)

    @app_commands.command(name="resetar_ranking_recrutadores", description="Reseta o ranking de recrutadores.")
    @app_commands.default_permissions(administrator=True)
    async def resetar_ranking(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)

        # Executa o reset
        db.execute("DELETE FROM registros")
        db.commit()

        # Atualiza o painel principal
        await self.atualizar_painel_ranking()

        await interaction.followup.send("✅ O ranking de recrutadores foi resetado e o painel atualizado.", ephemeral=True)

    @app_commands.command(name="setup_painel", description="Configura o painel de registro no canal definido.")
    @app_commands.default_permissions(administrator=True)
    async def setup_painel(self, interaction: discord.Interaction):
        """Configura o painel de registro no canal."""
        canal = self.bot.get_channel(CANAL_REGISTRO_ID)
        if not canal:
            await interaction.response.send_message("❌ Canal de registro não encontrado. Verifique `CANAL_REGISTRO_ID`.", ephemeral=True)
            return

        await interaction.response.defer(ephemeral=True, thinking=True)
        
        try:
            await canal.purge(limit=100)
        except discord.Forbidden:
            await interaction.followup.send("⚠️ Aviso: Não tenho permissão para limpar as mensagens antigas neste canal.", ephemeral=True)

        embed = discord.Embed(
            title="📋 Sistema de Registro",
            description="*Clique no botão abaixo para realizar seu **registro**.\n*Após o registro, aguarde a aprovação para receber seu cargo e ter acesso completo ao servidor.",
            color=0x2F4F4F
        )

        # --- Lógica de Imagem Aprimorada ---
        arquivo_imagem = None
        caminho_imagem_local = os.path.join(os.path.dirname(__file__), '..', 'assets', 'painel_registro.png')

        if os.path.exists(caminho_imagem_local):
            print("[DIAGNÓSTICO WL] Usando imagem local 'assets/painel_registro.png'.")
            arquivo_imagem = discord.File(caminho_imagem_local, filename="painel_registro.png")
            embed.set_image(url="attachment://painel_registro.png")
        elif REGISTRO_PAINEL_IMAGE_URL:
            print(f"[DIAGNÓSTICO WL] Usando imagem da URL: {REGISTRO_PAINEL_IMAGE_URL}")
            embed.set_image(url=REGISTRO_PAINEL_IMAGE_URL)
        else:
            print("⚠️ [DIAGNÓSTICO WL] A variável REGISTRO_PAINEL_IMAGE_URL não está definida no .env. O painel será criado sem imagem.")

        await canal.send(embed=embed, view=PainelView(bot=self.bot), file=arquivo_imagem)
        await interaction.followup.send(f"✅ Painel de registro configurado com sucesso no canal {canal.mention}!", ephemeral=True)

async def setup(bot: commands.Bot):
    await bot.add_cog(RegistroCog(bot))