
import os
from dotenv import load_dotenv

# Carrega as variáveis de ambiente do arquivo .env ANTES de qualquer outro import
load_dotenv()

import discord
from discord.ext import commands
TOKEN = os.getenv('DISCORD_TOKEN')

# Define os intents necessários
intents = discord.Intents.default()
intents.message_content = True
intents.members = True

# Cria a instância do bot
bot = commands.Bot(command_prefix='!', intents=intents)

@bot.event
async def on_ready():
    """Evento que é acionado quando o bot está online e pronto."""
    print(f'Bot conectado como {bot.user}')
    print('------')
    await load_all_cogs()
    print("Sincronizando comandos de barra com o Discord...")
    try:
        synced = await bot.tree.sync()
        print(f"-> {len(synced)} comando(s) de barra sincronizado(s).")
    except Exception as e:
        print(f"Falha ao sincronizar comandos: {e}")

async def load_all_cogs():
    """Carrega todos os arquivos .py da pasta /cogs como extensões."""
    print("Carregando cogs...")
    # Constrói um caminho absoluto para a pasta 'cogs' para evitar erros de diretório
    script_dir = os.path.dirname(os.path.abspath(__file__))
    cogs_dir = os.path.join(script_dir, 'cogs')

    if not os.path.isdir(cogs_dir):
        print(f"ERRO: O diretório de cogs não foi encontrado em '{cogs_dir}'. Verifique a estrutura de pastas.")
        return

    for filename in os.listdir(cogs_dir):
        if filename.endswith('.py'):
            try:
                await bot.load_extension(f'cogs.{filename[:-3]}')
                print(f"  -> Cog '{filename}' carregado com sucesso.")
            except Exception as e:
                print(f"  -> Falha ao carregar o cog '{filename}': {e}")
    
    # Tenta carregar o cog de tático que pode estar fora da pasta
    if os.path.exists(os.path.join(script_dir, 'tatico.py')):
        try:
            await bot.load_extension('tatico')
            print("  -> Cog 'tatico.py' carregado com sucesso da pasta raiz.")
        except Exception as e:
            print(f"  -> Falha ao carregar o cog 'tatico.py': {e}")

# Inicia o bot
if __name__ == "__main__":
    if TOKEN:
        bot.run(TOKEN)
    else:
        print("Erro: O token do Discord não foi encontrado no arquivo .env")
