import discord
from discord.ext import commands
from discord import app_commands
import os
import sqlite3
from datetime import datetime

# --- Configurações ---
def get_first_id(env_var: str, default: int = 0) -> int:
    """Lê uma variável de ambiente, pega o primeiro ID se houver múltiplos, e converte para int."""
    value = os.getenv(env_var)
    if not value:
        return default
    # Pega apenas o primeiro valor antes da vírgula, se houver, e remove espaços.
    first_value = value.split(',')[0].strip()
    return int(first_value) if first_value.isdigit() else default

CARGO_GERENTE_IDS_STR = os.getenv("CARGO_GERENTE_ID", "")
CARGO_GERENTE_IDS = {int(role_id.strip()) for role_id in CARGO_GERENTE_IDS_STR.split(',') if role_id.strip()}
CANAL_PAINEL_GERENTE_ID = get_first_id("CANAL_PAINEL_GERENTE_ID")
CANAL_LOG_PUBLICO_ADV_ID = get_first_id("CANAL_LOG_PUBLICO_ADV_ID")
CANAL_LOG_PRIVADO_ADV_ID = get_first_id("CANAL_LOG_PRIVADO_ADV_ID")
ROLES_INTOCAVEIS_IDS_STR = os.getenv("ROLES_INTOCAVEIS_IDS", "")
ROLES_INTOCAVEIS_IDS = {int(role_id.strip()) for role_id in ROLES_INTOCAVEIS_IDS_STR.split(',') if role_id.strip()}
CARGO_ADV_G1_ID = get_first_id("CARGO_ADV_G1_ID")
CARGO_ADV_G2_ID = get_first_id("CARGO_ADV_G2_ID")
CARGO_ADV_G3_ID = get_first_id("CARGO_ADV_G3_ID")
CARGO_EXONERADO_ID = get_first_id("CARGO_EXONERADO_ID")
CARGOS_DE_ADV = {CARGO_ADV_G1_ID, CARGO_ADV_G2_ID, CARGO_ADV_G3_ID}
ADV_LOG_PUBLICO_IMAGE_URL = os.getenv("ADV_LOG_PUBLICO_IMAGE_URL")
ADV_PAINEL_GERENTE_IMAGE_URL = os.getenv("ADV_PAINEL_GERENTE_IMAGE_URL")

# --- Diagnóstico ---
print(f"[DIAGNÓSTICO ADV] URL da imagem do log público: '{ADV_LOG_PUBLICO_IMAGE_URL}'")
print(f"[DIAGNÓSTICO ADV] URL da imagem do painel de gerente: '{ADV_PAINEL_GERENTE_IMAGE_URL}'")

# --- Banco de Dados ---
db_path = os.path.join(os.path.dirname(__file__), '..', 'registro.db')
db = sqlite3.connect(db_path)
db.execute("""
    CREATE TABLE IF NOT EXISTS advertencias (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        gravidade TEXT NOT NULL, -- G1, G2, G3, EXO
        motivo TEXT NOT NULL,
        prova TEXT,
        aplicado_por_id INTEGER NOT NULL,
        data_aplicacao TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'ativa', -- ativa, removida
        removido_por_id INTEGER,
        motivo_remocao TEXT,
        data_remocao TEXT
    )
""")
db.commit()

# --- Funções Auxiliares ---
async def buscar_usuario(guild: discord.Guild, identificador: str):
    """Busca um usuário por ID do Discord ou ID do jogo."""
    try:
        # Tenta buscar por ID do Discord
        membro = await guild.fetch_member(int(identificador))
        if membro:
            return membro
    except (ValueError, discord.NotFound):
        # Se não for um ID do Discord válido, busca no banco de dados pelo ID do jogo
        cursor = db.cursor()
        cursor.execute("SELECT user_id FROM registros WHERE id_ig = ?", (identificador,))
        resultado = cursor.fetchone()
        if resultado:
            try:
                return await guild.fetch_member(resultado[0])
            except discord.NotFound:
                return None
    return None

def calcular_nova_gravidade(user_id: int, gravidade_aplicada: str):
    """Calcula a gravidade escalonada de uma nova advertência com base nas regras."""
    if gravidade_aplicada == 'EXO':
        return 'EXO'

    cursor = db.cursor()
    cursor.execute("SELECT gravidade FROM advertencias WHERE user_id = ? AND status = 'ativa' ORDER BY id DESC LIMIT 1", (user_id,))
    ultima_adv = cursor.fetchone()

    if not ultima_adv:
        return gravidade_aplicada # Primeira advertência
    
    ultima_gravidade = ultima_adv[0]

    if ultima_gravidade == 'G1':
        if gravidade_aplicada == 'G1': return 'G2' # G1 + G1 = G2
        if gravidade_aplicada == 'G2': return 'G3' # G1 + G2 = G3
        return 'G3' # G1 + G3 = G3

    elif ultima_gravidade == 'G2':
        if gravidade_aplicada == 'G1': return 'G3' # G2 + G1 = G3
        if gravidade_aplicada == 'G2': return 'EXO' # G2 + G2 = EXO
        return 'EXO' # G2 + G3 = EXO

    elif ultima_gravidade == 'G3':
        # Qualquer advertência em cima de uma G3 resulta em EXO
        return 'EXO'

    return gravidade_aplicada # Caso base

# --- Modals e Views ---

class AplicarAdvModal(discord.ui.Modal, title="Aplicar Advertência"):
    identificador_membro = discord.ui.TextInput(label="ID do Discord ou ID do Jogo do Membro")
    motivo = discord.ui.TextInput(label="Motivo da Advertência", style=discord.TextStyle.paragraph)
    prova = discord.ui.TextInput(label="URL da Prova (Imagem/Vídeo)", required=False)
    como_revogar = discord.ui.TextInput(label="Como Revogar (se aplicável)", placeholder="Ex: 500k + 3 dias ou 4 rotas de farm", required=False)

    def __init__(self, bot: commands.Bot):
        super().__init__(timeout=None)
        self.bot = bot

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)

        membro = await buscar_usuario(interaction.guild, self.identificador_membro.value)
        if not membro:
            await interaction.followup.send("❌ Membro não encontrado com o ID fornecido.", ephemeral=True)
            return

        view = discord.ui.View()
        select = discord.ui.Select(placeholder="Selecione a gravidade da advertência...", options=[
            discord.SelectOption(label="Advertência Leve (G1)", value="G1"),
            discord.SelectOption(label="Advertência Média (G2)", value="G2"),
            discord.SelectOption(label="Advertência Grave (G3)", value="G3"),
            discord.SelectOption(label="Exoneração (EXO)", value="EXO", emoji="🔥"),
        ])

        async def select_callback(select_interaction: discord.Interaction):
            # Defer a resposta imediatamente para evitar que a interação expire.
            await select_interaction.response.defer(ephemeral=True, thinking=True)

            gravidade_selecionada = select.values[0]
            nova_gravidade = calcular_nova_gravidade(membro.id, gravidade_selecionada)

            db.execute("""
                INSERT INTO advertencias (user_id, gravidade, motivo, prova, aplicado_por_id, data_aplicacao)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (membro.id, nova_gravidade, self.motivo.value, self.prova.value, interaction.user.id, datetime.now().isoformat()))
            db.commit()

            # --- Enviar Logs ---
            canal_log_publico = self.bot.get_channel(CANAL_LOG_PUBLICO_ADV_ID)
            canal_log_privado = self.bot.get_channel(CANAL_LOG_PRIVADO_ADV_ID)

            # Log Público
            if canal_log_publico:
                # Busca o ID do jogo no banco de dados de registros
                cursor = db.cursor()
                cursor.execute("SELECT id_ig FROM registros WHERE user_id = ?", (membro.id,))
                resultado_id_ig = cursor.fetchone()
                id_do_jogo = resultado_id_ig[0] if resultado_id_ig else "Não cadastrado"

                embed_publico = discord.Embed(
                    title="NOVO PLAYER ADVERTIDO",
                    color=discord.Color.red() if nova_gravidade == 'EXO' else discord.Color.orange()
                )
                embed_publico.add_field(name="NOME", value=membro.mention, inline=False)
                embed_publico.add_field(name="ID", value=f"`{id_do_jogo}`", inline=False)
                embed_publico.add_field(name="MOTIVO", value=self.motivo.value, inline=False)
                embed_publico.add_field(name="PUNIÇÃO", value=nova_gravidade, inline=False)
                
                # --- Lógica de Imagem Aprimorada ---
                arquivo_imagem_publico = None
                caminho_imagem_local_publico = os.path.join(os.path.dirname(__file__), '..', 'assets', 'log_adv.png')

                if os.path.exists(caminho_imagem_local_publico):
                    arquivo_imagem_publico = discord.File(caminho_imagem_local_publico, filename="log_adv.png")
                    embed_publico.set_image(url="attachment://log_adv.png")
                elif ADV_LOG_PUBLICO_IMAGE_URL:
                    embed_publico.set_image(url=ADV_LOG_PUBLICO_IMAGE_URL)

                revogacao_texto = self.como_revogar.value if self.como_revogar.value else "Contate um gerente para mais informações."
                if nova_gravidade != 'EXO':
                    embed_publico.add_field(name="REVOGAÇÃO", value=revogacao_texto, inline=False)
                
                await canal_log_publico.send(embed=embed_publico, file=arquivo_imagem_publico)

            # Log Privado
            if canal_log_privado:
                embed_privado = discord.Embed(
                    title=f"🔥 LOG DE ADVERTÊNCIA - {nova_gravidade} 🔥" if nova_gravidade == 'EXO' else f"📄 Log de Advertência - {nova_gravidade}",
                    color=discord.Color.dark_red() if nova_gravidade == 'EXO' else discord.Color.dark_orange()
                )
                embed_privado.add_field(name="Membro Advertido", value=f"{membro.mention} (`{membro.id}`)", inline=False)
                embed_privado.add_field(name="Motivo", value=self.motivo.value, inline=False)
                embed_privado.add_field(name="Aplicado por", value=interaction.user.mention, inline=False)
                if self.prova.value:
                    embed_privado.add_field(name="Prova", value=f"Clique para ver", inline=False)
                await canal_log_privado.send(embed=embed_privado)

            # DM para o usuário
            try:
                dm_message = (
                    f"Você foi **exonerado** no servidor **{interaction.guild.name}**.\n"
                    f"**Motivo:** {self.motivo.value}\n\n"
                    "**Para resolver sua situação, por favor, abra um ticket.**"
                ) if nova_gravidade == 'EXO' else (
                    f"Você recebeu uma advertência de gravidade **{nova_gravidade}**.\n"
                    f"**Motivo:** {self.motivo.value}\n"
                    "Para mais informações, contate um gerente."
                )
                await membro.send(dm_message)
            except discord.Forbidden:
                print(f"Não foi possível enviar DM para {membro.name}")

            # --- Gerenciamento de Cargos ---
            try:
                # Remove cargos de advertência antigos
                cargos_adv_atuais = [role for role in membro.roles if role.id in CARGOS_DE_ADV]
                if cargos_adv_atuais:
                    await membro.remove_roles(*cargos_adv_atuais, reason="Atualização de advertência.")

                # Adiciona o novo cargo de advertência (se não for EXO)
                if nova_gravidade != 'EXO':
                    mapa_cargos = {'G1': CARGO_ADV_G1_ID, 'G2': CARGO_ADV_G2_ID, 'G3': CARGO_ADV_G3_ID}
                    id_novo_cargo = mapa_cargos.get(nova_gravidade)
                    if id_novo_cargo:
                        novo_cargo = interaction.guild.get_role(id_novo_cargo)
                        if novo_cargo:
                            await membro.add_roles(novo_cargo, reason=f"Advertência {nova_gravidade} aplicada.")
                        else:
                            await select_interaction.followup.send(f"⚠️ O cargo para a advertência {nova_gravidade} não foi encontrado.", ephemeral=True)
            except discord.Forbidden:
                await select_interaction.followup.send(f"⚠️ **Erro de Permissão:** Não tenho permissão para gerenciar os cargos de advertência de {membro.mention}. Verifique se o cargo do bot está acima dos cargos de advertência na hierarquia do servidor.", ephemeral=True)

            # Ação de Exoneração
            if nova_gravidade == 'EXO':
                await select_interaction.edit_original_response(content=f"🔥 Aplicando exoneração em {membro.mention}...", view=None)
                try:
                    # Remove todos os cargos, exceto os intocáveis
                    cargos_para_remover = [role for role in membro.roles if role.id not in ROLES_INTOCAVEIS_IDS and not role.is_default()]
                    if cargos_para_remover:
                        await membro.remove_roles(*cargos_para_remover, reason=f"Exonerado por {interaction.user.name}")
                    
                    # Adiciona o cargo de exonerado
                    cargo_exonerado = interaction.guild.get_role(CARGO_EXONERADO_ID)
                    if not cargo_exonerado:
                        await select_interaction.followup.send("❌ **ERRO DE CONFIGURAÇÃO:** O `CARGO_EXONERADO_ID` não foi encontrado. A ação não pôde ser completada.", ephemeral=True)
                        return # Para a execução aqui

                    # Verifica se o bot pode gerenciar o cargo de exonerado
                    if not interaction.guild.me.top_role > cargo_exonerado:
                        await select_interaction.followup.send(f"❌ **ERRO DE HIERARQUIA:** Não consigo adicionar o cargo {cargo_exonerado.mention} porque ele está acima do meu cargo na lista de cargos do servidor.", ephemeral=True)
                        return # Para a execução aqui

                    await membro.add_roles(cargo_exonerado, reason=f"Exonerado por {interaction.user.name}")
                    await select_interaction.followup.send(f"✅ {membro.name} foi exonerado e recebeu o cargo correspondente.", ephemeral=True)

                except discord.Forbidden:
                    await select_interaction.followup.send(f"⚠️ **ERRO DE PERMISSÃO:** Não tenho a permissão 'Gerenciar Cargos' para modificar os cargos de {membro.mention}. A exoneração foi registrada, mas a ação automática falhou.", ephemeral=True)
            else:
                await select_interaction.edit_original_response(content=f"✅ Advertência **{nova_gravidade}** aplicada com sucesso a {membro.mention}.", view=None)

        select.callback = select_callback
        view.add_item(select)
        await interaction.followup.send("Selecione a gravidade da advertência:", view=view, ephemeral=True)


class RemoverAdvModal(discord.ui.Modal, title="Remover Advertência"):
    identificador_membro = discord.ui.TextInput(label="ID do Discord ou ID do Jogo do Membro")
    motivo_remocao = discord.ui.TextInput(label="Justificativa para a Remoção", style=discord.TextStyle.paragraph)

    def __init__(self, bot: commands.Bot):
        super().__init__(timeout=None)
        self.bot = bot

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)

        membro = await buscar_usuario(interaction.guild, self.identificador_membro.value)
        if not membro:
            await interaction.followup.send("❌ Membro não encontrado com o ID fornecido.", ephemeral=True)
            return

        cursor = db.cursor()
        cursor.execute("SELECT id, gravidade, motivo, data_aplicacao FROM advertencias WHERE user_id = ? AND status = 'ativa' ORDER BY id DESC", (membro.id,))
        advs_ativas = cursor.fetchall()

        if not advs_ativas:
            await interaction.followup.send(f"❌ O membro {membro.mention} não possui advertências ativas.", ephemeral=True)
            return

        # Cria as opções para o menu de seleção
        options = []
        for adv_id, gravidade, motivo, data in advs_ativas:
            data_formatada = datetime.fromisoformat(data).strftime('%d/%m/%Y')
            options.append(discord.SelectOption(
                label=f"{gravidade} - Aplicada em {data_formatada}",
                description=motivo[:100], # Limita a descrição para 100 caracteres
                value=str(adv_id)
            ))

        select = discord.ui.Select(placeholder="Selecione a advertência para remover...", options=options)

        async def select_callback(select_interaction: discord.Interaction):
            adv_id_para_remover = int(select.values[0])
            
            # Encontra a gravidade da advertência selecionada
            adv_selecionada = next((adv for adv in advs_ativas if adv[0] == adv_id_para_remover), None)
            if not adv_selecionada: return # Segurança
            gravidade_removida = adv_selecionada[1]

            # Atualiza o banco de dados
            db.execute("""
                UPDATE advertencias SET status = 'removida', removido_por_id = ?, motivo_remocao = ?, data_remocao = ? WHERE id = ?
            """, (interaction.user.id, self.motivo_remocao.value, datetime.now().isoformat(), adv_id_para_remover))
            db.commit()

            # --- Gerenciamento de Cargos ---
            try:
                # Remove todos os cargos de advertência
                cargos_adv_atuais = [role for role in membro.roles if role.id in CARGOS_DE_ADV]
                if cargos_adv_atuais:
                    await membro.remove_roles(*cargos_adv_atuais, reason="Remoção/ajuste de advertência.")

                # Verifica qual a nova advertência mais recente (se houver)
                cursor.execute("SELECT gravidade FROM advertencias WHERE user_id = ? AND status = 'ativa' ORDER BY id DESC LIMIT 1", (membro.id,))
                nova_adv_ativa = cursor.fetchone()

                # Adiciona o cargo da nova advertência mais recente
                if nova_adv_ativa:
                    nova_gravidade = nova_adv_ativa[0]
                    mapa_cargos = {'G1': CARGO_ADV_G1_ID, 'G2': CARGO_ADV_G2_ID, 'G3': CARGO_ADV_G3_ID}
                    id_novo_cargo = mapa_cargos.get(nova_gravidade)
                    if id_novo_cargo and (novo_cargo := interaction.guild.get_role(id_novo_cargo)):
                        await membro.add_roles(novo_cargo, reason=f"Ajuste de advertência para {nova_gravidade}.")
            except discord.Forbidden:
                await select_interaction.followup.send(f"⚠️ Não tenho permissão para gerenciar os cargos de advertência de {membro.mention}.", ephemeral=True)

            # --- Enviar Logs e DM ---
            canal_log_privado = self.bot.get_channel(CANAL_LOG_PRIVADO_ADV_ID)
            if canal_log_privado:
                embed_privado = discord.Embed(title=f"✅ Advertência Removida - {gravidade_removida}", color=discord.Color.green())
                embed_privado.add_field(name="Membro", value=f"{membro.mention} (`{membro.id}`)", inline=False)
                embed_privado.add_field(name="Removido por", value=interaction.user.mention, inline=False)
                embed_privado.add_field(name="Justificativa", value=self.motivo_remocao.value, inline=False)
                await canal_log_privado.send(embed=embed_privado)

            try:
                await membro.send(
                    f"Sua advertência de gravidade **{gravidade_removida}** foi **removida**.\n"
                    f"**Justificativa:** {self.motivo_remocao.value}"
                )
            except discord.Forbidden:
                print(f"Não foi possível enviar DM para {membro.name}")

            await select_interaction.response.edit_message(content=f"✅ Advertência de {membro.mention} removida com sucesso.", view=None)

        select.callback = select_callback
        view = discord.ui.View()
        view.add_item(select)
        await interaction.followup.send("Selecione qual advertência deseja remover:", view=view, ephemeral=True)


class ConsultarAdvModal(discord.ui.Modal, title="Consultar Advertências"):
    identificador_membro = discord.ui.TextInput(label="ID do Discord ou ID do Jogo do Membro")

    def __init__(self, bot: commands.Bot):
        super().__init__(timeout=None)
        self.bot = bot

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)

        membro_obj = await buscar_usuario(interaction.guild, self.identificador_membro.value)
        if not membro_obj:
            return await interaction.followup.send("❌ Membro não encontrado.", ephemeral=True)

        cursor = db.cursor()
        cursor.execute("SELECT gravidade, motivo, aplicado_por_id, data_aplicacao, status FROM advertencias WHERE user_id = ? ORDER BY id DESC", (membro_obj.id,))
        advertencias = cursor.fetchall()

        if not advertencias:
            return await interaction.followup.send(f"✅ O membro {membro_obj.mention} não possui advertências.", ephemeral=True)

        embed = discord.Embed(
            title=f"Histórico de Advertências de {membro_obj.display_name}",
            color=discord.Color.blue()
        )
        embed.set_thumbnail(url=membro_obj.display_avatar.url)

        for adv in advertencias[:10]: # Limita a 10 para não sobrecarregar
            gravidade, motivo, aplicado_por_id, data, status = adv
            data_formatada = datetime.fromisoformat(data).strftime('%d/%m/%Y')
            status_emoji = "🟢 Ativa" if status == 'ativa' else "⚪️ Removida"
            
            try:
                aplicado_por = await self.bot.fetch_user(aplicado_por_id)
                aplicado_por_str = aplicado_por.name
            except discord.NotFound:
                aplicado_por_str = f"ID {aplicado_por_id}"

            embed.add_field(
                name=f"**{gravidade}** - {data_formatada} ({status_emoji})",
                value=f"**Motivo:** {motivo}\n**Aplicado por:** {aplicado_por_str}",
                inline=False
            )
        
        await interaction.followup.send(embed=embed, ephemeral=True)


class PainelGerenteView(discord.ui.View):
    def __init__(self, bot: commands.Bot):
        super().__init__(timeout=None)
        self.bot = bot

    @discord.ui.button(label="Aplicar Advertência", style=discord.ButtonStyle.danger, custom_id="adv_aplicar", emoji="⚠️")
    async def aplicar_adv(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(AplicarAdvModal(bot=self.bot))

    @discord.ui.button(label="Remover Advertência", style=discord.ButtonStyle.success, custom_id="adv_remover", emoji="✅")
    async def remover_adv(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(RemoverAdvModal(bot=self.bot))

    @discord.ui.button(label="Consultar Advertências", style=discord.ButtonStyle.secondary, custom_id="adv_consultar", emoji="🔍")
    async def consultar_adv(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(ConsultarAdvModal(bot=self.bot))

# --- Cog Principal ---

class AdvertenciaCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.bot.add_view(PainelGerenteView(bot=self.bot))

    @app_commands.command(name="setup_painel_adv", description="Cria o painel de gerenciamento de advertências.")
    @app_commands.default_permissions(administrator=True)
    async def setup_painel_adv(self, interaction: discord.Interaction):
        canal = self.bot.get_channel(CANAL_PAINEL_GERENTE_ID)
        if not canal:
            return await interaction.response.send_message("❌ `CANAL_PAINEL_GERENTE_ID` não foi configurado.", ephemeral=True)

        await interaction.response.defer(ephemeral=True)

        embed = discord.Embed(
            title="Painel de Gerenciamento de Advertências",
            description="Utilize os botões abaixo para aplicar ou remover advertências dos membros.",
            color=discord.Color.dark_grey()
        )

        # --- Lógica de Imagem Aprimorada ---
        arquivo_imagem = None
        caminho_imagem_local = os.path.join(os.path.dirname(__file__), '..', 'assets', 'painel_adv.png')

        if os.path.exists(caminho_imagem_local):
            print("[DIAGNÓSTICO ADV] Usando imagem local 'assets/painel_adv.png'.")
            arquivo_imagem = discord.File(caminho_imagem_local, filename="painel_adv.png")
            embed.set_image(url="attachment://painel_adv.png")
        elif ADV_PAINEL_GERENTE_IMAGE_URL:
            print(f"[DIAGNÓSTICO ADV] Usando imagem da URL: {ADV_PAINEL_GERENTE_IMAGE_URL}")
            embed.set_image(url=ADV_PAINEL_GERENTE_IMAGE_URL)

        await canal.send(embed=embed, view=PainelGerenteView(bot=self.bot), file=arquivo_imagem)
        await interaction.followup.send(f"✅ Painel configurado em {canal.mention}!", ephemeral=True)

    @app_commands.command(name="consultar_adv", description="Consulta o histórico de advertências de um membro.")
    @app_commands.describe(membro="O membro para consultar (pode ser menção, ID do Discord ou ID do jogo).")
    async def consultar_adv(self, interaction: discord.Interaction, membro: str):
        await interaction.response.defer(ephemeral=True)
        
        # Extrai o ID se for uma menção
        if membro.startswith('<@') and membro.endswith('>'):
            membro_id_str = membro.strip('<@!>')
        else:
            membro_id_str = membro

        membro_obj = await buscar_usuario(interaction.guild, membro_id_str)
        if not membro_obj:
            return await interaction.followup.send("❌ Membro não encontrado.", ephemeral=True)

        cursor = db.cursor()
        cursor.execute("SELECT gravidade, motivo, aplicado_por_id, data_aplicacao, status FROM advertencias WHERE user_id = ? ORDER BY id DESC", (membro_obj.id,))
        advertencias = cursor.fetchall()

        if not advertencias:
            return await interaction.followup.send(f"✅ O membro {membro_obj.mention} não possui advertências.", ephemeral=True)

        embed = discord.Embed(
            title=f"Histórico de Advertências de {membro_obj.display_name}",
            color=discord.Color.blue()
        )
        embed.set_thumbnail(url=membro_obj.display_avatar.url)

        for adv in advertencias[:10]: # Limita a 10 para não sobrecarregar
            gravidade, motivo, aplicado_por_id, data, status = adv
            data_formatada = datetime.fromisoformat(data).strftime('%d/%m/%Y')
            
            status_emoji = "🟢 Ativa" if status == 'ativa' else "⚪️ Removida"
            
            try:
                aplicado_por = await self.bot.fetch_user(aplicado_por_id)
                aplicado_por_str = aplicado_por.name
            except discord.NotFound:
                aplicado_por_str = f"ID {aplicado_por_id}"

            embed.add_field(
                name=f"**{gravidade}** - {data_formatada} ({status_emoji})",
                value=f"**Motivo:** {motivo}\n**Aplicado por:** {aplicado_por_str}",
                inline=False
            )
        
        await interaction.followup.send(embed=embed, ephemeral=True)

async def setup(bot: commands.Bot):
    await bot.add_cog(AdvertenciaCog(bot))