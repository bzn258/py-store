import discord
from discord import ui, app_commands
from discord.ext import commands
import asyncio
import os
import io

# --- Configurações (Lidas do .env) ---
CANAL_TICKETS_PAINEL_ID = int(os.getenv("CANAL_TICKETS_PAINEL_ID", 0))
CANAL_TRANSCRIPT_ID = int(os.getenv("CANAL_TRANSCRIPT_ID", 0))
CANAL_TRANSCRIPT_PRIVADO_ID = int(os.getenv("CANAL_TRANSCRIPT_PRIVADO_ID", 0))
CANAL_TRANSCRIPT_LIDER_ID = int(os.getenv("CANAL_TRANSCRIPT_LIDER_ID", 0))
CARGO_STAFF_ID = int(os.getenv("CARGO_STAFF_ID", 0))
CARGOS_LIDER_IDS_STR = os.getenv("CARGOS_LIDER_IDS", "")
CARGOS_LIDER_IDS = {int(role_id.strip()) for role_id in CARGOS_LIDER_IDS_STR.split(',') if role_id.strip()}
DONO_ID = int(os.getenv("DONO_ID", 0))
TICKET_PAINEL_IMAGE_URL = os.getenv("TICKET_PAINEL_IMAGE_URL") # URL para a imagem do painel de tickets

# --- Diagnóstico ---
print(f"[DIAGNÓSTICO TICKET] URL da imagem do painel de tickets: '{TICKET_PAINEL_IMAGE_URL}'")


class AcoesTicketView(ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    async def get_ticket_owner(self, interaction: discord.Interaction) -> discord.Member | None:
        """Busca o dono do ticket a partir do topic do canal."""
        if not interaction.channel.topic or not interaction.channel.topic.startswith("ticket:"):
            return None
        
        try:
            user_id = int(interaction.channel.topic.split(":")[1])
            return await interaction.guild.fetch_member(user_id)
        except (ValueError, IndexError, discord.NotFound):
            return None

    @ui.button(label="Pokar Jogador", style=discord.ButtonStyle.secondary, emoji="🔔", custom_id="pocar_btn")
    async def pocar_callback(self, interaction: discord.Interaction, button: ui.Button):
        if CARGO_STAFF_ID != 0 and discord.utils.get(interaction.user.roles, id=CARGO_STAFF_ID) is None:
            return await interaction.response.send_message("❌ Apenas a Staff pode usar este botão.", ephemeral=True)
        
        cliente = await self.get_ticket_owner(interaction)
        if not cliente:
            return await interaction.response.send_message("ERRO: Não foi possível identificar o dono deste ticket.", ephemeral=True)

        try:
            await cliente.send(f"🔔 **{interaction.user.display_name}** está te chamando no seu ticket no servidor **{interaction.guild.name}**!")
            await interaction.response.send_message(f"✅ {cliente.mention} foi 'pokado' no privado.", ephemeral=True)
        except discord.Forbidden:
            await interaction.response.send_message(f"❌ Não consegui enviar PV para {cliente.mention} (DMs fechadas).", ephemeral=True)

    @ui.button(label="Fechar Ticket", style=discord.ButtonStyle.danger, emoji="🔒", custom_id="fechar_ticket_btn")
    async def fechar_callback(self, interaction: discord.Interaction, button: ui.Button):
        cliente = await self.get_ticket_owner(interaction)
        
        await interaction.response.send_message("⚙️ Gerando logs e encerrando canal...", ephemeral=True)

        historico_mensagens = []
        async for message in interaction.channel.history(limit=None, oldest_first=True):
            time = message.created_at.strftime('%d/%m/%Y %H:%M')
            historico_mensagens.append(f"[{time}] {message.author.display_name}: {message.content}")
        
        conteudo_log = "\n".join(historico_mensagens)
        nome_arquivo = f"log-{interaction.channel.name}.txt"
        
        buffer = io.BytesIO(conteudo_log.encode('utf-8'))
        arquivo_log = discord.File(buffer, filename=nome_arquivo)

        if cliente:
            try:
                embed_pv = discord.Embed(
                    title="📄 Histórico do seu Ticket",
                    description=f"Seu atendimento em **{interaction.guild.name}** foi finalizado. Abaixo está o arquivo com todas as mensagens.",
                    color=discord.Color.blue()
                )
                await cliente.send(embed=embed_pv, file=arquivo_log)
            except discord.Forbidden:
                print(f"DM de {cliente.name} está fechada.")
        
        buffer.seek(0)

        log_channel_id = CANAL_TRANSCRIPT_ID

        if interaction.channel.name.startswith("🚫-denuncia-"):
            cargo_staff = interaction.guild.get_role(CARGO_STAFF_ID)
            
            if cargo_staff and not interaction.channel.permissions_for(cargo_staff).view_channel:
                log_channel_id = CANAL_TRANSCRIPT_PRIVADO_ID

                is_leader_denunciation = True
                for cargo_id in CARGOS_LIDER_IDS:
                    cargo_lider = interaction.guild.get_role(cargo_id)
                    if cargo_lider and interaction.channel.permissions_for(cargo_lider).view_channel:
                        is_leader_denunciation = False
                        break
                if is_leader_denunciation:
                    log_channel_id = CANAL_TRANSCRIPT_LIDER_ID

        canal_log = interaction.guild.get_channel(log_channel_id)
        if canal_log:
            await canal_log.send(f"✅ Ticket `{interaction.channel.name}` fechado por {interaction.user.mention}.", file=discord.File(buffer, filename=nome_arquivo))
        else:
            print(f"AVISO: Canal de log com ID {log_channel_id} não encontrado. Verifique as configurações.")

        await asyncio.sleep(3)
        try:
            await interaction.channel.delete()
        except discord.NotFound:
            pass

class DenunciaTipoSelect(ui.Select):
    def __init__(self, original_interaction: discord.Interaction):
        self.original_interaction = original_interaction
        options = [
            discord.SelectOption(label="Membro Comum", value="membro", description="Denunciar um membro que não faz parte da staff.", emoji="👤"),
            discord.SelectOption(label="Sub Líder / Gerente", value="sub-lider", description="Denunciar um membro da staff (Gerente, Recrutador, etc).", emoji="👮"),
            discord.SelectOption(label="Líder", value="lider", description="Denunciar um Líder.", emoji="👑"),
        ]
        super().__init__(placeholder="Selecione o tipo de cargo do denunciado...", options=options, custom_id="denuncia_tipo_select")

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)

        topic_procurado = f"ticket:{interaction.user.id}"
        if discord.utils.get(interaction.guild.text_channels, topic=topic_procurado):
            return await interaction.followup.send("❌ Você já tem um ticket aberto.", ephemeral=True)

        tipo_denunciado = self.values[0]

        overwrites = {
            interaction.guild.default_role: discord.PermissionOverwrite(view_channel=False),
            interaction.user: discord.PermissionOverwrite(view_channel=True, send_messages=True, attach_files=True),
            interaction.guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, attach_files=True)
        }

        dono = interaction.guild.get_member(DONO_ID)
        cargo_staff = interaction.guild.get_role(CARGO_STAFF_ID)

        if tipo_denunciado == "lider":
            if dono: overwrites[dono] = discord.PermissionOverwrite(view_channel=True)
            aviso_perm = f"Este ticket é confidencial e visível apenas para {dono.mention if dono else 'o Dono'}."
        
        elif tipo_denunciado == "sub-lider":
            for cargo_id in CARGOS_LIDER_IDS:
                cargo_lider = interaction.guild.get_role(cargo_id)
                if cargo_lider: overwrites[cargo_lider] = discord.PermissionOverwrite(view_channel=True)
            if dono: overwrites[dono] = discord.PermissionOverwrite(view_channel=True)
            aviso_perm = "Este ticket é confidencial e visível apenas para a Liderança."
        
        else: # Membro comum
            if cargo_staff: overwrites[cargo_staff] = discord.PermissionOverwrite(view_channel=True)
            for cargo_id in CARGOS_LIDER_IDS:
                cargo_lider = interaction.guild.get_role(cargo_id)
                if cargo_lider: overwrites[cargo_lider] = discord.PermissionOverwrite(view_channel=True)
            if dono: overwrites[dono] = discord.PermissionOverwrite(view_channel=True)
            aviso_perm = "A Staff já foi notificada e atenderá em breve."

        nome_canal = f"🚫-denuncia-{interaction.user.id}"
        novo_canal = await interaction.guild.create_text_channel(
            name=nome_canal,
            overwrites=overwrites,
            category=self.original_interaction.channel.category,
            topic=f"ticket:{interaction.user.id}"
        )

        embed_boas_vindas = discord.Embed(
            title="👋 Denúncia Registrada", 
            description=f"Obrigado, {interaction.user.mention}. Sua denúncia foi registrada com o nível de sigilo apropriado.\n\n{aviso_perm}\n\nPor favor, envie todas as provas (prints, vídeos, e o nome/ID do acusado) aqui.", 
            color=discord.Color.red()
        )
        await novo_canal.send(content=f"{interaction.user.mention}", embed=embed_boas_vindas, view=AcoesTicketView())
        await interaction.followup.send(f"Seu ticket de denúncia foi criado aqui: {novo_canal.mention}", ephemeral=True)

class DenunciaTipoView(ui.View):
    def __init__(self, original_interaction: discord.Interaction):
        super().__init__(timeout=180)
        self.add_item(DenunciaTipoSelect(original_interaction))

class TicketSelect(ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(label="Dúvidas/Suporte", value="duvidas/Suporte", description="Solicite ajuda de um responsavel pela facção", emoji="💭"),
            discord.SelectOption(label="Parcerias", value="parcerias", description="Para fechar parcerias", emoji="🤝"),
            discord.SelectOption(label="Denuncias", value="denuncias", description="Denunciar Player.", emoji="🚫"),
            discord.SelectOption(label="Encomendas", value="encomendas", description="Fazer uma encomenda.", emoji="📊")
        ]
        super().__init__(placeholder="Selecione o tipo de atendimento...", options=options, custom_id="ticket_select_main")

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)

        if self.values[0] == "denuncias":
            view = DenunciaTipoView(original_interaction=interaction)
            return await interaction.followup.send("Sua denúncia é contra que tipo de membro?", view=view, ephemeral=True)

        topic_procurado = f"ticket:{interaction.user.id}"
        canal_existente = discord.utils.get(interaction.guild.text_channels, topic=topic_procurado)

        if canal_existente:
            return await interaction.followup.send(
                "❌ Você já tem um ticket aberto. Feche o ticket atual antes de abrir um novo.",
                ephemeral=True
            )

        overwrites = {
            interaction.guild.default_role: discord.PermissionOverwrite(view_channel=False),
            interaction.user: discord.PermissionOverwrite(view_channel=True, send_messages=True, attach_files=True),
            interaction.guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, attach_files=True)
        }
        
        if CARGO_STAFF_ID != 0:
            cargo = interaction.guild.get_role(CARGO_STAFF_ID)
            if cargo:
                overwrites[cargo] = discord.PermissionOverwrite(view_channel=True, send_messages=True, attach_files=True)

        tipo = self.values[0]
        nome_canal_seguro = tipo.replace('/', '-')
        nome_canal = f"🎫-{nome_canal_seguro}-{interaction.user.id}"
        
        novo_canal = await interaction.guild.create_text_channel(
            name=nome_canal,
            overwrites=overwrites,
            category=interaction.channel.category,
            topic=f"ticket:{interaction.user.id}"
        )

        embed_boas_vindas = discord.Embed(
            title="👋 Atendimento Iniciado",
            description=f"Olá {interaction.user.mention}, você abriu um ticket para **{tipo.capitalize()}**.\n\n"
                        f"**Staff:** Use os botões abaixo para gerenciar este ticket.",
            color=discord.Color.green()
        )

        await novo_canal.send(content=f"{interaction.user.mention}", embed=embed_boas_vindas, view=AcoesTicketView())
        await interaction.followup.send(f"Seu ticket foi criado aqui: {novo_canal.mention}", ephemeral=True)

class TicketSetupView(ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(TicketSelect())

class TicketCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        bot.add_view(AcoesTicketView())
        bot.add_view(TicketSetupView())

    async def _reenviar_painel_tickets(self, channel_id: int):
        """Apaga o painel de tickets antigo e envia um novo."""
        try:
            channel = self.bot.get_channel(channel_id)
            if not channel: return

            # Limpa mensagens antigas do bot no canal para evitar painéis duplicados
            async for message in channel.history(limit=10):
                if message.author == self.bot.user and message.embeds and "CENTRAL DE ATENDIMENTOS" in message.embeds[0].title:
                    await message.delete()
            
            embed_painel = discord.Embed(title="🎟️ **CENTRAL DE ATENDIMENTOS**", description="Precisa de suporte ou tirar dúvidas? Selecione a opção abaixo para abrir um canal privado.", color=discord.Color.from_rgb(0, 255, 0)) # Cor verde
            embed_painel.set_footer(text="Aguarde o carregamento do canal após selecionar.")

            # --- Lógica de Imagem Aprimorada ---
            arquivo_imagem = None
            caminho_imagem_local = os.path.join(os.path.dirname(__file__), '..', 'assets', 'painel_ticket.png')

            if os.path.exists(caminho_imagem_local):
                print("[DIAGNÓSTICO TICKET] Usando imagem local 'assets/painel_ticket.png'.")
                arquivo_imagem = discord.File(caminho_imagem_local, filename="painel_ticket.png")
                embed_painel.set_image(url="attachment://painel_ticket.png")
            elif TICKET_PAINEL_IMAGE_URL:
                print(f"[DIAGNÓSTICO TICKET] Usando imagem da URL: {TICKET_PAINEL_IMAGE_URL}")
                embed_painel.set_image(url=TICKET_PAINEL_IMAGE_URL)

            await channel.send(embed=embed_painel, view=TicketSetupView(), file=arquivo_imagem)
        except Exception as e:
            print(f"AVISO: Não foi possível reenviar o painel de tickets. Erro: {e}")

    @commands.Cog.listener()
    async def on_ready(self):
        print("Cog de Tickets pronto.")

    @app_commands.command(name="setup_tickets", description="Posta o painel de tickets no canal.")
    @app_commands.default_permissions(administrator=True)
    async def setup_command(self, interaction: discord.Interaction):
        canal = self.bot.get_channel(CANAL_TICKETS_PAINEL_ID)
        if not canal:
            return await interaction.response.send_message("❌ `CANAL_TICKETS_PAINEL_ID` não foi configurado.", ephemeral=True)

        await interaction.response.defer(ephemeral=True)
        await self._reenviar_painel_tickets(canal.id)
        await interaction.followup.send(f"✅ Painel de tickets configurado com sucesso em {canal.mention}!", ephemeral=True)

async def setup(bot: commands.Bot):
    await bot.add_cog(TicketCog(bot))