import discord
from discord import ui, app_commands
from discord.ext import commands
import os
import io
import asyncio

# --- Configurações (Lidas do .env) ---
CANAL_TATICO_PAINEL_ID = int(os.getenv("CANAL_TATICO_PAINEL_ID", 0))
CATEGORIA_TICKETS_TATICOS_ID = int(os.getenv("CATEGORIA_TICKETS_TATICOS_ID", 0))
CARGO_LIDER_TATICO_ID = int(os.getenv("CARGO_LIDER_TATICO_ID", 0))
TATICO_PAINEL_IMAGE_URL = os.getenv("TATICO_PAINEL_IMAGE_URL")
CANAL_LOG_TATICOS_ID = int(os.getenv("CANAL_LOG_TATICOS_ID", 0))

# --- Modals ---

class ReprovarTaticoModal(ui.Modal, title="Reprovar Teste Tático"):
    motivo = ui.TextInput(
        label="Motivo da Reprovação",
        style=discord.TextStyle.paragraph,
        placeholder="Ex: Não demonstrou bom posicionamento, comunicação falha, etc.",
        required=True
    )

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer()
        # A lógica de edição do embed e notificação está no botão que chamou este modal.

# --- Views (Botões) ---

class FecharTaticoView(ui.View):
    """View com o botão para fechar o ticket de teste."""
    def __init__(self):
        super().__init__(timeout=None)

    @ui.button(label="Fechar Ticket", style=discord.ButtonStyle.danger, emoji="🔒", custom_id="tatico_fechar")
    async def fechar_ticket(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.send_message("✅ Gerando log e fechando o ticket em 5 segundos...", ephemeral=True)

        # --- Geração de Transcript ---
        log_channel = interaction.guild.get_channel(CANAL_LOG_TATICOS_ID)
        if not log_channel:
            print(f"AVISO: Canal de log de táticos (ID: {CANAL_LOG_TATICOS_ID}) não encontrado.")

        # Extrai o ID do criador do topic do canal
        criador_id = None
        if interaction.channel.topic and "criador:" in interaction.channel.topic:
            try:
                criador_id = int(interaction.channel.topic.split("criador:")[1])
            except (ValueError, IndexError):
                pass

        historico_mensagens = []
        async for message in interaction.channel.history(limit=None, oldest_first=True):
            time = message.created_at.strftime('%d/%m/%Y %H:%M')
            historico_mensagens.append(f"[{time}] {message.author.display_name}: {message.content}")
        
        conteudo_log = "\n".join(historico_mensagens)
        nome_arquivo = f"log-tatico-{interaction.channel.name}.txt"
        
        buffer = io.BytesIO(conteudo_log.encode('utf-8'))
        arquivo_log = discord.File(buffer, filename=nome_arquivo)

        # Envia DM para o criador do ticket
        if criador_id:
            try:
                membro = await interaction.guild.fetch_member(criador_id)
                embed_pv = discord.Embed(
                    title="📄 Histórico do seu Teste Tático",
                    description=f"Seu teste em **{interaction.guild.name}** foi finalizado. Abaixo está o arquivo com todas as mensagens.",
                    color=discord.Color.blue()
                )
                await membro.send(embed=embed_pv, file=arquivo_log)
            except (discord.NotFound, discord.Forbidden):
                print(f"Não foi possível enviar DM com o log para o usuário ID {criador_id}.")
        
        # Envia o log para o canal de logs
        if log_channel:
            buffer.seek(0) # Reseta o buffer para ser lido novamente
            
            # Extrai o resultado do embed para adicionar ao log
            resultado_final = "Não definido"
            if interaction.message.embeds:
                if "Aprovado" in interaction.message.embeds[0].title: resultado_final = "Aprovado"
                elif "Reprovado" in interaction.message.embeds[0].title: resultado_final = "Reprovado"
            await log_channel.send(f"✅ Ticket de teste tático `{interaction.channel.name}` fechado por {interaction.user.mention}. **Resultado: {resultado_final}**", file=discord.File(buffer, filename=nome_arquivo))

        await asyncio.sleep(5)
        await interaction.channel.delete(reason=f"Ticket de teste tático fechado por {interaction.user.name}")

class AprovacaoTaticoView(ui.View):
    """View com botões de Aprovar/Reprovar para o líder tático."""
    def __init__(self):
        super().__init__(timeout=None)

    async def _verificar_permissao(self, interaction: discord.Interaction) -> bool:
        """Verifica se o usuário tem o cargo de Líder Tático."""
        lider_tatico_role = interaction.guild.get_role(CARGO_LIDER_TATICO_ID)
        if not lider_tatico_role or lider_tatico_role not in interaction.user.roles:
            await interaction.response.send_message("❌ Apenas Líderes Táticos podem usar este botão.", ephemeral=True)
            return False
        return True

    async def interacao_lider(self, interaction: discord.Interaction, resultado: str, motivo: str = None):
        original_embed = interaction.message.embeds[0]
        criador_id = int(original_embed.footer.text.split(': ')[1])
        membro = await interaction.guild.fetch_member(criador_id)

        novo_embed = original_embed.copy()
        novo_embed.title = f"🎯 Teste Tático - {resultado}"
        novo_embed.color = discord.Color.green() if resultado == "Aprovado" else discord.Color.red()
        novo_embed.add_field(name="Resultado", value=f"**{resultado}** por {interaction.user.mention}", inline=False)
        if motivo:
            novo_embed.add_field(name="Motivo", value=motivo, inline=False)

        await interaction.message.edit(embed=novo_embed, view=FecharTaticoView())

        # Notifica o usuário
        try:
            dm_msg = f"Seu teste tático foi **{resultado.lower()}**!"
            if motivo:
                dm_msg += f"\n**Motivo:** {motivo}"
            await membro.send(dm_msg)
        except (discord.NotFound, discord.Forbidden):
            await interaction.channel.send(f"⚠️ Não foi possível notificar {membro.mention} no privado.", delete_after=10)

    @ui.button(label="Aprovar", style=discord.ButtonStyle.success, emoji="✅", custom_id="tatico_aprovar")
    async def aprovar(self, interaction: discord.Interaction, button: ui.Button):
        if not await self._verificar_permissao(interaction):
            return
        
        await interaction.response.defer()
        await self.interacao_lider(interaction, "Aprovado")

    @ui.button(label="Reprovar", style=discord.ButtonStyle.danger, emoji="❌", custom_id="tatico_reprovar")
    async def reprovar(self, interaction: discord.Interaction, button: ui.Button):
        if not await self._verificar_permissao(interaction):
            return

        modal = ReprovarTaticoModal()
        await interaction.response.send_modal(modal)
        await modal.wait() # Espera o modal ser enviado

        if modal.motivo.value:
            await self.interacao_lider(interaction, "Reprovado", motivo=modal.motivo.value)

class PainelTaticoView(ui.View):
    """View persistente com o botão para solicitar o teste."""
    def __init__(self):
        super().__init__(timeout=None)

    @ui.button(label="Solicitar Teste Tático", style=discord.ButtonStyle.primary, custom_id="tatico_solicitar", emoji="🎯")
    async def solicitar_teste(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.defer(ephemeral=True, thinking=True)

        categoria = interaction.guild.get_channel(CATEGORIA_TICKETS_TATICOS_ID)
        lider_tatico_role = interaction.guild.get_role(CARGO_LIDER_TATICO_ID)

        if not categoria or not isinstance(categoria, discord.CategoryChannel):
            return await interaction.followup.send("❌ A categoria para tickets táticos não foi configurada corretamente. Avise um administrador.", ephemeral=True)
        if not lider_tatico_role:
            return await interaction.followup.send("❌ O cargo de Líder Tático não foi configurado. Avise um administrador.", ephemeral=True)

        # Verifica se o usuário já tem um ticket aberto
        for channel in categoria.text_channels:
            if channel.topic and f"criador:{interaction.user.id}" in channel.topic:
                return await interaction.followup.send(f"❌ Você já possui um ticket de teste aberto em {channel.mention}.", ephemeral=True)

        # Permissões do novo canal
        overwrites = {
            interaction.guild.default_role: discord.PermissionOverwrite(view_channel=False),
            interaction.user: discord.PermissionOverwrite(view_channel=True, send_messages=True, attach_files=True),
            interaction.guild.me: discord.PermissionOverwrite(view_channel=True),
            lider_tatico_role: discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_messages=True)
        }

        # Cria o canal
        nome_canal = f"🎯-teste-{interaction.user.name}"
        try:
            novo_canal = await categoria.create_text_channel(
                name=nome_canal,
                overwrites=overwrites,
                topic=f"Ticket de teste tático para {interaction.user.name}. criador:{interaction.user.id}"
            )
        except discord.Forbidden:
            return await interaction.followup.send("❌ Não tenho permissão para criar canais nesta categoria. Avise um administrador.", ephemeral=True)

        # Mensagem de boas-vindas no ticket
        embed_boas_vindas = discord.Embed(
            title="🎯 Solicitação de Teste Tático",
            description=f"Olá {interaction.user.mention}, seu canal para o teste tático foi criado.\n\n"
                        f"Aguarde que o {lider_tatico_role.mention} irá entrar em contato para agendar seu teste.",
            color=discord.Color.blue()
        )
        embed_boas_vindas.set_footer(text=f"ID do Solicitante: {interaction.user.id}")
        await novo_canal.send(content=f"{interaction.user.mention} {lider_tatico_role.mention}", embed=embed_boas_vindas, view=AprovacaoTaticoView())
        await interaction.followup.send(f"✅ Seu ticket para o teste tático foi criado: {novo_canal.mention}", ephemeral=True)

# --- Cog Principal ---

class TaticoCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        # Registra as views para que os botões funcionem após o bot reiniciar
        self.bot.add_view(PainelTaticoView())
        self.bot.add_view(AprovacaoTaticoView())
        self.bot.add_view(FecharTaticoView())

    @commands.Cog.listener()
    async def on_ready(self):
        print("Cog de Teste Tático pronto.")

    @app_commands.command(name="setup_painel_tatico", description="Cria o painel para solicitar teste tático.")
    @app_commands.default_permissions(administrator=True)
    async def setup_painel_tatico(self, interaction: discord.Interaction):
        canal = self.bot.get_channel(CANAL_TATICO_PAINEL_ID)
        if not canal:
            return await interaction.response.send_message("❌ `CANAL_TATICO_PAINEL_ID` não foi configurado no .env.", ephemeral=True)

        await interaction.response.defer(ephemeral=True)

        embed = discord.Embed(
            title="Central de Testes Táticos",
            description="Clique no botão abaixo para abrir um ticket e solicitar seu teste para a equipe tática.",
            color=0x00008B # Azul Escuro
        )

        # --- Lógica de Imagem Aprimorada ---
        arquivo_imagem = None
        caminho_imagem_local = os.path.join(os.path.dirname(__file__), '..', 'assets', 'painel_tatico.png')

        if os.path.exists(caminho_imagem_local):
            print("[DIAGNÓSTICO TATICO] Usando imagem local 'assets/painel_tatico.png'.")
            arquivo_imagem = discord.File(caminho_imagem_local, filename="painel_tatico.png")
            embed.set_image(url="attachment://painel_tatico.png")
        elif TATICO_PAINEL_IMAGE_URL:
            print(f"[DIAGNÓSTICO TATICO] Usando imagem da URL: {TATICO_PAINEL_IMAGE_URL}")
            embed.set_image(url=TATICO_PAINEL_IMAGE_URL)

        try:
            await canal.send(embed=embed, view=PainelTaticoView(), file=arquivo_imagem)
            await interaction.followup.send(f"✅ Painel de teste tático configurado com sucesso em {canal.mention}!", ephemeral=True)
        except discord.Forbidden:
            await interaction.followup.send("❌ Não tenho permissão para enviar mensagens ou arquivos neste canal.", ephemeral=True)

async def setup(bot: commands.Bot):
    await bot.add_cog(TaticoCog(bot))