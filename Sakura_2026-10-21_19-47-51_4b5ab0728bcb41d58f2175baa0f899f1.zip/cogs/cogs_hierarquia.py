import discord
from discord.ext import commands, tasks
from discord import app_commands
import asyncio
from datetime import datetime
import json
import os
import re
import pytz

# --- Configurações ---
ID_DO_CANAL_HIERARQUIA = int(os.getenv("ID_DO_CANAL_HIERARQUIA", 0))
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_FILE = os.path.join(BASE_DIR, "config_hierarquia.json")
if not os.path.exists(CONFIG_FILE):
    CONFIG_FILE = "config_hierarquia.json"

# Suporta colchetes ocidentais [...] e japoneses 【...】
TAG_REGEX = re.compile(r"^(?:[\[【][^\]】]*[\]】]\s*)+")

# --- Funções de Gerenciamento da Configuração ---
def carregar_config():
    if not os.path.exists(CONFIG_FILE):
        return []
    try:
        with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, FileNotFoundError):
        return []

def salvar_config(config):
    with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=4)

# --- Funções Utilitárias de Tags e Apelidos ---
def formatar_tag(tag: str) -> str:
    """Padroniza a tag informada (ex: se o usuário digitar 'T', transforma em '[T]')."""
    if not tag:
        return ""
    tag = tag.strip()
    if not tag:
        return ""
    if (tag.startswith("[") and tag.endswith("]")) or (tag.startswith("【") and tag.endswith("】")):
        return tag
    return f"[{tag}]"

def extrair_nome_base(display_name: str, username: str) -> str:
    """Remove qualquer tag existente entre colchetes do início do nome."""
    limpo = TAG_REGEX.sub("", display_name).strip()
    return limpo if limpo else username

def obter_tag_mais_alta(membro: discord.Member, config: list) -> str | None:
    """
    Percorre a hierarquia do topo até a base.
    Retorna a tag do primeiro cargo (mais alto) que o membro possuir e que tiver tag preenchida.
    """
    ids_do_membro = {r.id for r in membro.roles}
    for c in config:
        if c.get("id") in ids_do_membro:
            tag = c.get("tag")
            if tag and tag.strip():
                return tag.strip()
    return None

def pode_alterar_apelido(membro: discord.Member) -> tuple[bool, str]:
    """
    Verifica se o bot tem autorização hierárquica e permissão para alterar o apelido do membro.
    Retorna (pode: bool, motivo: str).
    """
    if membro.bot:
        return False, "É um bot"
    guild = membro.guild
    if not guild.me.guild_permissions.manage_nicknames:
        return False, "Bot sem a permissão 'Gerenciar Apelidos' (Manage Nicknames)"
    if membro.id == guild.owner_id:
        return False, "É o Dono do Servidor (o Discord proíbe bots de renomearem o Dono)"
    if membro.top_role >= guild.me.top_role:
        return False, f"Cargo do membro ({membro.top_role.name} - Pos {membro.top_role.position}) é igual ou superior ao cargo mais alto do bot ({guild.me.top_role.name} - Pos {guild.me.top_role.position})"
    return True, "OK"

async def aplicar_tag_membro(membro: discord.Member, config: list = None, log_motivo: bool = True) -> tuple[bool, str]:
    """
    Calcula e aplica a tag correspondente ao cargo mais alto da hierarquia.
    Retorna (alterou: bool, status: str).
    """
    pode, motivo = pode_alterar_apelido(membro)
    if not pode:
        if log_motivo:
            print(f"[TAGS] Ignorado {membro.display_name} ({membro.id}): {motivo}")
        return False, motivo

    if config is None:
        config = carregar_config()

    tag = obter_tag_mais_alta(membro, config)
    nome_atual = membro.display_name
    nome_base = extrair_nome_base(nome_atual, membro.name)

    if tag:
        novo_nick = f"{tag} {nome_base}"
        if len(novo_nick) > 32:
            espaco_base = 32 - len(tag) - 1
            if espaco_base > 0:
                novo_nick = f"{tag} {nome_base[:espaco_base].rstrip()}"
            else:
                novo_nick = novo_nick[:32]
    else:
        novo_nick = nome_base[:32]

    # Se já estiver com o nome correto, evita requisição à API
    nick_atual_comparacao = membro.nick if membro.nick is not None else membro.name
    if nick_atual_comparacao == novo_nick or membro.display_name == novo_nick:
        return False, "Já está com o apelido correto"

    try:
        await membro.edit(nick=novo_nick, reason="Sincronização de Tag de Hierarquia")
        print(f"[TAGS] ✅ Apelido atualizado: '{membro.display_name}' -> '{novo_nick}'")
        return True, f"Atualizado para {novo_nick}"
    except discord.Forbidden:
        msg = f"Erro 403 Forbidden ao editar {membro.display_name} (verifique se o cargo do bot está acima)"
        print(f"[TAGS] ❌ {msg}")
        return False, msg
    except discord.HTTPException as e:
        msg = f"Erro HTTP ao editar {membro.display_name}: {e}"
        print(f"[TAGS] ❌ {msg}")
        return False, msg

# --- Classes da Interface ---
class AdicionarCargoModal(discord.ui.Modal, title="Adicionar Cargo à Hierarquia"):
    posicao = discord.ui.TextInput(
        label="Posição na Hierarquia",
        placeholder="Ex: 1 (topo), 2, 3...",
        style=discord.TextStyle.short,
        required=True
    )
    tag = discord.ui.TextInput(
        label="Tag de Identificação (Opcional)",
        placeholder="Ex: [T] ou [L.T] (deixe vazio se não tiver)",
        style=discord.TextStyle.short,
        required=False,
        max_length=15
    )
    
    def __init__(self, role: discord.Role, parent_view: "PainelConfigHierarquiaView"):
        super().__init__()
        self.role = role
        self.parent_view = parent_view
        
    async def on_submit(self, interaction: discord.Interaction):
        try:
            pos = int(self.posicao.value)
            if pos < 1:
                await interaction.response.send_message("A posição deve ser um número maior que 0.", ephemeral=True)
                return
        except ValueError:
            await interaction.response.send_message("A posição deve ser um número válido.", ephemeral=True)
            return

        config = carregar_config()

        if any(c['id'] == self.role.id for c in config):
            await interaction.response.send_message(f"O cargo {self.role.mention} já está na hierarquia.", ephemeral=True)
            return

        tag_formatada = formatar_tag(self.tag.value)
        novo_cargo = {
            "id": self.role.id,
            "titulo": self.role.name,
            "cor": self.role.color.value,
            "tag": tag_formatada
        }
        config.insert(pos - 1, novo_cargo)

        salvar_config(config)
        info_tag = f" com a tag `{tag_formatada}`" if tag_formatada else " *(sem tag)*"
        await interaction.response.send_message(f"✅ Cargo {self.role.mention} adicionado na posição {pos}{info_tag}.", ephemeral=True)
        await self.parent_view.atualizar_embed()

class EditarTagModal(discord.ui.Modal):
    def __init__(self, role_id: int, role_name: str, tag_atual: str, parent_view: "PainelConfigHierarquiaView"):
        super().__init__(title=f"Tag: {role_name[:20]}")
        self.role_id = role_id
        self.parent_view = parent_view

        self.tag_input = discord.ui.TextInput(
            label="Tag de Identificação",
            placeholder="Ex: [T] (deixe em branco para remover)",
            default=tag_atual,
            required=False,
            max_length=15
        )
        self.add_item(self.tag_input)

    async def on_submit(self, interaction: discord.Interaction):
        config = carregar_config()
        nova_tag = formatar_tag(self.tag_input.value)

        atualizado = False
        for c in config:
            if c['id'] == self.role_id:
                c['tag'] = nova_tag
                atualizado = True
                break

        if atualizado:
            salvar_config(config)
            role = interaction.guild.get_role(self.role_id)
            role_str = role.mention if role else f"ID {self.role_id}"
            txt_tag = f"`{nova_tag}`" if nova_tag else "*(Nenhuma)*"
            await interaction.response.send_message(f"✅ Tag do cargo {role_str} atualizada para {txt_tag}.", ephemeral=True)
            await self.parent_view.atualizar_embed()
        else:
            await interaction.response.send_message("❌ Cargo não encontrado na configuração.", ephemeral=True)

class PainelConfigHierarquiaView(discord.ui.View):
    def __init__(self, cog: "HierarquiaCog", *, timeout=300):
        super().__init__(timeout=timeout)
        self.cog = cog
        self.bot = cog.bot
        self.message: discord.Message = None

    async def atualizar_embed(self):
        embed = self.criar_embed_config(self.message.guild)
        await self.message.edit(embed=embed, view=self)

    def criar_embed_config(self, guild: discord.Guild):
        config = carregar_config()
        embed = discord.Embed(
            title="⚙️ Painel de Configuração da Hierarquia",
            description="Use os botões abaixo para gerenciar os cargos, suas posições e tags de identificação.",
            color=discord.Color.blue()
        )
        if not config:
            embed.add_field(name="Hierarquia Atual", value="*Nenhum cargo configurado ainda.*", inline=False)
        else:
            linhas = []
            for i, cargo_info in enumerate(config):
                role = guild.get_role(cargo_info['id'])
                role_str = role.mention if role else f"Cargo não encontrado (ID: {cargo_info['id']})"
                tag = cargo_info.get("tag")
                tag_str = f" • Tag: `{tag}`" if tag else " • *(Sem Tag)*"
                linhas.append(f"**{i+1}.** {role_str}{tag_str}")

            texto = "\n".join(linhas)
            if len(texto) <= 1024:
                embed.add_field(name="Ordem da Hierarquia e Tags", value=texto, inline=False)
            else:
                meio = len(linhas) // 2
                embed.add_field(name="Ordem da Hierarquia (Parte 1)", value="\n".join(linhas[:meio]), inline=False)
                embed.add_field(name="Ordem da Hierarquia (Parte 2)", value="\n".join(linhas[meio:]), inline=False)

        embed.set_footer(text="As mudanças são salvas automaticamente.")
        return embed

    @discord.ui.button(label="Adicionar Cargo", style=discord.ButtonStyle.success, emoji="➕", row=0)
    async def adicionar(self, interaction: discord.Interaction, button: discord.ui.Button):
        select_view = discord.ui.View(timeout=180)
        role_select = discord.ui.RoleSelect(placeholder="Selecione o cargo para adicionar...")

        async def select_callback(select_interaction: discord.Interaction):
            selected_role_id = int(select_interaction.data['values'][0])
            role_obj = select_interaction.guild.get_role(selected_role_id)
            if not role_obj:
                await select_interaction.response.send_message("Erro: O cargo selecionado não foi encontrado.", ephemeral=True)
                return
            modal = AdicionarCargoModal(role=role_obj, parent_view=self)
            await select_interaction.response.send_modal(modal)

        role_select.callback = select_callback
        select_view.add_item(role_select)
        await interaction.response.send_message("Qual cargo você deseja adicionar à hierarquia?", view=select_view, ephemeral=True)

    @discord.ui.button(label="Remover Cargo", style=discord.ButtonStyle.danger, emoji="🗑️", row=0)
    async def remover(self, interaction: discord.Interaction, button: discord.ui.Button):
        config = carregar_config()
        if not config:
            await interaction.response.send_message("A hierarquia está vazia. Não há cargos para remover.", ephemeral=True)
            return

        options = []
        for i, c in enumerate(config[:25]):
            role = interaction.guild.get_role(c['id'])
            nome = role.name if role else f"ID: {c['id']}"
            options.append(
                discord.SelectOption(
                    label=f"{(i+1):02d}. {nome}"[:100],
                    value=str(c['id'])
                )
            )
        select = discord.ui.Select(placeholder="Selecione o cargo para remover...", options=options, max_values=len(options))

        async def remover_callback(select_interaction: discord.Interaction):
            ids_para_remover = {int(v) for v in select_interaction.data['values']}
            nova_config = [c for c in carregar_config() if c['id'] not in ids_para_remover]
            salvar_config(nova_config)
            await select_interaction.response.send_message(f"✅ {len(ids_para_remover)} cargo(s) removido(s) com sucesso.", ephemeral=True)
            await self.atualizar_embed()

        select.callback = remover_callback
        view_remover = discord.ui.View(timeout=180)
        view_remover.add_item(select)
        await interaction.response.send_message("Selecione os cargos que deseja remover da hierarquia:", view=view_remover, ephemeral=True)

    @discord.ui.button(label="Definir/Editar Tag", style=discord.ButtonStyle.secondary, emoji="🏷️", row=0)
    async def editar_tag(self, interaction: discord.Interaction, button: discord.ui.Button):
        config = carregar_config()
        if not config:
            await interaction.response.send_message("A hierarquia está vazia. Adicione cargos primeiro.", ephemeral=True)
            return

        options = []
        for i, c in enumerate(config[:25]):
            role = interaction.guild.get_role(c['id'])
            nome_cargo = role.name if role else f"ID: {c['id']}"
            tag_atual = c.get('tag', '')
            options.append(discord.SelectOption(
                label=f"{(i+1):02d}. {nome_cargo}"[:100],
                description=f"Tag atual: {tag_atual or 'Nenhuma'}"[:100],
                value=str(c['id'])
            ))

        select = discord.ui.Select(placeholder="Selecione o cargo para editar a tag...", options=options)

        async def editar_callback(select_interaction: discord.Interaction):
            role_id = int(select_interaction.data['values'][0])
            cargo_info = next((c for c in config if c['id'] == role_id), None)
            if not cargo_info:
                await select_interaction.response.send_message("Cargo não encontrado na configuração.", ephemeral=True)
                return

            role = select_interaction.guild.get_role(role_id)
            role_name = role.name if role else f"ID {role_id}"
            tag_atual = cargo_info.get("tag", "")

            modal = EditarTagModal(role_id=role_id, role_name=role_name, tag_atual=tag_atual, parent_view=self)
            await select_interaction.response.send_modal(modal)

        select.callback = editar_callback
        view_editar = discord.ui.View(timeout=180)
        view_editar.add_item(select)
        await interaction.response.send_message("Selecione o cargo que deseja definir ou alterar a tag:", view=view_editar, ephemeral=True)

    @discord.ui.button(label="Sincronizar Tags", style=discord.ButtonStyle.primary, emoji="🔄", row=1)
    async def sincronizar_tags_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True, thinking=True)
        resultado = await self.cog.executar_sincronizacao(interaction.guild)
        await interaction.followup.send(resultado, ephemeral=True)

    @discord.ui.button(label="Finalizar e Atualizar Painel", style=discord.ButtonStyle.success, emoji="🚀", row=1)
    async def finalizar_e_atualizar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True, thinking=True)
        await self.cog.atualizar_painel_hierarquia()
        await interaction.followup.send("✅ O painel de hierarquia principal foi atualizado com sucesso!", ephemeral=True)


class HierarquiaCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.loop_hierarquia.start()

    def cog_unload(self):
        self.loop_hierarquia.cancel()

    async def atualizar_painel_hierarquia(self):
        try:
            channel = await self.bot.fetch_channel(ID_DO_CANAL_HIERARQUIA)
        except Exception as e:
            print(f"ERRO CRÍTICO: Não foi possível acessar o canal ID {ID_DO_CANAL_HIERARQUIA}. Detalhe: {e}")
            return

        try:
            await channel.purge(limit=30)
        except discord.Forbidden:
            print(f"ERRO: O bot não tem permissão para 'Gerenciar Mensagens' no canal {channel.name}.")

        cargos_config = carregar_config()
        fuso_horario_py = pytz.timezone('America/Asuncion')
        data_hoje = datetime.now(fuso_horario_py).strftime("%d/%m/%Y às %H:%M")
        membros_ja_exibidos = set()
        guild = channel.guild

        for config in cargos_config:
            role = guild.get_role(config["id"])
            if not role:
                continue

            membros_para_exibir = [m for m in role.members if not m.bot and m.id not in membros_ja_exibidos]
            membros_ja_exibidos.update(m.id for m in membros_para_exibir)

            lista_membros = "\n".join(f"• {m.mention}" for m in membros_para_exibir) or "• *Nenhum membro neste cargo.*"

            cor = role.color if role.color.value != 0 else 0x99aab5
            embed = discord.Embed(description=f"## {role.name}\n\n{lista_membros}", color=cor)

            LINK_DO_GIF = "https://files.catbox.moe/71gbst.gif"
            embed.set_footer(text=f"Total: {len(membros_para_exibir)} membros   |   Atualizado automaticamente dia: {data_hoje}", icon_url=LINK_DO_GIF)

            if role.icon:
                embed.set_thumbnail(url=role.icon.url)

            await channel.send(embed=embed)
            await asyncio.sleep(1)

        print(f"Hierarquia atualizada com sucesso em {data_hoje}")

    async def executar_sincronizacao(self, guild: discord.Guild) -> str:
        """Sincroniza as tags de todos os membros do servidor com base na hierarquia."""
        config = carregar_config()
        if not config:
            return "❌ Nenhum cargo configurado na hierarquia."

        if len(guild.members) < guild.member_count:
            try:
                await guild.chunk()
            except Exception:
                pass

        alterados = 0
        inalterados = 0
        bloqueados_cargo = []
        dono_ignorado = 0

        for membro in guild.members:
            if membro.bot:
                continue

            pode, motivo = pode_alterar_apelido(membro)
            if not pode:
                if membro.id == guild.owner_id:
                    dono_ignorado += 1
                elif "superior ao cargo" in motivo:
                    bloqueados_cargo.append(f"• **{membro.display_name}** ({membro.top_role.name})")
                continue

            alterou, _ = await aplicar_tag_membro(membro, config, log_motivo=False)
            if alterou:
                alterados += 1
                await asyncio.sleep(1)  # Intervalo seguro contra rate-limit
            else:
                inalterados += 1

        resposta = [
            "📋 **Resultado da Sincronização de Tags:**\n",
            f"• 🏷️ **Apelidos Atualizados:** `{alterados}`",
            f"• ⚡ **Já estavam com a tag correta:** `{inalterados}`",
        ]

        if dono_ignorado > 0:
            resposta.append("• 👑 **Dono do Servidor:** Ignorado (limitação oficial de segurança do Discord).")

        if bloqueados_cargo:
            cargo_bot_str = f"{guild.me.top_role.name} (Posição {guild.me.top_role.position})"
            resposta.append(
                f"\n⚠️ **Ignorados por Hierarquia do Discord ({len(bloqueados_cargo)} membros):**\n"
                f"*O cargo mais alto do bot é `{cargo_bot_str}`. No Discord, suba o cargo do bot para o topo da lista de cargos para permitir renomear:*\n"
                + "\n".join(bloqueados_cargo[:8])
            )
            if len(bloqueados_cargo) > 8:
                resposta.append(f"*... e mais {len(bloqueados_cargo) - 8} membro(s).*")

        return "\n".join(resposta)

    @tasks.loop(minutes=60)
    async def loop_hierarquia(self):
        await self.atualizar_painel_hierarquia()

    @loop_hierarquia.before_loop
    async def before_loop_hierarquia(self):
        await self.bot.wait_until_ready()

    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member):
        """Atualiza a tag do membro automaticamente quando os cargos ou o nick mudam."""
        if after.bot:
            return
        if before.roles != after.roles or before.nick != after.nick:
            await aplicar_tag_membro(after, log_motivo=True)

    # --- Comandos Slash (/) ---
    @app_commands.command(name="atualizar", description="Força a atualização do painel de hierarquia.")
    @app_commands.default_permissions(administrator=True)
    async def atualizar(self, interaction: discord.Interaction):
        await interaction.response.send_message("**Iniciando atualização da Hierarquia...**", ephemeral=True)
        await self.atualizar_painel_hierarquia()
        await interaction.followup.send("**Hierarquia Atualizada com sucesso!**", ephemeral=True)

    @app_commands.command(name="sincronizar_tags", description="Sincroniza as tags dos membros com base no cargo mais alto da hierarquia.")
    @app_commands.default_permissions(administrator=True)
    async def sincronizar_tags(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)
        resultado = await self.executar_sincronizacao(interaction.guild)
        await interaction.followup.send(resultado, ephemeral=True)

    @app_commands.command(name="painel_config", description="Exibe o painel para configurar a hierarquia de cargos e tags.")
    @app_commands.default_permissions(administrator=True)
    async def painel_config(self, interaction: discord.Interaction):
        view = PainelConfigHierarquiaView(cog=self)
        embed = view.criar_embed_config(interaction.guild)
        await interaction.response.send_message(embed=embed, view=view)
        message = await interaction.original_response()
        view.message = message

    # --- Comandos de Prefixo (!) ---
    @commands.command(name="sincronizar_tags", aliases=["synctags", "sync_tags", "atualizartags"])
    @commands.has_permissions(administrator=True)
    async def cmd_sincronizar_tags(self, ctx: commands.Context):
        """Executa sincronização manual via prefixo !sincronizar_tags."""
        msg = await ctx.send("⏳ Iniciando sincronização de tags de todos os membros...")
        resultado = await self.executar_sincronizacao(ctx.guild)
        await msg.edit(content=resultado)

    @commands.command(name="atualizar_painel", aliases=["atualizar"])
    @commands.has_permissions(administrator=True)
    async def cmd_atualizar_painel(self, ctx: commands.Context):
        """Executa atualização manual do painel via prefixo !atualizar."""
        msg = await ctx.send("⏳ Atualizando painel da hierarquia...")
        await self.atualizar_painel_hierarquia()
        await msg.edit(content="✅ Painel de hierarquia atualizado com sucesso!")

    @commands.command(name="testartag", aliases=["checktag"])
    @commands.has_permissions(administrator=True)
    async def cmd_testar_tag(self, ctx: commands.Context, membro: discord.Member = None):
        """Testa e exibe diagnóstico do motivo de renomeação de um membro (!testartag @usuario)."""
        membro = membro or ctx.author
        config = carregar_config()
        pode, motivo = pode_alterar_apelido(membro)
        tag = obter_tag_mais_alta(membro, config)
        base = extrair_nome_base(membro.display_name, membro.name)
        esperado = f"{tag} {base}" if tag else base

        embed = discord.Embed(title=f"🔍 Diagnóstico: {membro.display_name}", color=discord.Color.blue())
        embed.add_field(name="Cargo Mais Alto do Membro", value=f"{membro.top_role.name} (Pos {membro.top_role.position})", inline=True)
        embed.add_field(name="Cargo Mais Alto do Bot", value=f"{ctx.guild.me.top_role.name} (Pos {ctx.guild.me.top_role.position})", inline=True)
        embed.add_field(name="O Bot Pode Alterar?", value=f"{'✅ Sim' if pode else f'❌ Não ({motivo})'}", inline=False)
        embed.add_field(name="Tag Calculada", value=f"`{tag}`" if tag else "*Nenhuma*", inline=True)
        embed.add_field(name="Apelido Final Calculado", value=f"`{esperado}`", inline=True)
        embed.add_field(name="Apelido Atual", value=f"`{membro.display_name}`", inline=True)
        await ctx.send(embed=embed)

async def setup(bot: commands.Bot):
    if bot.get_cog("HierarquiaCog"):
        await bot.remove_cog("HierarquiaCog")
    await bot.add_cog(HierarquiaCog(bot))