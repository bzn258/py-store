import discord
from discord.ext import commands
from discord import app_commands, ui
import os
import re
from datetime import datetime

# --- Configurações ---
CANAL_ACOES_ID = int(os.getenv("CANAL_ACOES_ID", 0))
CANAL_LOG_ACOES_ID = int(os.getenv("CANAL_LOG_ACOES_ID", 0))

# --- Funções Auxiliares ---
def parse_embed_footer(footer_text: str):
    """Extrai dados do rodapé do embed."""
    creator_id = int(re.search(r"Criador: (\d+)", footer_text).group(1))
    max_players = int(re.search(r"Vagas: (\d+)", footer_text).group(1))
    return creator_id, max_players

def get_players_from_field(field_value: str):
    """Extrai IDs de jogadores de um campo do embed."""
    if "Nenhum" in field_value:
        return []
    return [int(p_id) for p_id in re.findall(r"<@(\d+)>", field_value)]

# --- Views e Modals ---

class ResultadoView(ui.View):
    """View para o criador da ação escolher o resultado."""
    def __init__(self, interaction_original: discord.Interaction):
        super().__init__(timeout=180)
        self.interaction_original = interaction_original
        self.resultado = None

    @ui.button(label="Vitória", style=discord.ButtonStyle.success, emoji="🏆")
    async def vitoria(self, interaction: discord.Interaction, button: ui.Button):
        self.resultado = "Vitória"
        await interaction.response.defer()
        self.stop()

    @ui.button(label="Derrota", style=discord.ButtonStyle.danger, emoji="💔")
    async def derrota(self, interaction: discord.Interaction, button: ui.Button):
        self.resultado = "Derrota"
        await interaction.response.defer()
        self.stop()

class AcaoView(ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    async def atualizar_embed(self, interaction: discord.Interaction, players: list, suplentes: list):
        embed = interaction.message.embeds[0]
        
        players_str = "\n".join(f"• <@{p_id}>" for p_id in players) if players else "• *Nenhum participante*"
        suplentes_str = "\n".join(f"• <@{p_id}>" for p_id in suplentes) if suplentes else "• *Nenhum suplente*"

        embed.set_field_at(4, name="👥 Participantes", value=players_str, inline=False)
        embed.set_field_at(5, name="🔄 Suplentes", value=suplentes_str, inline=False)

        await interaction.message.edit(embed=embed)

    @ui.button(label="Entrar", style=discord.ButtonStyle.success, custom_id="acao_entrar")
    async def entrar(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.defer(ephemeral=True)
        
        embed = interaction.message.embeds[0]
        creator_id, max_players = parse_embed_footer(embed.footer.text)
        
        players = get_players_from_field(embed.fields[4].value)
        suplentes = get_players_from_field(embed.fields[5].value)

        user_id = interaction.user.id
        if user_id in players or user_id in suplentes:
            return await interaction.followup.send("❌ Você já está na lista.", ephemeral=True)

        if len(players) < max_players:
            players.append(user_id)
            await interaction.followup.send("✅ Você entrou na lista de participantes!", ephemeral=True)
        else: # Vagas de suplentes são ilimitadas
            suplentes.append(user_id)
            await interaction.followup.send("✅ A lista principal está cheia. Você entrou como suplente.", ephemeral=True)

        await self.atualizar_embed(interaction, players, suplentes)

    @ui.button(label="Sair", style=discord.ButtonStyle.danger, custom_id="acao_sair")
    async def sair(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.defer(ephemeral=True)

        embed = interaction.message.embeds[0]
        creator_id, max_players = parse_embed_footer(embed.footer.text)

        players = get_players_from_field(embed.fields[4].value)
        suplentes = get_players_from_field(embed.fields[5].value)
        
        user_id = interaction.user.id
        if user_id not in players and user_id not in suplentes:
            return await interaction.followup.send("❌ Você não está em nenhuma lista.", ephemeral=True)

        if user_id in players:
            players.remove(user_id)
            # Move um suplente para a lista principal se houver vaga e suplentes
            if suplentes:
                primeiro_suplente = suplentes.pop(0)
                players.append(primeiro_suplente)
                try:
                    membro_promovido = await interaction.guild.fetch_member(primeiro_suplente)
                    await membro_promovido.send(f"🎉 Você foi promovido para a lista de participantes da ação **{embed.title}**!")
                except (discord.NotFound, discord.Forbidden):
                    pass

        elif user_id in suplentes:
            suplentes.remove(user_id)

        await interaction.followup.send("✅ Você saiu da lista.", ephemeral=True)
        await self.atualizar_embed(interaction, players, suplentes)

    @ui.button(label="Finalizar Ação", style=discord.ButtonStyle.primary, emoji="🏁", custom_id="acao_finalizar")
    async def finalizar(self, interaction: discord.Interaction, button: ui.Button):
        embed = interaction.message.embeds[0]
        creator_id, _ = parse_embed_footer(embed.footer.text)

        if interaction.user.id != creator_id:
            return await interaction.response.send_message("❌ Apenas o criador da ação pode finalizá-la.", ephemeral=True)

        view_resultado = ResultadoView(interaction)
        await interaction.response.send_message("Qual foi o resultado da ação?", view=view_resultado, ephemeral=True)
        await view_resultado.wait()

        if view_resultado.resultado is None:
            return await interaction.edit_original_response(content="Tempo esgotado. A finalização foi cancelada.", view=None)

        # --- Geração do Log Final ---
        players = get_players_from_field(embed.fields[4].value)
        players_str = "\n".join(f"• <@{p_id}>" for p_id in players) if players else "• *Ninguém participou*"

        log_embed = discord.Embed(
            title=f"🏁 Log da Ação: {embed.title}",
            color=discord.Color.green() if view_resultado.resultado == "Vitória" else discord.Color.red()
        )
        log_embed.add_field(name="Criador", value=f"<@{creator_id}>", inline=False)
        log_embed.add_field(name="Resultado", value=f"**{view_resultado.resultado}**", inline=False)
        log_embed.add_field(name="Participantes Finais", value=players_str, inline=False)
        log_embed.set_footer(text=f"Ação finalizada em: {datetime.now().strftime('%d/%m/%Y %H:%M')}")

        canal_log = interaction.guild.get_channel(CANAL_LOG_ACOES_ID)
        if canal_log:
            await canal_log.send(embed=log_embed)

        # Desativa os botões e atualiza o painel original
        for item in self.children: item.disabled = True
        embed.title = f"[FINALIZADA] {embed.title}"
        embed.color = discord.Color.dark_grey()
        await interaction.message.edit(embed=embed, view=self)
        await interaction.edit_original_response(content="✅ Ação finalizada e log gerado!", view=None)

class AcaoModal(ui.Modal, title="Marcar Nova Ação"):
    titulo = ui.TextInput(label="Título da Ação", placeholder="Ex: Invasão à Ammu-Nation", required=True)
    armamento = ui.TextInput(label="Armamento Sugerido", placeholder="Ex: Fuzis e Coletes", required=True)
    local = ui.TextInput(label="Local da Ação", placeholder="Ex: Ammu-Nation Central", required=True)
    data_hora = ui.TextInput(label="Dia e Hora", placeholder="Ex: 20/07 às 21:00", required=True)
    max_players = ui.TextInput(label="Nº de Participantes", placeholder="Ex: 4", required=True)
    
    async def on_submit(self, interaction: discord.Interaction):
        try:
            max_players_val = int(self.max_players.value)
            if not (2 <= max_players_val <= 20):
                raise ValueError("O número de participantes deve estar entre 2 e 20.")
        except ValueError as e:
            return await interaction.response.send_message(f"❌ Número de participantes inválido. {e}", ephemeral=True)

        await interaction.response.defer(ephemeral=True)

        canal_acoes = interaction.guild.get_channel(CANAL_ACOES_ID)
        if not canal_acoes:
            await interaction.followup.send("❌ Canal de ações não configurado. Avise um administrador.", ephemeral=True)
            return

        embed = discord.Embed(
            title=self.titulo.value,
            description="Uma nova ação foi marcada! Clique nos botões para participar.",
            color=0x3498db # Azul
        )
        embed.set_author(name=f"Ação marcada por {interaction.user.display_name}", icon_url=interaction.user.avatar.url)
        embed.add_field(name="🔫 Armamento", value=self.armamento.value, inline=True)
        embed.add_field(name="📍 Local", value=self.local.value, inline=True)
        embed.add_field(name="🗓️ Data/Hora", value=self.data_hora.value, inline=True)
        embed.add_field(name="\u200b", value="\u200b", inline=True) # Espaço em branco
        embed.add_field(name="👥 Participantes", value="• *Nenhum participante*", inline=False)
        embed.add_field(name="🔄 Suplentes", value="• *Nenhum suplente*", inline=False)
        embed.set_footer(text=f"Criador: {interaction.user.id} | Vagas: {max_players_val}")

        await canal_acoes.send(embed=embed, view=AcaoView())
        await interaction.followup.send("✅ Ação marcada com sucesso!", ephemeral=True)

# --- Cog Principal ---

class AcaoCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.bot.add_view(AcaoView())

    @commands.Cog.listener()
    async def on_ready(self):
        print("Cog de Ações pronto.")

    @app_commands.command(name="marcar_acao", description="Abre o formulário para marcar uma nova ação.")
    @app_commands.default_permissions(manage_messages=True) # Permissão genérica para staff
    async def marcar_acao(self, interaction: discord.Interaction):
        """
        Inicia o processo de marcar uma ação.
        """
        await interaction.response.send_modal(AcaoModal())

async def setup(bot: commands.Bot):
    await bot.add_cog(AcaoCog(bot))