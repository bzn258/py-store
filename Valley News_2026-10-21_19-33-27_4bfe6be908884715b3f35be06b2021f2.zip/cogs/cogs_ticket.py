# cogs_tickets.py
import os
import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime
from io import BytesIO

# IDs do arquivo .env com fallbacks seguros para evitar crashes ao importar
GUILD_ID = int(os.getenv("GUILD_ID", 0) or 0)
TICKET_CATEGORY_ID = int(os.getenv("TICKET_CATEGORY_ID", 0) or 0)
TICKET_LOG_CHANNEL_ID = int(os.getenv("TICKET_LOG_CHANNEL_ID", 0) or 0)
TICKET_STAFF_ROLE_ID = int(os.getenv("TICKET_STAFF_ROLE_ID", 0) or 0)

async def get_ticket_creator(channel: discord.TextChannel, guild: discord.Guild, fallback: discord.Member = None) -> discord.Member | None:
    """Identifica confiavelmente o criador do ticket, mesmo após reinicialização do bot."""
    if fallback:
        return fallback

    # 1. Tenta recuperar pelo tópico do canal (onde salvamos o ID do criador)
    if channel.topic:
        for part in channel.topic.replace(":", " ").replace("|", " ").split():
            if part.isdigit() and len(part) >= 15:
                try:
                    user_id = int(part)
                    member = guild.get_member(user_id)
                    if not member:
                        member = await guild.fetch_member(user_id)
                    if member:
                        return member
                except Exception:
                    pass

    # 2. Tenta recuperar pelo final do nome do canal (ex: suporte-123456789012345678)
    try:
        parts = channel.name.split("-")
        last_part = parts[-1]
        if last_part.isdigit() and len(last_part) >= 15:
            user_id = int(last_part)
            member = guild.get_member(user_id)
            if not member:
                member = await guild.fetch_member(user_id)
            if member:
                return member
    except Exception:
        pass

    return None

# Função auxiliar para criar o canal do ticket (usada também pelo cog de vendas)
async def create_ticket_channel(guild: discord.Guild, user: discord.Member, name_prefix: str) -> discord.TextChannel:
    category = guild.get_channel(TICKET_CATEGORY_ID) if TICKET_CATEGORY_ID else None
    if not category and TICKET_CATEGORY_ID:
        try:
            category = await guild.fetch_channel(TICKET_CATEGORY_ID)
        except Exception:
            category = None

    # Permissões para o canal do ticket
    overwrites = {
        guild.default_role: discord.PermissionOverwrite(read_messages=False),
        user: discord.PermissionOverwrite(read_messages=True, send_messages=True, attach_files=True),
        guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True, manage_channels=True)
    }

    # Garante permissão ao cargo de staff se configurado
    if TICKET_STAFF_ROLE_ID:
        staff_role = guild.get_role(TICKET_STAFF_ROLE_ID)
        if staff_role:
            overwrites[staff_role] = discord.PermissionOverwrite(read_messages=True, send_messages=True, attach_files=True)

    channel_name = f"{name_prefix}-{user.id}"
    topic = f"Ticket Criador ID: {user.id} | Usuário: {user.name}"
    ticket_channel = await guild.create_text_channel(channel_name, category=category, overwrites=overwrites, topic=topic)
    return ticket_channel

async def process_ticket_closure(channel: discord.TextChannel, guild: discord.Guild, closer: discord.Member, ticket_creator: discord.Member = None):
    """Função centralizada para fechar tickets, gerar transcript e enviar logs."""
    # Se o criador não foi passado diretamente, tenta identificar
    if not ticket_creator:
        ticket_creator = await get_ticket_creator(channel, guild)

    creator_name = ticket_creator.name if ticket_creator else "Desconhecido"
    creator_mention = ticket_creator.mention if ticket_creator else f"`#{channel.name}`"

    # Gera o transcript das mensagens
    messages = [message async for message in channel.history(limit=None, oldest_first=True)]
    transcript_content = f"Transcript do ticket: #{channel.name}\n"
    transcript_content += f"Criador: {creator_name} ({ticket_creator.id if ticket_creator else 'N/A'})\n"
    transcript_content += f"Fechado por: {closer.name} ({closer.id})\n"
    transcript_content += "="*40 + "\n\n"

    for msg in messages:
        timestamp = msg.created_at.strftime("%Y-%m-%d %H:%M:%S")
        transcript_content += f"[{timestamp}] {msg.author.name}: {msg.content}\n"
        if msg.attachments:
            for att in msg.attachments:
                transcript_content += f"    [Anexo: {att.url}]\n"

    transcript_bytes = BytesIO(transcript_content.encode('utf-8'))
    transcript_file = discord.File(transcript_bytes, filename=f"transcript-{channel.name}.txt")

    # Envia o log de fechamento
    log_channel = guild.get_channel(TICKET_LOG_CHANNEL_ID) if TICKET_LOG_CHANNEL_ID else None
    if not log_channel and TICKET_LOG_CHANNEL_ID:
        try:
            log_channel = await guild.fetch_channel(TICKET_LOG_CHANNEL_ID)
        except Exception:
            log_channel = None

    if log_channel:
        embed_log = discord.Embed(
            title="Ticket Fechado",
            description=f"O ticket `{channel.name}` de {creator_mention} foi fechado por {closer.mention}.",
            color=discord.Color.red(),
            timestamp=discord.utils.utcnow()
        )
        try:
            await log_channel.send(embed=embed_log, file=transcript_file)
        except Exception as e:
            print(f"⚠️ Erro ao enviar log no canal de logs: {e}")

    # Envia o transcript para o criador do ticket no privado (se disponível)
    if ticket_creator:
        try:
            transcript_bytes.seek(0)
            user_transcript_file = discord.File(transcript_bytes, filename=f"transcript-{channel.name}.txt")
            await ticket_creator.send(f"Seu ticket (`{channel.name}`) foi fechado. Aqui está o registro da conversa:", file=user_transcript_file)
        except (discord.Forbidden, discord.HTTPException):
            pass

    # Deleta o canal do ticket
    try:
        await channel.delete(reason=f"Ticket fechado por {closer.name}")
    except Exception as e:
        print(f"⚠️ Erro ao deletar o canal do ticket: {e}")

class TicketPanelView(discord.ui.View):
    def __init__(self, ticket_creator: discord.Member = None):
        super().__init__(timeout=None)
        self.ticket_creator = ticket_creator


    @discord.ui.button(label="Fechar Ticket", style=discord.ButtonStyle.danger, emoji="🔒", custom_id="ticket_close_button")
    async def close_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.response.is_done():
            await interaction.response.send_message("🔒 Fechando o ticket e gerando transcript...", ephemeral=True)
        else:
            await interaction.followup.send("🔒 Fechando o ticket e gerando transcript...", ephemeral=True)
        
        # Desativa os botões apenas na mensagem do Discord, sem alterar a instância persistente global
        try:
            msg_view = discord.ui.View.from_message(interaction.message)
            if msg_view:
                for item in msg_view.children:
                    item.disabled = True
                await interaction.message.edit(view=msg_view)
        except Exception:
            pass

        creator = await get_ticket_creator(interaction.channel, interaction.guild, self.ticket_creator)
        await process_ticket_closure(interaction.channel, interaction.guild, interaction.user, creator)

class TicketReasonSelect(discord.ui.Select):
    """Menu suspenso persistente para o usuário selecionar o motivo do ticket."""
    def __init__(self):
        options = [
            discord.SelectOption(label="Suporte/Dúvidas", value="suporte", emoji="❓", description="Para obter ajuda geral ou tirar dúvidas."),
            discord.SelectOption(label="Contratar uma reportagem", value="Reportagem", emoji="📰", description="Para orçar ou solicitar uma reportagem nova."),
        ]
        super().__init__(
            custom_id="ticket_reason_select",
            placeholder="Escolha o motivo do seu contato...",
            min_values=1,
            max_values=1,
            options=options
        )

    async def callback(self, interaction: discord.Interaction):
        # Confirma a interação imediatamente para evitar timeout de 3 segundos
        await interaction.response.defer(ephemeral=True)

        reason_value = self.values[0]
        reason_option = discord.utils.get(self.options, value=reason_value)

        # Cria o canal do ticket com o prefixo correto
        ticket_channel = await create_ticket_channel(interaction.guild, interaction.user, name_prefix=reason_value)

        # Log de criação do ticket
        log_channel = interaction.guild.get_channel(TICKET_LOG_CHANNEL_ID) if TICKET_LOG_CHANNEL_ID else None
        if not log_channel and TICKET_LOG_CHANNEL_ID:
            try:
                log_channel = await interaction.guild.fetch_channel(TICKET_LOG_CHANNEL_ID)
            except Exception:
                log_channel = None

        if log_channel:
            log_embed = discord.Embed(
                title="Ticket Criado",
                description=f"**Usuário:** {interaction.user.mention}\n**Canal:** {ticket_channel.mention}\n**Motivo:** {reason_option.label if reason_option else reason_value}",
                color=discord.Color.green(),
                timestamp=discord.utils.utcnow()
            )
            try:
                await log_channel.send(embed=log_embed)
            except Exception:
                pass

        # Mensagem inicial personalizada no ticket
        initial_message = {
            "suporte": f"Olá {interaction.user.mention}, descreva seu problema ou dúvida em detalhes. Um membro da equipe irá atendê-lo em breve.",
            "Reportagem": f"Olá {interaction.user.mention}, por favor, descreva com o máximo de detalhes possível como você gostaria que sua reportagem fosse realizada.",
        }

        ticket_embed = discord.Embed(
            title=f"Ticket: {reason_option.label if reason_option else reason_value}",
            description=initial_message.get(reason_value, "Por favor, descreva sua solicitação."),
            color=discord.Color.blurple()
        )

        # Prepara a mensagem com menção do usuário e da equipe
        staff_role = interaction.guild.get_role(TICKET_STAFF_ROLE_ID) if TICKET_STAFF_ROLE_ID else None
        mention_content = interaction.user.mention
        if staff_role:
            mention_content += f" {staff_role.mention}"
        
        await ticket_channel.send(
            content=mention_content,
            embed=ticket_embed,
            view=TicketPanelView(interaction.user)
        )

        # Edita a mensagem efêmera confirmando a criação
        await interaction.edit_original_response(content=f"✅ Seu ticket foi criado com sucesso em {ticket_channel.mention}!", view=None)

class TicketReasonView(discord.ui.View):
    """View persistente que contém o menu de seleção de motivo."""
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(TicketReasonSelect())

class TicketCreationPanelView(discord.ui.View):
    """View persistente com o botão para iniciar a criação de um ticket."""
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Abrir Ticket", style=discord.ButtonStyle.primary, emoji="🎟️", custom_id="create_ticket_button")
    async def create_ticket_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        # Verifica se o usuário já tem um ticket aberto
        category = interaction.guild.get_channel(TICKET_CATEGORY_ID) if TICKET_CATEGORY_ID else None
        
        existing_channel = None
        if category and hasattr(category, 'text_channels'):
            for ch in category.text_channels:
                if f"-{interaction.user.id}" in ch.name:
                    existing_channel = ch
                    break

        if not existing_channel:
            for ch in interaction.guild.text_channels:
                if ch.name.endswith(f"-{interaction.user.id}"):
                    existing_channel = ch
                    break

        if existing_channel:
            await interaction.response.send_message(f"❗️ Você já possui um ticket aberto em {existing_channel.mention}!", ephemeral=True)
            return
        
        await interaction.response.send_message("Por favor, selecione o motivo do seu ticket:", view=TicketReasonView(), ephemeral=True)

class Tickets(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        # Registra todas as views persistentes para que os botões sigam funcionando após reinicializações
        self.bot.add_view(TicketCreationPanelView())
        self.bot.add_view(TicketReasonView())
        self.bot.add_view(TicketPanelView())

    # Grupo de comandos de barra para tickets
    ticket_group = app_commands.Group(name="ticket", description="Comandos relacionados ao sistema de tickets.")

    @ticket_group.command(name="fechar", description="Fecha o canal de ticket atual e salva o histórico.")
    async def fechar_ticket(self, interaction: discord.Interaction):
        category_id = int(os.getenv("TICKET_CATEGORY_ID", 0) or 0)
        is_ticket = (category_id and interaction.channel.category_id == category_id) or ("-" in interaction.channel.name) or interaction.user.guild_permissions.administrator
        
        if not is_ticket:
            await interaction.response.send_message("❌ Este comando só pode ser utilizado dentro de um canal de ticket!", ephemeral=True)
            return

        await interaction.response.send_message("Fechando o ticket...", ephemeral=True)
        await process_ticket_closure(interaction.channel, interaction.guild, interaction.user)

    @commands.command(name="fechar")
    async def fechar_comando(self, ctx: commands.Context):
        """Comando prefixado (!fechar) para fechar tickets antigos ou travados."""
        category_id = int(os.getenv("TICKET_CATEGORY_ID", 0) or 0)
        is_ticket = (category_id and ctx.channel.category_id == category_id) or ("-" in ctx.channel.name) or ctx.author.guild_permissions.administrator

        if not is_ticket:
            await ctx.send("❌ Este comando só pode ser utilizado dentro de um canal de ticket!")
            return

        await ctx.send("Fechando o ticket...")
        await process_ticket_closure(ctx.channel, ctx.guild, ctx.author)

    @ticket_group.command(name="painel", description="Envia o painel de criação de tickets em um canal.")
    @app_commands.describe(
        canal="O canal onde o painel será enviado.",
        image_url="URL da imagem para exibir no painel (opcional)."
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def ticket_panel(self, interaction: discord.Interaction, canal: discord.TextChannel, image_url: str = None):
        await interaction.response.defer(ephemeral=True)
        embed = discord.Embed(
            title="Central de Atendimento",
            description="Precisa de ajuda ou deseja solicitar um serviço? Clique no botão abaixo para abrir um ticket!",
            color=discord.Color.from_rgb(88, 101, 242)
        )
        # Procura imagem na pasta 'imagens' ou usa image_url se fornecido
        imagens_dir = os.path.join(os.path.dirname(__file__), '..', 'imagens')
        arquivo_banner = None

        if not image_url:
            for nome_arq in ['painel_ticket.png', 'painel_ticket.jpg', 'painel_ticket.jpeg', 'painel_ticket.gif', 'ticket.png', 'ticket.jpg']:
                caminho = os.path.join(imagens_dir, nome_arq)
                if os.path.isfile(caminho):
                    arquivo_banner = discord.File(caminho, filename=nome_arq)
                    embed.set_image(url=f"attachment://{nome_arq}")
                    break
        else:
            embed.set_image(url=image_url)

        embed.set_footer(text="Nossa equipe está pronta para te atender.")

        try:
            if arquivo_banner:
                await canal.send(embed=embed, file=arquivo_banner, view=TicketCreationPanelView())
            else:
                await canal.send(embed=embed, view=TicketCreationPanelView())
            await interaction.followup.send(f"✅ Painel de tickets enviado com sucesso em {canal.mention}!", ephemeral=True)
        except discord.Forbidden:
            await interaction.followup.send("❌ Não tenho permissão para enviar mensagens neste canal.", ephemeral=True)

async def setup(bot: commands.Bot):
    await bot.add_cog(Tickets(bot))

